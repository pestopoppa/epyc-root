#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/sr7-qwen36-proposer-w1-20261102
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id sr7-qwen36-proposer-w1-20261102 --class cpu --role bench --claim-cpus 0-95 --min-window 10800 --port 18989 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B /mnt/raid0/llm/tmp/sr7-qwen36-proposer-w1-20261102/docs/reports/sr7-proposer-preparation/row_entrypoint.py --config $D/config.json --config-sha256 1f5a39aca0755aabb7cc4f59ce7c71cae1295b9356dabe64c7de248454da0519"
