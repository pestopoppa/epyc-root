#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/sr7-qwen36-proposer-w3-20261102
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id sr7-qwen36-proposer-w3-20261102 --class cpu --role bench --claim-cpus 0-95 --min-window 10800 --port 18989 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B /mnt/raid0/llm/tmp/sr7-qwen36-proposer-w3-20261102/docs/reports/sr7-proposer-preparation/row_entrypoint.py --config $D/config.json --config-sha256 3e938c898a1b9bf72d5dae234a2f0e914b1d01559c563a1860c5caeeb23a1ee7"
