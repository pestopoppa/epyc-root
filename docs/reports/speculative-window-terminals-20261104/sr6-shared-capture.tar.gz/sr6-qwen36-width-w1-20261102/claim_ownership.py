#!/usr/bin/env python3
"""Verify SR-6 full-host build claim with the existing live region guard.

Only usable for the full q0-q3, role=build, cross-role-mutex configuration
enforced by scripts/gitnexus-guard.py. The caller must independently bind the
expected guard digest, interpreter, grant paths, and launcher at publication.
This check does not prove residency, process-tree drain or in-flight STOP.
"""
import hashlib
import os
from pathlib import Path
import re
import subprocess

_HEX = re.compile(r'[0-9a-f]{64}\Z')
_GUARD = Path(__file__).resolve().parents[3] / 'scripts' / 'gitnexus-guard.py'


class FullHostClaim:
    """Callable ownership predicate for KeeperAdmission, rechecked each call."""
    def __init__(self, guard_sha256, interpreter):
        if (not isinstance(guard_sha256, str) or not _HEX.fullmatch(guard_sha256)
                or not isinstance(interpreter, str) or not os.path.isabs(interpreter)):
            raise ValueError('guard digest and absolute interpreter required')
        self.guard_sha256 = guard_sha256
        self.interpreter = interpreter

    def __call__(self):
        try:
            fd = os.open(_GUARD, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            with os.fdopen(fd, 'rb') as f:
                raw = f.read(131073)
            if len(raw) > 131072 or hashlib.sha256(raw).hexdigest() != self.guard_sha256:
                return False
            source = raw.decode('utf-8')
            # Execute the bytes that were hashed, avoiding a pathname swap
            # between digest verification and interpreter open.
            result = subprocess.run([self.interpreter, '-I', '-c', source, '--repo', 'root'],
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, timeout=5, check=False)
            return result.returncode == 0
        except (OSError, UnicodeDecodeError, subprocess.SubprocessError, ValueError):
            return False
