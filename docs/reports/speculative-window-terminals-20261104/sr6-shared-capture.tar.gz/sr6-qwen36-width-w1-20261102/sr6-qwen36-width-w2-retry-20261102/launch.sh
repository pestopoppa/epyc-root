#!/bin/bash
# SR-6 W2 retry: shared sealed exposure root, distinct retry server evidence.
set -euo pipefail
D=/mnt/raid0/llm/tmp/speculative-decoding-mtp/sr6-qwen36-width-w1-20261102/sr6-qwen36-width-w2-retry-20261102
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id sr6-qwen36-width-w2-retry-20261102 --class cpu --role bench --claim-cpus 0-95 --min-window 10800 --port 18979 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B $D/row_entrypoint_w2.py --config $D/config.json --config-sha256 ccdf98e4ee3a10856108b0b926a94fd2bdb1cefd9c7516cc6069d265a850c507"
