#!/bin/bash
# Revision 2: verify the manifest-pinned multimodal server library.
set -euo pipefail
D=/mnt/raid0/llm/tmp/speculative-decoding-mtp/sr6-qwen36-width-w1-20261102
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id sr6-qwen36-width-w1-20261102 --class cpu --role bench --claim-cpus 0-95 --gpu-quiet exclusive --min-window 10800 --port 18979 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B $D/row_entrypoint.py --config $D/config.json --config-sha256 089eb6fc6db531be64ef2449aa5df9f83ec598e7bbab3ad91814d5a945a215e9"
