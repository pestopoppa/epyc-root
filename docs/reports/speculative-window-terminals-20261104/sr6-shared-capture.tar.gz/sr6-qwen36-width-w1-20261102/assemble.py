#!/usr/bin/env python3
import hashlib, json, os, shutil
from pathlib import Path
root=Path('/mnt/raid0/llm/tmp/speculative-decoding-mtp/sr6-qwen36-width-w1-20261102')
source=Path('/mnt/raid0/llm/worktrees/mains/h-speculative-decoding-mtp/docs/reports/sr6-successor-preparation')
config=json.loads((root/'config.json').read_bytes())
if config.get('preflight_status') != 'VERIFIED': raise SystemExit('refusing unverified config')
for f in source.glob('*.py'):
 if not f.name.startswith('test_') and f.name not in ('prepare_rendered_corpus.py','verify_candidate_sources.py'):
  shutil.copy2(f,root/f.name)
cs=hashlib.sha256((root/'config.json').read_bytes()).hexdigest()
names=sorted(p.name for p in root.glob('*.py') if p.name != 'assemble.py')
names += ['config.json','packet.json','preflight-receipt.json','region-lock','REGION-LOCK-INPUTS.sha256','REGION-LOCK-PYTHON-ALLOW.txt']
with (root/'SOURCE-SHA256SUMS').open('w') as f:
 for n in names:
  f.write(hashlib.sha256((root/n).read_bytes()).hexdigest()+'  '+str(root/n)+'\n')
id='sr6-qwen36-width-w1-20261102'
launcher=f'''#!/bin/bash
# Revision 2: verify the manifest-pinned multimodal server library.
set -euo pipefail
D={root}
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id {id} --class cpu --role bench --claim-cpus 0-95 --gpu-quiet exclusive --min-window 10800 --port 18979 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B $D/row_entrypoint.py --config $D/config.json --config-sha256 {cs}"
'''
p=root/'launch.sh';p.write_text(launcher);p.chmod(0o755)
spec={'id':id,'owner':'handoff-speculative-decoding-mtp','launcher':str(p),'lane':'cpu','regions':'0-95','scratch_root':str(root),'result_path':str(root/'RESULT.json'),'result_format':'json','dryrun_native_result':True,'decision_rule':'Window 1 of three predeclared windows only. Preserve every exposure, response, placement and terminal; interrupted, incomplete, or missing provenance is UNKNOWN. Analyze only after all three independent windows with the sealed decision rule; no registry change or performance claim from this row alone.','ram_gib':128,'estimate_s':14400,'min_window_s':10800,'handoff_task':'speculative-decoding-mtp-refresh.md:SR-6','priority_rank':30,'kind':'compute','keep':['*.json','*.jsonl','*.py','*.sh','*.sha256','SOURCE-SHA256SUMS','region-lock','output/**','smoke/**']}
(root/'spec.json').write_text(json.dumps(spec,indent=2)+'\n')
print('assembled',p,'config_sha256',cs)
