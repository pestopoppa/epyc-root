#!/bin/bash
# SR-6 W3 successor: shared sealed exposure root, distinct W3 server evidence.
set -euo pipefail
D=/mnt/raid0/llm/tmp/speculative-decoding-mtp/sr6-qwen36-width-w1-20261102/sr6-qwen36-width-w3-20261102
cd "$D"
sha256sum -c --quiet "$D/SOURCE-SHA256SUMS"
export FILLER_RL="$D/region-lock" RUS3_DIAGNOSTIC=1
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id sr6-qwen36-width-w3-20261102 --class cpu --role bench --claim-cpus 0-95 --min-window 10800 --port 18979 --stop "$D/STOP" --workdir "$D" --complete-cmd "test -s $D/RESULT.json" --cmd "/usr/bin/python3 -B $D/row_entrypoint_w2.py --config $D/config.json --config-sha256 fd164771a13dc40bc10ff209af7b32ae4b676e6efe4c96bb3640249212087043"
