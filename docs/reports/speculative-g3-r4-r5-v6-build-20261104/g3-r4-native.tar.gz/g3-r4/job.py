#!/usr/bin/env python3
"""Four-cell G3 V4 scoped MI210 dispatch diagnostic, one server per cell."""
import hashlib, json, os, pathlib, subprocess, sys, tempfile, time
D=pathlib.Path('/mnt/raid0/llm/tmp/speculative-decoding-mtp/g3-gpu-20261104-r4')
V=D/'vendor'; ROOT=pathlib.Path('/mnt/raid0/llm/tmp/speculative-decoding-mtp/g3-v4-build-row')
BUILD=ROOT/'runs/build-BwLyph3y/build/bin'
MODEL='/mnt/raid0/llm/models/Qwen3.6-35B-A3B-MTP-Q8_0.gguf'
BACKEND='c9ed775d4a2d313dcdfc1d5d522513a476923ce3dde129eac5d6f5f33ede2abe'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
 stop=pathlib.Path(os.environ['FILLER_STOPFILE']); deadline=int(os.environ['FILLER_DEADLINE'])
 result=pathlib.Path(os.environ.get('FILLER_DRYRUN_RESULT_PATH') or D/'RESULT.jsonl')
 if stop.exists() or time.time()>=deadline: return 75
 runs=D/'runs'; runs.mkdir(exist_ok=True); run=pathlib.Path(tempfile.mkdtemp(prefix='attempt-',dir=runs))
 if result.exists(): raise RuntimeError('result already exists; no overwrite')
 for kv,depth in [('q8_0',1),('q8_0',4),('q4_0',1),('q4_0',4)]:
  if stop.exists() or time.time()>=deadline: return 75
  cell=f'{kv}-d{depth}'; cfg=run/f'{cell}.json'; out=run/cell
  payload={'prompt':'Explain how a balanced search tree maintains ordered keys, then work through an example with eight distinct keys.', 'n_predict':128, 'temperature':0, 'seed':42, 'stream':False}
  c={'output':str(out),'build_result':str(ROOT/'RESULT.json'),'build_root':str(ROOT),
     'server':str(BUILD/'llama-server'),'backend':str(BUILD/'libggml-hip.so.0.16.0'),'backend_sha256':BACKEND,
     'trace_marker':'G3_FATTN_DISPATCH_V3','model':MODEL,
     'model_sha256':'c1283d8b80c3e38b2735ddbc9766d3b3126f44d6c484be419d4e101d09a76131',
     'model_preflight':str(D/'preflight.json'),'model_preflight_sha256':sha(D/'preflight.json'),
     'layer_manifest':str(V/'qwen35-layer-manifest.json'),'layer_manifest_sha256':sha(V/'qwen35-layer-manifest.json'),
     'timeout_seconds':min(1700,max(1,int(deadline-time.time()))),'url':'http://127.0.0.1:18991/completion','rocm_card':'card0',
     'server_args':['-m',MODEL,'--host','127.0.0.1','--port','18991','-np','1','-c','4096','-b','512','-ub','512','--flash-attn','on','-ctk',kv,'-ctv',kv,'--device','ROCm0','-ngl','999','--spec-type','draft-mtp','--spec-draft-n-max',str(depth),'--spec-draft-p-min','0'],
     'requests':[payload]}
  cfg.write_text(json.dumps(c,indent=2)+'\n')
  rc=subprocess.run([sys.executable,str(V/'diagnostic_runner.py'),str(cfg)],check=False).returncode
  rp=out/'result.json'
  if rc or not rp.exists(): return 75 if stop.exists() or time.time()>=deadline else 1
  record=json.loads(rp.read_text())
  if record.get('status')!='complete' or record.get('process_group_drained') is not True: return 1
  unit={'cell':cell,'status':'complete','result':str(rp),'result_sha256':sha(rp),'server_log':str(out/'server.log'),
        'trace_status':record.get('timed_analysis',{}).get('status','UNKNOWN'),'scope':'instrumented dispatch diagnostic only'}
  with result.open('a') as f: f.write(json.dumps(unit)+'\n'); f.flush(); os.fsync(f.fileno())
 return 0
if __name__=='__main__': sys.exit(main())
