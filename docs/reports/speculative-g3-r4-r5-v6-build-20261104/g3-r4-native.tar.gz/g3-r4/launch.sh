#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/speculative-decoding-mtp/g3-gpu-20261104-r4
exec bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id g3-v10-v4-mi210-r4-20261104 --class gpu --gpu-quiet exclusive --no-fold-siblings --role bench --min-window 5400 --stop "$D/STOP" --workdir "$D" --port 18991 --precond-cmd "sha256sum -c $D/runtime.sha256" --cmd "python3 $D/job.py" --complete-cmd "python3 $D/complete.py"
