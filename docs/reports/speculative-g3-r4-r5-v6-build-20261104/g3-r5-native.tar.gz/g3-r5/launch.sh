#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/speculative-decoding-mtp/g3-gpu-20261104-r5
EXPECTED_RUNTIME_SHA=508b322823e2dde5945179004c6a1f1e4a50fa80bff329b240e719b94a234b40
exec bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id g3-v10-v4-mi210-r5-20261104 --class gpu --gpu-quiet exclusive --no-fold-siblings --role bench --min-window 5400 --stop "$D/STOP" --workdir "$D" --port 18991 --precond-cmd "printf '%s  %s\n' '$EXPECTED_RUNTIME_SHA' '$D/runtime.sha256' | sha256sum -c && sha256sum -c '$D/runtime.sha256'" --cmd "python3 $D/job.py" --complete-cmd "python3 $D/complete.py"
