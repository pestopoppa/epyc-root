#!/usr/bin/env python3
import hashlib,json,os,pathlib,sys
D=pathlib.Path('/mnt/raid0/llm/tmp/speculative-decoding-mtp/g3-gpu-20261104-r5')
if os.environ.get('FILLER_DRYRUN')=='1': sys.exit(1)
try:
 rows=[json.loads(x) for x in (D/'RESULT.jsonl').read_text().splitlines()]
 assert [x['cell'] for x in rows]==['q8_0-d1','q8_0-d4','q4_0-d1','q4_0-d4']
 for x in rows:
  p=pathlib.Path(x['result']).resolve(strict=True); assert p.is_relative_to((D/'runs').resolve())
  assert hashlib.sha256(p.read_bytes()).hexdigest()==x['result_sha256']
  y=json.loads(p.read_text()); assert y['status']=='complete' and y['process_group_drained'] is True
except (OSError,ValueError,KeyError,AssertionError): sys.exit(1)
