"""Scratch-only consumed grant binding; consistency checks, not provenance authority."""
import hashlib
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from select_run import aware, kv_line


def grant_directory(env):
    # Mirror filler_run15 shell ${VAR:-default}: empty values use the default.
    flags = env.get("FILLER_FLAGS_DIR") or "/mnt/raid0/llm/tmp/compute-flags"
    directory = env.get("FILLER_GRANTS_DIR") or str(Path(flags) / "grants")
    parent = Path(directory)
    if not parent.is_absolute() or parent.is_symlink() or parent.resolve() != parent:
        raise ValueError("grant directory must be absolute, canonical and non-symlink")
    return parent


def consumed_grant(root, env=None, clock=None):
    env = os.environ if env is None else env
    clock = datetime.now(timezone.utc) if clock is None else clock
    identity = env.get('FILLER_ID', '')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', identity):
        raise ValueError('missing/invalid FILLER_ID')
    parent = grant_directory(env)
    source = parent / (identity + '.grant')
    if source.with_suffix('.ended').exists() or source.with_suffix('.complete').exists():
        raise ValueError('grant already terminal')
    fields = kv_line(source)
    raw = source.read_bytes()
    start, end = aware(fields['start']), aware(fields['end'])
    if not start <= clock < end:
        raise ValueError('grant not currently valid')
    if env.get('FILLER_END') != str(int(end.timestamp())) or aware(env.get('FILLER_END_ISO')) != end:
        raise ValueError('launcher end does not match consumed grant')
    if fields['regions'] != 'mi210_0,184-191':
        raise ValueError('exact mi210_0,184-191 grant required')
    if 'cpus' in fields and fields['cpus'] != '184-191':
        raise ValueError('grant cpus must match 184-191')
    # Re-read parser/bytes to refuse replacement while capturing.
    if kv_line(source) != fields or source.read_bytes() != raw:
        raise ValueError('grant changed while capturing')
    archive = Path(root) / 'out/grants' / source.name
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open('xb') as target:
        target.write(raw)
    return dict(grant_id=identity, grant_start=fields['start'], grant_end=fields['end'],
                grant_sha256=hashlib.sha256(raw).hexdigest(), grant_source=str(source),
                grant_snapshot=str(archive))


def verify_consumed(binding):
    source = Path(binding['grant_source'])
    fields = kv_line(source)
    if (hashlib.sha256(source.read_bytes()).hexdigest() != binding['grant_sha256']
            or fields['start'] != binding['grant_start'] or fields['end'] != binding['grant_end']):
        raise ValueError('consumed grant changed before COMPLETE')
