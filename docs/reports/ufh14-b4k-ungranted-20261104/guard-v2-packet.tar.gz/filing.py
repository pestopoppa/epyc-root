"""File only using native original receipt; never launch a job."""
import json, shutil
from pathlib import Path
from select_run import select_run

def write_result(root):
    root = Path(root)
    complete = root / "out/COMPLETE"
    temporary = root / "out/RESULT.json.tmp"
    with temporary.open("xb") as target:
        target.write(complete.read_bytes())
    temporary.replace(root / "out/RESULT.json")

def file_run(root):
    root=Path(root); complete=root/'out/COMPLETE'
    result=root/'out/RESULT.json'
    if result.is_symlink() or not result.is_file() or result.read_bytes()!=complete.read_bytes():
        raise ValueError('missing or mismatched RESULT/COMPLETE pair')
    binding=json.loads(complete.read_text())
    ended=Path(binding['grant_source']).with_suffix('.ended')
    run=select_run(root,complete,Path(binding['grant_snapshot']),ended)
    retained=root/'out/receipts'/ended.name; retained.parent.mkdir(parents=True,exist_ok=True)
    if retained.exists() and retained.read_bytes()!=ended.read_bytes():
        raise ValueError('retained receipt differs')
    if not retained.exists(): shutil.copyfile(ended,retained)
    return run
