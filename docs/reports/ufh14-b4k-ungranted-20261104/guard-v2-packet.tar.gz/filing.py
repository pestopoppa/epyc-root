"""File only using native original receipt; never launch a job."""
import json, shutil
from pathlib import Path
from select_run import select_run

def file_run(root):
    root=Path(root); complete=root/'out/COMPLETE'; binding=json.loads(complete.read_text())
    ended=Path(binding['grant_source']).with_suffix('.ended')
    run=select_run(root,complete,Path(binding['grant_snapshot']),ended)
    retained=root/'out/receipts'/ended.name; retained.parent.mkdir(parents=True,exist_ok=True)
    if retained.exists() and retained.read_bytes()!=ended.read_bytes():
        raise ValueError('retained receipt differs')
    if not retained.exists(): shutil.copyfile(ended,retained)
    return run
