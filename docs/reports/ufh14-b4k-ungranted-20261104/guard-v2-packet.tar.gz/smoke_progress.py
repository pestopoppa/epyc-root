"""Native first successful serving call from this smoke; no qualification placeholders."""
import json, os
from datetime import datetime
from pathlib import Path
ROOT = Path(__file__).resolve().parent
COMMIT = '77ba24efe7f27783a3a98be5474bace26c753f12'

def progressed(root, since):
    for path in (root / 'out/runs').glob('*/serving_calls.jsonl'):
        if path.is_symlink():
            continue
        for line in path.read_text().splitlines():
            try:
                row = json.loads(line)
                if (row['schema'] == 'epyc.orchestrator.serving_call.v1'
                    and datetime.fromisoformat(row['ts_start'].replace('Z','+00:00')).timestamp() >= since
                    and row['dispatched'] is True and row['result']['success'] is True
                    and row['result']['tokens_generated'] > 0
                    and row['provenance']['orch_commit'] == COMMIT
                    and row['request']['n_tokens'] == 384 and row['request']['prefix_fp']
                    and row['server']['port'] == 18383):
                    return True
            except (KeyError, TypeError, ValueError):
                continue
    return False

if __name__ == '__main__':
    raise SystemExit(0 if progressed(ROOT, float(os.environ['FILLER_SMOKE_T0'])) else 1)
