import json, tempfile, unittest
from pathlib import Path
from smoke_progress import progressed, COMMIT
class NativeProgress(unittest.TestCase):
    def test_native_progress_and_refusals(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'out/runs/20261104T180000Z/serving_calls.jsonl';p.parent.mkdir(parents=True)
            self.assertFalse(progressed(root, 1))
            row=dict(schema='epyc.orchestrator.serving_call.v1', ts_start='2026-11-04T18:00:00Z', dispatched=True, result=dict(success=True,tokens_generated=1), provenance=dict(orch_commit=COMMIT), request=dict(n_tokens=384,prefix_fp={'256':'abc'}),server=dict(port=18383))
            p.write_text(json.dumps(row)+'\n');self.assertTrue(progressed(root, 1))
            self.assertFalse(progressed(root, 99999999999))
            for key, value in [('dispatched',False),('result',dict(success=False,tokens_generated=1)),('provenance',dict(orch_commit='foreign')),('request',dict(n_tokens=96,prefix_fp={'256':'abc'}))]:
                altered=dict(row);altered[key]=value;p.write_text(json.dumps(altered)+'\n');self.assertFalse(progressed(root, 1))
if __name__=='__main__':unittest.main()
