import ast
import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from grant_guard import consumed_grant, verify_consumed, grant_directory
from select_run import select_run

class Integrated(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name); self.root=self.base/'packet'; self.root.mkdir()
        self.flags=self.base/'flags'; self.flags.mkdir()
        self.grant=self.flags/'test-row.grant'
        self.grant.write_text('regions=mi210_0,184-191 start=2026-11-04T16:06Z end=2026-11-04T16:08Z holds=gpu-quiet,q3\n')
        self.env=dict(FILLER_ID='test-row',FILLER_GRANTS_DIR=str(self.flags),FILLER_END='1793808480',FILLER_END_ISO='2026-11-04T16:08Z')
        self.clock=datetime(2026,11,4,16,7,tzinfo=timezone.utc)
    def capture(self): return consumed_grant(self.root,self.env,self.clock)
    def test_native_default_directory_resolution(self):
        self.assertEqual(grant_directory({}),Path('/mnt/raid0/llm/tmp/compute-flags/grants'))
        self.assertEqual(grant_directory({'FILLER_FLAGS_DIR':'','FILLER_GRANTS_DIR':''}),Path('/mnt/raid0/llm/tmp/compute-flags/grants'))
    def test_native_flags_default_capture(self):
        grants=self.flags/'grants'; grants.mkdir(); self.grant.rename(grants/self.grant.name)
        env=dict(self.env); del env['FILLER_GRANTS_DIR']; env['FILLER_FLAGS_DIR']=str(self.flags)
        binding=consumed_grant(self.root,env,self.clock)
        self.assertEqual(binding['grant_source'],str(grants/'test-row.grant'))
    def test_override_takes_precedence(self):
        env=dict(self.env,FILLER_FLAGS_DIR='/irrelevant-flags')
        binding=consumed_grant(self.root,env,self.clock)
        self.assertEqual(binding['grant_source'],str(self.grant))
    def test_exact_regions_and_cpu_refusal(self):
        raw=self.grant.read_text()
        for regions in ('mi210_0','mi210_0,0-95','mi210_0,184-191,0','184-191,mi210_0'):
            self.grant.write_text(raw.replace('regions=mi210_0,184-191','regions='+regions))
            with self.subTest(regions=regions),self.assertRaises(ValueError): self.capture()
        self.grant.write_text(raw.strip()+' cpus=0-95\n')
        with self.assertRaises(ValueError): self.capture()
    def test_flags_directory_symlink_refused(self):
        link=self.base/'linked'; link.symlink_to(self.flags,target_is_directory=True)
        env=dict(self.env); del env['FILLER_GRANTS_DIR']; env['FILLER_FLAGS_DIR']=str(link)
        with self.assertRaises(ValueError): consumed_grant(self.root,env,self.clock)
    def test_producer_filing_native_deleted_grant(self):
        binding=self.capture(); verify_consumed(binding)
        run=self.root/'out/runs/20261104T160700Z'; run.mkdir(parents=True); (run/'calls.jsonl').write_text('{}\n')
        complete=self.root/'out/COMPLETE'; complete.write_text(json.dumps(dict(run=str(run),**binding)))
        ended=self.grant.with_suffix('.ended'); ended.write_text('rc=0 time=2026-11-04T16:07:59Z reason=complete\njob_id=test-row\n')
        self.grant.unlink()
        self.assertEqual(select_run(self.root,complete,Path(binding['grant_snapshot']),ended),run)
        ended.unlink()
        with self.assertRaises(ValueError): select_run(self.root,complete,Path(binding['grant_snapshot']),ended)
    def test_result_pair_partial_mismatch_and_atomic_write(self):
        from filing import file_run, write_result
        out=self.root/'out'; out.mkdir()
        complete=out/'COMPLETE'; complete.write_text('{"bound":"payload"}')
        with self.assertRaisesRegex(ValueError, 'RESULT/COMPLETE'): file_run(self.root)
        (out/'RESULT.json.tmp').write_text('partial')
        with self.assertRaisesRegex(ValueError, 'RESULT/COMPLETE'): file_run(self.root)
        (out/'RESULT.json.tmp').unlink()
        write_result(self.root)
        self.assertEqual((out/'RESULT.json').read_bytes(), complete.read_bytes())
        self.assertFalse((out/'RESULT.json.tmp').exists())
        (out/'RESULT.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'RESULT/COMPLETE'): file_run(self.root)

    def test_refusals(self):
        cases=[{'FILLER_ID':'foreign'},{'FILLER_END':'0'},{'FILLER_END_ISO':'2026-11-04T16:08'}, {'FILLER_GRANTS_DIR':'relative'}]
        for changes in cases:
            with self.subTest(changes=changes),self.assertRaises(ValueError):
                consumed_grant(self.root,dict(self.env,**changes),self.clock)
    def test_missing_gpu_hold(self):
        self.grant.write_text(self.grant.read_text().replace("gpu-quiet", "mi210_0"))
        with self.assertRaises(ValueError): self.capture()
    def test_terminal(self):
        self.grant.with_suffix('.ended').write_text('rc=1')
        with self.assertRaises(ValueError): self.capture()
    def test_symlink(self):
        target=self.grant.with_suffix('.saved'); self.grant.rename(target); self.grant.symlink_to(target)
        with self.assertRaises(ValueError): self.capture()
    def test_changed_consumed_grant(self):
        b=self.capture(); self.grant.write_text(self.grant.read_text().replace('q3','q2'))
        with self.assertRaises(ValueError): verify_consumed(b)
    def test_naive_or_expired_clock(self):
        with self.assertRaises(ValueError): consumed_grant(self.root,self.env,datetime(2026,11,4,16,9,tzinfo=timezone.utc))
    def test_inherited_producer_identity_is_overridden_before_import(self):
        # Execute only actual environment setup AST, never import/run the job.
        import os
        from unittest.mock import patch
        tree = ast.parse((Path(__file__).parent/'job.py').read_text())
        run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
        setup = []
        for node in run.body:
            if isinstance(node, ast.ImportFrom):
                break
            if isinstance(node, (ast.Assign, ast.Expr)) and 'ORCHESTRATOR_GIT_SHA' in ast.unparse(node):
                setup.append(node)
        self.assertEqual(len(setup), 1)
        scope = {'os': os, 'ORCH_COMMIT': '77ba24efe7f27783a3a98be5474bace26c753f12'}
        with patch.dict(os.environ, {'ORCHESTRATOR_GIT_SHA': 'foreign-inherited-commit'}):
            exec(compile(ast.fix_missing_locations(ast.Module(body=setup, type_ignores=[])), '<identity-setup>', 'exec'), scope)
            self.assertEqual(os.environ['ORCHESTRATOR_GIT_SHA'], scope['ORCH_COMMIT'])

    def test_producer_structure(self):
        tree=ast.parse((Path(__file__).parent/'job.py').read_text())
        main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
        text=ast.unparse(main)
        self.assertLess(text.index('parser.parse_args'),text.index('consumed_grant(D)'))
        self.assertLess(text.index('consumed_grant(D)'),text.index('check() != 0'))
        self.assertLess(text.index('verify_consumed(binding)'),text.index("'COMPLETE'"))
        self.assertIn('**binding',text)
    def test_owned_cleanup_startup_exception_and_interrupt(self):
        import subprocess
        from unittest.mock import Mock
        tree=ast.parse((Path(__file__).parent/'job.py').read_text())
        main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
        reap=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='reap')
        scope={'srv':Mock(), 'subprocess':subprocess}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[reap],type_ignores=[])),'<isolated-cleanup>','exec'),scope)
        for error in (RuntimeError('startup failure'), KeyboardInterrupt()):
            srv=scope['srv']; srv.reset_mock(); srv.poll.return_value=None
            srv.wait.side_effect=[subprocess.TimeoutExpired('owned-child',60),0]
            # Exercise the actual finally cleanup expression with only a mocked owned child.
            startup=next(n for n in main.body if isinstance(n,ast.Try) and n.finalbody)
            guarded=ast.Try(body=[ast.Raise(exc=ast.Name(id='failure',ctx=ast.Load()),cause=None)], handlers=[],orelse=[],finalbody=startup.finalbody)
            scope['failure']=error
            with self.assertRaises(type(error)):
                exec(compile(ast.fix_missing_locations(ast.Module(body=[guarded],type_ignores=[])),'<isolated-finally>','exec'),scope)
            srv.terminate.assert_called_once_with(); srv.kill.assert_called_once_with()
            self.assertEqual(srv.wait.call_args_list[0].args,(60,))
            self.assertEqual(srv.wait.call_args_list[1].args,(30,))
if __name__=='__main__': unittest.main()
