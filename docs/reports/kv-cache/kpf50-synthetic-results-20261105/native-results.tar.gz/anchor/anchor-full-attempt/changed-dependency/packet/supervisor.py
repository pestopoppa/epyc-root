# inert synthetic supervisor
