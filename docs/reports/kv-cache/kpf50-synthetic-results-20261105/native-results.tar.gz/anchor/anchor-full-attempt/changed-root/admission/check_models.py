synthetic check_models.py
