"""Proposed own-server canceled seed transport. NO standalone entry point.

Nothing executes at import. A reviewed launcher with a live native GPU grant
must call this object; its ctx.check_boundary must enforce grant/HOLD/deadline
before every HTTP boundary. No invocation under the current whole-host HOLD.
"""
import errno
import http.client
import json
import os
import re
import socket
import struct
import time
from pathlib import Path
from urllib.parse import urlsplit

from socket_deadline import SocketDeadline
from slots_transport import bounded_slots
from cancel_seed_stream import capture
from native_block import TraceSlice
from native_task_log import SLOT,CANCEL,canceled_task

def prefix_hash(ids):
    # Exact a1 server FNV seed (NOT the conventional FNV offset constant).
    value=1469598103934665603
    for token in ids:
        if type(token) is not int or not 0<=token<2**32:raise ValueError('bad native token id')
        for shift in (0,8,16,24):
            value^=(token>>shift)&255
            value=(value*1099511628211)&((1<<64)-1)
    return f'{value:016x}'

def relevant_log(path,start,end):
    """Stream raw native bytes; retain task/error lines, not whole debug grids."""
    out=[]
    with open(path,'rb') as stream:
        stream.seek(start)
        while stream.tell()<end:
            raw=stream.readline(end-stream.tell())
            if not raw or not raw.endswith(b'\n'):break
            line=raw.decode('utf-8',errors='strict')
            if SLOT.search(line) or CANCEL.search(line) or re.match(r'^\s*(?:[0-9]+(?:\.[0-9]+)+\s+){1,2}E\s',line) or any(
                word in line for word in ('failed to process speculative batch','decode() failed:','post_decode() failed:')):
                out.append(line)
    return out

def pid_owns_port(pid, port):
    """Prove this process holds a listening socket on the requested port."""
    inodes = set()
    for name in ("/proc/net/tcp",):
        try:
            for line in Path(name).read_text().splitlines()[1:]:
                fields = line.split()
                if len(fields) > 9 and fields[3] == "0A" and fields[1] == f"0100007F:{port:04X}":
                    inodes.add(fields[9])
        except (OSError, ValueError, IndexError):
            continue
    if not inodes:
        return False
    try:
        for fd in Path(f"/proc/{pid}/fd").iterdir():
            try:
                target = os.readlink(fd)
            except OSError:
                continue
            if target.startswith("socket:[") and target[8:-1] in inodes:
                return True
    except OSError:
        return False
    return False

class SeedControl:
    def __init__(self,*,delay_s=.05,trigger_processed=31744):
        self.delay_s=delay_s;self.trigger_processed=trigger_processed

    def __call__(self,*,gate,ctx,R,srv,slot,source_ids,checkpoint,n_predict,control,attempt):
        ctx.check_boundary()
        if slot!=1 or len(source_ids)!=32512 or checkpoint!=32000 or n_predict!=256 or not 1<=attempt<=3:
            raise gate.Abort('unapproved native canceled-seed shape')
        address=urlsplit(ctx.client.base)
        if address.scheme!='http' or address.hostname!='127.0.0.1' or address.port!=ctx.args.port:
            raise gate.Abort('canceled seed must use exact own local server')
        if srv.proc is None or srv.proc.poll() is not None or not pid_owns_port(srv.proc.pid,address.port):
            raise gate.Abort('own native server identity lost')
        before={s['id']:s for s in bounded_slots(ctx)}[slot]
        if before.get('is_processing') or before.get('n_prompt_tokens')!=0 or (before.get('kv_cells') or {}).get('private')!=0:
            raise gate.Abort('canceled seed slot not independently empty')
        directory=ctx.out/'construction'/f'Cmask{control}-attempt{attempt}'
        directory.mkdir(parents=True,exist_ok=False)
        raw_path=directory/'native-sse.raw'
        record_path=directory/'seed.json'
        body={**gate.body_for(source_ids,n_predict,slot,fork=False,ckpt=[checkpoint],n_probs=20),
              'stream':True,'return_progress':True}
        started=time.time();log_start=Path(srv.log).stat().st_size
        identity=None;binding=None;response=None;captured_socket=None;transport_closed=False;client_error=None;cap=None
        connection=http.client.HTTPConnection(address.hostname,address.port,
            timeout=min(180.,max(1.,ctx.deadline.remaining())))
        def close_transport():
            nonlocal transport_closed
            if transport_closed:return
            transport_closed=True
            # Captured own socket only. RST makes disconnect visible promptly;
            # the server's native cancellation/release remains separate proof.
            if captured_socket is not None:
                try:captured_socket.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0))
                except OSError:pass
                try:captured_socket.shutdown(socket.SHUT_RDWR)
                except OSError as error:
                    if error.errno not in (errno.ENOTCONN,errno.EBADF):raise
            if response is not None:response.close()
            connection.close()
        def bind_task(event):
            nonlocal identity,binding
            ctx.check_boundary()
            current={s['id']:s for s in bounded_slots(ctx)}[slot]
            if not current.get('is_processing') or type(current.get('id_task')) is not int:
                raise gate.Abort('no current seed native task')
            identity=current['id_task'];binding=current
            return identity
        try:
            ctx.check_boundary()
            transport_budget=min(180.,ctx.deadline.remaining())
            if transport_budget<=0:raise gate.Abort('seed transport deadline expired before connect')
            transport_deadline=time.monotonic()+transport_budget
            connection.timeout=transport_budget
            connection.connect()
            captured_socket=connection.sock
            with SocketDeadline(captured_socket,transport_deadline) as watchdog:
                connection.request('POST','/completion',body=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
                response=connection.getresponse()
                if response.status!=200:raise gate.Abort(f'canceled seed HTTP{response.status}')
                with open(raw_path,'xb') as raw:
                    def write_raw(line):raw.write(line);raw.flush()
                    def lines():
                        while True:
                            line=response.readline()
                            if not line:return
                            yield line
                    cap=capture(lines=lines(),close_transport=close_transport,capture_task_identity=bind_task,
                        write_raw=write_raw,deadline_check=ctx.check_boundary,slot_id=slot,
                        trigger_processed=self.trigger_processed,delay_s=self.delay_s)
                watchdog.check()
        except Exception as error:
            client_error=f'{type(error).__name__}: {error}'
        finally:
            close_transport()
            # Raw capture exists on every normal path, including refusals.
            if not raw_path.exists():raw_path.touch(exist_ok=False)
        # The socket close is NOT a release acknowledgment. No next model
        # request is made until the same native task is observably idle.
        until=time.monotonic()+10.;after=None
        while time.monotonic()<until:
            ctx.check_boundary()
            after={s['id']:s for s in bounded_slots(ctx, deadline=until)}[slot]
            if identity is not None and after.get('id_task')==identity and not after.get('is_processing'):break
            time.sleep(.05)
        else:
            gate.write_json(record_path,{'body':body,'client_error':client_error,'task_binding':binding,'after':after,
                                         'raw_sse':str(raw_path),'refusal':'native cancellation not acknowledged'})
            raise gate.Abort('native seed cancellation did not become idle in10s')
        # Wait only for our pump to record the already-observed native release;
        # this is not a model wait and cannot create a missing release.
        until=time.monotonic()+2.;log_end=Path(srv.log).stat().st_size;task_lines=[]
        while True:
            ctx.check_boundary();log_end=Path(srv.log).stat().st_size
            task_lines=relevant_log(srv.log,log_start,log_end)
            if any((m:=SLOT.search(line)) and int(m[2])==slot and int(m[3])==identity and m[1]=='release' for line in task_lines):break
            if time.monotonic()>=until:break
            time.sleep(.02)
        events=[]
        with open(raw_path,'rb') as raw:
            for line in raw:
                if line.startswith(b'data:') and line[5:].strip() not in (b'',b'[DONE]'):
                    events.append(json.loads(line[5:].strip()))
        error_lines=[line for line in task_lines if re.match(r'^\s*(?:[0-9]+(?:\.[0-9]+)+\s+){1,2}E\s',line) or any(
            word in line for word in ('failed to process speculative batch','decode() failed:','post_decode() failed:'))]
        if client_error:error_lines.append('client construction refusal: '+client_error)
        cancellation=any((m:=CANCEL.search(line)) and int(m[1])==identity for line in task_lines)
        native_witness=None;native_refusal=None
        try:native_witness=canceled_task(task_lines,task_id=identity,slot_id=slot,T=checkpoint)
        except Exception as error:native_refusal=f'{type(error).__name__}: {error}'
        generation=bool(after.get('n_prompt_tokens',0)>=len(source_ids) or any(
            token>=0 for ev in events for token in ev.get('tokens',[]) if type(token) is int))
        record={'schema':'epyc.kpf18.canceled-seed-attempt.v1','body':body,'request_slot':slot,'own_server_pid':srv.proc.pid,
                'seed_task_id':identity,'task_binding':binding,'postcancel_slot':after,'events':events,
                'client_capture':cap,'client_error':client_error,'raw_sse':str(raw_path),'raw_sse_sha256':gate.sha256_file(raw_path),
                'native_task_witness':native_witness,'native_refusal':native_refusal,
                'native_log_span':{'path':str(srv.log),'start':log_start,'end':log_end},
                'actual_prefix_hash':after.get('prefix_hash'),'expected_prefix_hash':prefix_hash(source_ids[:checkpoint]),
                'start':started,'end':time.time(),'control':control,'attempt':attempt,
                'native_geometry_admitted':False,'note':'geometry is observed separately at PRE-mask allocation'}
        gate.write_json(record_path,record)
        R.rows.add({'event':'native_canceled_seed_attempt','record':str(record_path),'record_sha256':gate.sha256_file(record_path)})
        return {'slot':after,'seed_task_id':identity,'events':events,'raw_record_path':str(record_path),
                'expected_prefix_hash':record['expected_prefix_hash'],'current_task_generation_entered':generation,
                'source_error_lines':error_lines,'observed_cancel_task':bool(cancellation and native_witness),
                'seed_trace':TraceSlice(srv.log,log_start,log_end)}
