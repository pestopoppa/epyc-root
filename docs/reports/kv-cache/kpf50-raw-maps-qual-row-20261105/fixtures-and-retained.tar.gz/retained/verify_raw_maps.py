#!/usr/bin/env python3
"""Offline raw /proc maps custody checks. Never certifies collection or residency."""
import argparse, hashlib, json, re, sys
from pathlib import Path
SOURCE='1e8a6d5da9836a27e8f1d2010a02e6cebd95abdc'
def need(ok, message):
    if not ok: raise ValueError(message)
def sha(data): return hashlib.sha256(data).hexdigest()
def integer(x): return type(x) is int
class Evidence:
    def __init__(self, root): self.root=root.resolve()
    def read(self, ref):
        need(isinstance(ref,dict) and set(ref)=={'path','sha256'}, 'artifact reference')
        need(isinstance(ref['path'],str) and not Path(ref['path']).is_absolute(),'relative path required')
        p=(self.root/ref['path']).resolve();need(p.is_relative_to(self.root),'bundle escape')
        data=p.read_bytes();need(sha(data)==ref['sha256'],'artifact hash: '+ref['path']);return data

def proc_stat(data):
    # comm may contain spaces and ')' so split at the final close parenthesis.
    text=data.decode('ascii'); left, right=text.rsplit(')',1)
    pid=int(left.split(' (',1)[0]); fields=right.split()
    need(len(fields)>=20,'short proc stat');return pid,int(fields[19]) # field 22

def maps_rows(data):
    rows=[]
    for line in data.decode('utf-8',errors='strict').splitlines():
        m=re.fullmatch(r'([0-9a-f]+)-([0-9a-f]+) ([rwxps-]{4}) ([0-9a-f]+) ([0-9a-f]+):([0-9a-f]+) ([0-9]+)(?: +(.*))?',line)
        need(m is not None,'malformed maps row');a,b,perm,off,major,minor,ino,path=m.groups()
        need(int(a,16)<int(b,16),'maps address range')
        rows.append(dict(range=a+'-'+b,permissions=perm,offset=int(off,16),major=int(major,16),minor=int(minor,16),inode=int(ino),path=path or ''))
    need(rows,'empty maps');return rows

def verify(root, manifest, candidate):
    e=Evidence(root)
    need(manifest['schema']=='epyc.kpf50.raw-maps.v1','schema')
    need(type(manifest['synthetic']) is bool,'synthetic flag')
    need(candidate['source_commit']==SOURCE,'candidate source')
    need(candidate['schema']=='epyc.kpf50.candidate-map-policy.v1','candidate policy schema')
    # An external seal establishes which bytes were reviewed, not truth of a build receipt.
    receipt=json.loads(e.read(manifest['candidate_receipt']))
    need(receipt['source_commit']==SOURCE and receipt['artifacts']==candidate['artifacts'],'candidate build receipt identity')
    need(receipt['synthetic'] is manifest['synthetic'],'receipt classification')
    pid=manifest['pid'];birth=manifest['starttime_ticks']
    need(integer(pid) and pid>0 and integer(birth) and birth>0,'PID birth')
    need(re.fullmatch(r'[0-9a-f-]{36}',manifest['boot_id']) is not None,'boot ID')
    need(manifest['clock']=='CLOCK_MONOTONIC','unsupported time domain')
    hz=manifest['clock_ticks_per_second'];need(integer(hz) and hz>0,'CLK_TCK')
    begin,end=manifest['window_ns'];attempt=manifest['attempt_start_ns']
    need(all(integer(x) for x in (begin,end,attempt)) and 0<=attempt<begin<end,'prospective attempt/window')
    captures=manifest['captures'];need(len(captures)>=2,'bracketing captures required')
    spans=[]; parsed=[]
    for c in captures:
        lo,hi=c['capture_ns'];need(integer(lo) and integer(hi) and attempt<=lo<=hi,'capture bracket')
        # Linux starttime is ticks since boot; conservative full tick must precede capture.
        need((birth+1)*1000000000<=lo*hz,'capture predates birth')
        need(c['boot_id']==manifest['boot_id'],'boot changed')
        need(proc_stat(e.read(c['stat_before']))==(pid,birth),'before PID lifetime')
        need(proc_stat(e.read(c['stat_after']))==(pid,birth),'after PID lifetime')
        rows=maps_rows(e.read(c['maps']));parsed.append(rows);spans.append((lo,hi))
        witnesses=c['mapped_files'];need(set(witnesses)==set(candidate['artifacts']),'missing mapped-file witness')
        for name,w in witnesses.items():
            expected=candidate['artifacts'][name]
            need(re.fullmatch('[0-9a-f]{64}',expected['sha256']) is not None,'candidate hash')
            # Bytes must be copied from open /proc/PID/map_files/RANGE handle, not pathname lookup.
            need(w['open_source']=='/proc/'+str(pid)+'/map_files/'+w['range'],'map_files source')
            matches=[r for r in rows if r['range']==w['range']]
            need(len(matches)==1,'mapped range join');r=matches[0]
            need(r['inode']>0 and not r['path'].endswith(' (deleted)'),'deleted/anonymous mapping')
            need(r['path']==expected['path'],'candidate mapped pathname')
            st=json.loads(e.read(w['fstat']))
            need(st['inode']==r['inode'] and st['device_major']==r['major'] and st['device_minor']==r['minor'],'mapped inode/device mismatch')
            need(integer(st['size']) and st['size']>0,'mapped file size')
            blob=e.read(w['bytes']);need(len(blob)==st['size'] and sha(blob)==expected['sha256'],'mapped content mismatch')
            need(w['capture_ns']==c['capture_ns'],'file capture bracket mismatch')
    need(spans==sorted(spans),'capture order')
    need(spans[0][1]<=begin and spans[-1][0]>=end,'window not bracketed')
    need(any(begin<=lo<=hi<=end for lo,hi in spans),'no during-window maps')
    return {'schema':'epyc.kpf50.raw-maps-result.v1','status':'SYNTHETIC_CONTROL_ONLY' if manifest['synthetic'] else 'UNKNOWN','custody_checks':'consistent','physical_provenance':'UNKNOWN: offline raw bytes and asserted capture envelopes cannot authenticate collector, map_files handle origin, timestamp acquisition or uninterrupted process lifetime','source_commit':SOURCE,'pid':pid,'starttime_ticks':birth,'residency':'UNKNOWN: maps do not prove GPU residency','gate_verdict':'UNRESOLVED'}

def main():
    p=argparse.ArgumentParser();p.add_argument('bundle',type=Path);p.add_argument('--candidate-policy',type=Path,required=True);p.add_argument('--candidate-policy-sha256',required=True);a=p.parse_args()
    try:
        raw=a.candidate_policy.read_bytes();need(sha(raw)==a.candidate_policy_sha256,'external policy seal')
        r=verify(a.bundle,json.loads((a.bundle/'raw-maps.json').read_text()),json.loads(raw));print(json.dumps(r,sort_keys=True));return 0 if r['status']=='SYNTHETIC_CONTROL_ONLY' else 3
    except (ValueError,KeyError,TypeError,OSError,UnicodeError,OverflowError) as ex:
        print(json.dumps({'status':'UNKNOWN','custody_checks':'REFUSED','reason':str(ex),'physical_provenance':'UNKNOWN','gate_verdict':'UNRESOLVED'}));return 3
if __name__=='__main__':sys.exit(main())
