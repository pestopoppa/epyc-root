# KPF50 raw residency verifier preparation, 2026-11-05

This isolated, offline package inspects raw own-PID `/proc/<pid>/stat`, descriptor
readlink captures and DRM `fdinfo`. It does not collect target evidence. Invoke
`python3 verify_residency.py BUNDLE`, where BUNDLE contains `residency.json`
and its sealed artifacts. Every invocation returns UNKNOWN (exit 3): this is an
evidence component inspector, not a native physical provenance qualification.

The manifest format is demonstrated by `controls/residency.json`. Each raw
reference supplies path, exact source and SHA-256. Capture brackets cover the
entire stat/FD/stat collection and declare CLOCK_MONOTONIC, matching the target
step. Two distinct nonoverlapping capture intervals must fit wholly within the
step; samples after or straddling the step never count. No arbitrary sampling
frequency, clock uncertainty threshold or observation duration is introduced.
The step interval must be independently joined to the first qualifying native
KPF50_STEP; this package does not authenticate that join.

PID starttime is parsed from field 22 of raw stat, including comm strings with
spaces or closing parentheses. Both before and after stat must match the exact
PID and expected starttime ticks. Actual boot identity remains unproved. A raw
readlink `/dev/kfd` establishes only descriptor openness. DRM fdinfo must name
the selected PCI BDF and client ID; positive `drm-memory-vram` accepts explicit
B/KiB/MiB/GiB. Duplicate DRM client descriptors are counted once per capture.
Absent or unsupported memory accounting remains null, never zero. A missing
KFD FD or nonpositive accounting cannot satisfy a candidate sample.

Neither caller-provided JSON nor raw text is trusted merely because its digest
matches. This package cannot authenticate sampler executable/source identity,
collector process, capture clocks, boot identity, BDF-to-device identity,
producer honesty or active KFD queues. The selected identity is retained as a
required policy field but is not physically validated. Even two candidate
samples remain UNKNOWN; a descriptor and VRAM bytes cannot establish model
placement or dispatch execution. There is deliberately no native PASS escape
hatch and no flag that converts producer assertions into provenance.

`controls/` is explicitly synthetic. It includes a positive-shaped carrier and
negative controls for after-step, straddling, duplicate capture, wrong PID birth,
wrong BDF, missing KFD, unsupported clock, missing sample, and producer-asserted
native identity. Each must remain UNKNOWN; malformed evidence also remains
UNKNOWN. Copy the desired control manifest to `residency.json` in an isolated
copy of controls to inspect it. Controls were generated, not executed. No tests,
compute, target access, publication, commit, repository edits, waits or polling
were performed. `seals.json` records package byte custody, not authenticity.

This component follows the PREDECLARED residency requirement in
`/mnt/raid0/llm/tmp/heterogeneous-slot-fabric-residency/kpf50-row-20261104`
and complements `docs/reports/kv-cache/kpf50-window-validator-prep-20261105`.
It does not remove that validator's UNKNOWN restriction for maps, shapes,
freshness, clocks or native physical provenance, and makes no performance or
20 percent gate claim.
