#!/usr/bin/env python3
"""Writes synthetic fixtures only. Does not execute the verifier or any tests."""
import copy
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent/'controls'
root.mkdir(exist_ok=True)
def artifact(name,source,text):
    (root/name).write_text(text)
    return {'path':name,'source':source,'sha256':hashlib.sha256(text.encode()).hexdigest()}
pid=12345
# Fields 3..21 followed by field 22 starttime, then optional later fields.
stat=f'{pid} (synthetic server) '+' '.join(['S']+['0']*18+['900']+['0']*4)+'\n'
statref=artifact('stat.txt',f'/proc/{pid}/stat',stat)
kfd=artifact('fd3-link.txt',f'/proc/{pid}/fd/3:readlink','/dev/kfd\n')
drm=artifact('fd4-link.txt',f'/proc/{pid}/fd/4:readlink','/dev/dri/renderD128\n')
info=artifact('fd4-info.txt',f'/proc/{pid}/fdinfo/4','pos:\t0\nflags:\t02000002\ndrm-pdev:\t0000:01:00.0\ndrm-client-id:\t7\ndrm-memory-vram:\t1024 KiB\n')
def sample(lo,hi):
    return {'clock':'CLOCK_MONOTONIC','before_ns':lo,'after_ns':hi,'stat_before':statref,'stat_after':statref,'fds':[{'fd':3,'link':kfd},{'fd':4,'link':drm,'fdinfo':info}]}
m={'schema':'epyc.kpf50.raw-residency.v1','synthetic':True,'pid':pid,'pid_starttime_ticks':900,
   'selected_device':{'bdf':'0000:01:00.0','identity':'SYNTHETIC identity, never a physical proof'},
   'step':{'clock':'CLOCK_MONOTONIC','start_ns':100,'end_ns':200},'samples':[sample(110,120),sample(130,140)]}
def write(name,obj):
    (root/name).write_text(json.dumps(obj,indent=2)+'\n')
write('residency.json',m)
cases=[]
for name,change in [
    ('after-step',lambda x:x['samples'][1].update(before_ns=201,after_ns=210)),
    ('straddle-step',lambda x:x['samples'][1].update(before_ns=190,after_ns=210)),
    ('same-capture',lambda x:x['samples'].__setitem__(1,copy.deepcopy(x['samples'][0]))),
    ('wrong-birth',lambda x:x.update(pid_starttime_ticks=901)),
    ('wrong-bdf',lambda x:x['selected_device'].update(bdf='0000:02:00.0')),
    ('missing-kfd',lambda x:x['samples'][1].update(fds=x['samples'][1]['fds'][1:])),
    ('unsupported-clock',lambda x:x['samples'][1].update(clock='unattested')),
    ('missing-sample',lambda x:x.update(samples=x['samples'][:1])),
    ('untrusted-native',lambda x:x.update(synthetic=False)),
]:
    x=copy.deepcopy(m);change(x);write(name+'.json',x)
    cases.append({'fixture':name+'.json','expected_status':'UNKNOWN','native_verified':False})
write('expectations.json',{'not_executed':True,'positive_shaped_fixture_also_UNKNOWN':True,'negative_controls':cases})
