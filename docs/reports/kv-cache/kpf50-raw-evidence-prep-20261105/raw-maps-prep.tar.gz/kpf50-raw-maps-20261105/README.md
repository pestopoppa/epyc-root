# KPF50 raw maps preparation — no native certification

Source-bound to `1e8a6d5da9836a27e8f1d2010a02e6cebd95abdc`, the original
`kpf50-row-20261104/PREDECLARED.md` and
`docs/reports/kv-cache/kpf50-window-validator-prep-20261105`.

`verify_raw_maps.py BUNDLE --candidate-policy POLICY --candidate-policy-sha256 HASH`
is an offline component. Supply a separately reviewed and sealed policy, never one
inferred from observed receipts. It reads raw `/proc/PID/maps` and `/proc/PID/stat`
bytes from the bundle, parses kernel PID starttime (field 22), requires the same
PID birth/boot across before/after snapshots, a prospective attempt marker,
CLOCK_MONOTONIC capture envelopes before/during/after the target window, and
mapped-library bytes bound through a `/proc/PID/map_files/RANGE` open-handle
witness to the raw mapping range/device/inode and candidate SHA-256 policy.
The bundled candidate build receipt must match the complete policy artifact set
and the exact source commit. Policy artifact names should include every required
server/library identity, including HIP; this component verifies the complete
supplied set but cannot decide whether a separately reviewed policy is complete.

A mapping address is a virtual process address. It is not physical K/V layout or
GPU residency. fstat JSON, sampler timestamps, clock rate and open-source strings
remain asserted carrier metadata; matching them cannot authenticate the producer,
the actual handle, timestamp acquisition, or uninterrupted process lifetime.
There is deliberately no native PASS path: consistent native evidence returns
UNKNOWN (exit 3), and absent, malformed or inconsistent evidence returns
UNKNOWN/REFUSED (exit 3). Only explicitly synthetic controls can return exit 0.
No producer attestation or independently trusted acquisition channel exists in
these source packages, so the verifier cannot invent physical provenance.
Independent collector provenance review remains necessary before changing this
boundary; a caller-supplied 'trusted' flag must never clear it.

Controls are artificial files produced by `make_controls.py`, sealed individually
in `controls/seals.json`. They include a positive-shaped artificial carrier and
mutation specifications for PID reuse, late attempt marker, missing in-window
capture, inode mismatch, wrong bytes, missing receipt, escape, wrong source and
native UNKNOWN. No control or verifier has been run. Generation only writes
artificial fixtures and computes file hashes; it does not sample the target.

This component does not replace four-window order, first qualifying native step,
clock/dispatch validation, shape/fork provenance, KFD/VRAM proof, full-window
comparison or independent cleanup supervision. No native evidence, performance
result, >=20% gate outcome, or production authorization is created here.
