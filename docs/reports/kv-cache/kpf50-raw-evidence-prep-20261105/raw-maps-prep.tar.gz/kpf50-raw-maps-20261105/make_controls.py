#!/usr/bin/env python3
"""Generate sealed artificial fixtures; does not run verifier or touch /proc."""
import hashlib,json
from pathlib import Path
from verify_raw_maps import SOURCE
root=Path(__file__).parent/'controls';root.mkdir(exist_ok=True)
def write(name,data):
    if not isinstance(data,bytes):data=(json.dumps(data,sort_keys=True,indent=2)+'\n').encode()
    (root/name).write_bytes(data);return {'path':name,'sha256':hashlib.sha256(data).hexdigest()}
blob=b'SYNTHETIC NOT ELF NOT NATIVE\n';blobref=write('fake-lib.bin',blob)
policy={'schema':'epyc.kpf50.candidate-map-policy.v1','source_commit':SOURCE,'artifacts':{'libggml-hip.so':{'path':'/synthetic/libggml-hip.so','sha256':blobref['sha256']}}}
policyref=write('candidate-policy.json',policy)
receipt=write('candidate-receipt.json',{'synthetic':True,'source_commit':SOURCE,'artifacts':policy['artifacts']})
stat=write('proc-stat.txt',('123 (synthetic fake) '+' '.join(['S']+['0']*18+['1']+['0']*8)+'\n').encode())
maps=write('proc-maps.txt',b'1000-2000 r-xp 00000000 08:01 42 /synthetic/libggml-hip.so\n')
fstat=write('fstat.json',{'inode':42,'device_major':8,'device_minor':1,'size':len(blob)})
boot='00000000-0000-0000-0000-000000000000'
captures=[]
for lo,hi in ((100000000,110000000),(140000000,150000000),(190000000,200000000)):
    captures.append({'capture_ns':[lo,hi],'boot_id':boot,'stat_before':stat,'stat_after':stat,'maps':maps,'mapped_files':{'libggml-hip.so':{'range':'1000-2000','open_source':'/proc/123/map_files/1000-2000','fstat':fstat,'bytes':blobref,'capture_ns':[lo,hi]}}})
write('raw-maps.json',{'schema':'epyc.kpf50.raw-maps.v1','synthetic':True,'candidate_receipt':receipt,'pid':123,'starttime_ticks':1,'boot_id':boot,'clock':'CLOCK_MONOTONIC','clock_ticks_per_second':100,'attempt_start_ns':90000000,'window_ns':[120000000,180000000],'captures':captures})
write('mutations.json',[
{'name':'native-label','change':'set synthetic and candidate receipt synthetic false; reseal modified receipt','expected':'UNKNOWN even if consistent'},
{'name':'PID-reuse','change':'change stat_after field 22','expected':'UNKNOWN/REFUSED'},
{'name':'late-attempt','change':'attempt_start_ns = 130000000','expected':'UNKNOWN/REFUSED'},
{'name':'missing-during','change':'remove middle capture','expected':'UNKNOWN/REFUSED'},
{'name':'inode-mismatch','change':'change fstat inode and update its artifact hash','expected':'UNKNOWN/REFUSED'},
{'name':'wrong-library','change':'replace fake-lib bytes and update reference hash without changing external policy','expected':'UNKNOWN/REFUSED'},
{'name':'missing-receipt','change':'delete candidate_receipt','expected':'UNKNOWN/REFUSED'},
{'name':'path-escape','change':'maps path = ../outside','expected':'UNKNOWN/REFUSED'},
{'name':'wrong-source','change':'candidate source differs from source-bound constant','expected':'UNKNOWN/REFUSED'}])
seals={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.iterdir()) if p.is_file() and p.name!='seals.json'}
write('seals.json',seals)
print('Generated artificial controls only; verifier was not executed.')
