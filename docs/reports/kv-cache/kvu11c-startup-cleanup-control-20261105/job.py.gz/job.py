#!/usr/bin/env python3
"""Model-free four-CPU qualification smoke or one bounded TTS GPU mechanics run."""
import ctypes, base64, hashlib, json, os, signal, subprocess, sys, time, urllib.request, wave, struct
from pathlib import Path

D=Path(__file__).resolve().parent
BUILD=Path('/mnt/raid0/llm/tmp/heterogeneous-slot-fabric-residency/kvu11c-startup-cleanup-control-prep-20261105/candidate')
B=BUILD/'build'; RECEIPT=D/'build-receipt.json'
TALKER=Path('/mnt/raid0/llm/models/Qwen3-TTS-qwentts/qwen-talker-0.6b-base-Q8_0.gguf')
CODEC=Path('/mnt/raid0/llm/models/Qwen3-TTS-qwentts/qwen-tokenizer-12hz-Q8_0.gguf')
REF_ARCHIVE=D/'reference.wav'
REF_MEMBER='rec-u-0001.wav'
REF_SHA256='84e1801ec61153c2b40d1bb05f01492f8d5873d46ae33435cf968cc6cb552bca'
PINS_FILE=D/'pins.json'
PINS_FILE_SHA256='e4def906c359e3d2533da02f70ac30da7fc49f28bf2f9fa4e72723e2c283359f'
MODEL_RECEIPT=D/'model-preverify.json'
MODEL_RECEIPT_BODY_SHA256='805a3cae59ceb47677ce9d3845f9bc25cd858cd30c36e26da36ccf1de0e2f012'
MODEL_RECEIPT_FILE_SHA256='74cf44448eac10724eb71427707d8194824080e2997e28e2ed44ac33ae0b9d4d'
MODEL_SHA256={str(TALKER):'d54dbaf10591421fa764ed630d764efa717ae40cd959bd48c66d4eb1af226426',
              str(CODEC):'1883beeed99348fc35e23dd225e9082f93f6f8c109330a33d935baa8acdbfd94'}
MODEL_STAT_SNAPSHOT={str(TALKER):{'device':2431,'inode':98072488,'size':992615488,'mtime_ns':1785488569306102893,'ctime_ns':1785488569525976376},
                 str(CODEC):{'device':2431,'inode':98072490,'size':291150624,'mtime_ns':1785488596173518782,'ctime_ns':1785488596294923577}}
# This fixed identity came from the one-time out-of-grant hash receipt. Grant checks
# verify only this small receipt and stat metadata; they never hash model weights.
VOICE='kvu11c-fixed-reference'
TEXT='The mini CPM audio path is working.'
PORT=18209


def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def verify_build():
    assert sha(RECEIPT)=='6a20b41abb07e3efeb9c882420a5246940db90f6e6b44acf388e81e84396d999', 'build receipt drift'
    r=json.loads(RECEIPT.read_text())
    assert r.get('schema')=='kvu11c.hip-build.v1' and r.get('status')=='BUILT'
    assert r.get('qwentts_commit')=='aca703283192f892f1e85636fbc48832c4d5560a'
    assert r.get('ggml_commit')=='b86f660238dcc1a83b7cbf5a72d355a965de9245'
    assert 'gfx90a' in (B/'CMakeCache.txt').read_text()
    for name,want in r['files'].items():
        p=Path(name)
        assert p.is_file() and p.resolve().is_relative_to(B.resolve()) and sha(p)==want, name
    return r

def verify_model_pin_record():
    if not PINS_FILE.is_file() or sha(PINS_FILE)!=PINS_FILE_SHA256:
        raise RuntimeError('sealed historical model pin record missing or changed')
    pins=json.loads(PINS_FILE.read_text())
    tts=pins['tts_kernel_for_synthesized_stratum']
    if tts.get('talker')!=str(TALKER) or tts.get('codec')!=str(CODEC):
        raise RuntimeError('historical model pins name different model paths')
    if tts.get('render_run',{}).get('talker_sha256')!=MODEL_SHA256[str(TALKER)] or tts.get('render_run',{}).get('codec_sha256')!=MODEL_SHA256[str(CODEC)]:
        raise RuntimeError('sealed historical model SHA values differ from the packet constants')
    return pins

def verify_model_preverification():
    if not MODEL_RECEIPT.is_file() or sha(MODEL_RECEIPT)!=MODEL_RECEIPT_FILE_SHA256:
        raise RuntimeError('sealed out-of-grant model preverification receipt missing or changed')
    receipt=json.loads(MODEL_RECEIPT.read_text())
    seal=receipt.get('receipt_sha256'); body=dict(receipt); body.pop('receipt_sha256',None)
    computed=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if receipt.get('schema')!='kvu11c.model-preverify.v1' or seal!=computed or seal!=MODEL_RECEIPT_BODY_SHA256:
        raise RuntimeError('model preverification receipt seal mismatch')
    rows={row.get('path'):row for row in receipt.get('models',[])}
    if set(rows)!=set(MODEL_SHA256): raise RuntimeError('model preverification receipt has wrong model set')
    for path,want in MODEL_SHA256.items():
        row=rows[path]
        if row.get('sha256')!=want or row.get('historical_pin_sha256')!=want:
            raise RuntimeError(f'preverified model content disagrees with sealed historical pin: {path}')
        if row.get('pin_record_sha256')!=PINS_FILE_SHA256:
            raise RuntimeError(f'model hash is not bound to the sealed historical pin record: {path}')
        if row.get('stat_before')!=row.get('stat_after') or row.get('stat_before')!=MODEL_STAT_SNAPSHOT[path]:
            raise RuntimeError(f'model stat identity is not stable/sealed: {path}')
    return receipt

def preflight():
    # Deliberately model-free: checks only the existing candidate build receipt and binaries.
    r=verify_build()
    print(json.dumps({'status':'preflight_ok','build_receipt':str(RECEIPT),'files':len(r['files'])}))

def cpu_smoke():
    # Do not stat, open, hash, or otherwise touch either model in this branch.
    r=verify_build()
    out=Path(os.environ['FILLER_DRYRUN_RESULT_PATH'])
    out.parent.mkdir(parents=True,exist_ok=True)
    record={'schema':'kvu11c.gpu-mechanics.smoke.v1','status':'smoke_progress','progress_units':1,
            'progress_unit':'content-validated HIP candidate build receipt','build_receipt_sha256':sha(RECEIPT),
            'candidate_file_count':len(r['files']),'scope':'four-CPU smoke only; no model access, GPU access, or inference'}
    out.write_text(json.dumps(record,sort_keys=True)+'\n')
    print(json.dumps(record,sort_keys=True))

def gpu_smoke():
    """Bounded model-free HIP allocation for publisher smoke; never runs tts-server."""
    if os.environ.get('FILLER_SMOKE')!='1' or os.environ.get('FILLER_NEEDGPU')!='1' or os.environ.get('FILLER_DRYRUN')!='1':
        raise RuntimeError('model-free GPU witness requires publisher GPU smoke grant')
    smoke_target=Path(os.environ.get('FILLER_DRYRUN_RESULT_PATH',''))
    if not str(smoke_target) or not smoke_target.is_absolute() or smoke_target.resolve()==(D/'out'/'RESULT.json').resolve():
        raise RuntimeError('publisher smoke requires a separate absolute FILLER_DRYRUN_RESULT_PATH')
    import ctypes, threading
    build_receipt=verify_build()
    hip=ctypes.CDLL('/opt/rocm/lib/libamdhip64.so')
    def call(name,*args):
        fn=getattr(hip,name); fn.restype=ctypes.c_int
        rc=fn(*args)
        if rc: raise RuntimeError(f'{name} returned HIP status {rc}')
    call('hipInit',ctypes.c_uint(0))
    # Resolve the MI210 selected by this row to its HIP ordinal through PCI BDF.
    count=ctypes.c_int(); call('hipGetDeviceCount',ctypes.byref(count))
    nodes=Path('/sys/class/kfd/kfd/topology/nodes')
    candidates=[]
    for node in nodes.iterdir():
        props={}
        try:
            for line in (node/'properties').read_text().splitlines():
                k,_,v=line.partition(' '); props[k]=int(v,0)
        except (OSError,ValueError): continue
        if props.get('vendor_id')==0x1002 and props.get('device_id')==0x740f:
            loc=props['location_id']; domain=props.get('domain',0)
            bdf=f'{domain:04x}:{(loc>>8)&255:02x}:{(loc>>3)&31:02x}.{loc&7:x}'
            candidates.append((bdf,int((node/'gpu_id').read_text().strip()),str(node)))
    assert len(candidates)==1, f'expected exactly one MI210 KFD node, got {candidates}'
    bdf,gpu_id,node=candidates[0]
    get_bdf=hip.hipDeviceGetPCIBusId; get_bdf.restype=ctypes.c_int
    selected=None
    for ordinal in range(count.value):
        buf=ctypes.create_string_buffer(64)
        rc=get_bdf(buf,ctypes.c_int(len(buf)),ctypes.c_int(ordinal))
        if rc==0 and buf.value.decode().lower()==bdf.lower(): selected=ordinal
    assert selected is not None, f'MI210 {bdf} not visible through HIP'
    call('hipSetDevice',ctypes.c_int(selected))
    ptr=ctypes.c_void_p(); size=192*1024*1024
    call('hipMalloc',ctypes.byref(ptr),ctypes.c_size_t(size))
    freed=False; observations=[]
    try:
        call('hipMemset',ptr,ctypes.c_int(0x5a),ctypes.c_size_t(size))
        witness_start=time.monotonic(); deadline=min(witness_start+30,witness_start+max(0,float(os.environ.get('FILLER_DEADLINE',str(int(time.time())+30)))-time.time()))
        while time.monotonic()-witness_start<25 and time.monotonic()<deadline:
            check_run_limits()
            try: used=int(Path(f'/sys/class/kfd/kfd/proc/{os.getpid()}/vram_{gpu_id}').read_text().strip())
            except (OSError,ValueError): used=0
            observations.append({'monotonic_s':time.monotonic(),'pid':os.getpid(),'birth_ticks':proc_birth(os.getpid()),'gpu_id':gpu_id,'bdf':bdf,'vram_bytes':used})
            time.sleep(.2)
        positive=[x for x in observations if x['vram_bytes']>0]
        if len(positive)<2 or positive[-1]['monotonic_s']-positive[0]['monotonic_s']<24:
            raise RuntimeError('HIP residency witness did not span 24 seconds with two positive own-PID samples')
    finally:
        call('hipFree',ptr); freed=True
    progress={'schema':'kvu11c.gpu-mechanics.publisher-smoke.v1','status':'smoke_progress','progress_units':1,
              'progress_unit':'model-free selected-MI210 HIP allocation with own-PID KFD VRAM witness',
              'selected_device':{'gpu_id':gpu_id,'bdf':bdf,'kfd_node':node,'hip_ordinal':selected},
              'helper_pid':os.getpid(),'helper_birth_ticks':proc_birth(os.getpid()),'allocation_bytes':size,
              'witness_duration_s':positive[-1]['monotonic_s']-positive[0]['monotonic_s'],
              'build_receipt_sha256':sha(RECEIPT),'candidate_file_count':len(build_receipt['files']),
              'own_pid_vram_samples':observations,'hip_allocation_freed':freed,
              'scope':'publisher smoke only; target models were not opened, tts-server was not launched, no target RESULT.json'}
    smoke_target.parent.mkdir(parents=True,exist_ok=True)
    smoke_target.write_text(json.dumps(progress,sort_keys=True)+'\n')
    print(json.dumps(progress,sort_keys=True))

def proc_birth(pid):
    s=Path(f'/proc/{pid}/stat').read_text(); return int(s[s.rfind(')')+2:].split()[19])

def selected_mi210_gpu_id():
    found=[]
    for node in Path('/sys/class/kfd/kfd/topology/nodes').iterdir():
        props={}
        try:
            for line in (node/'properties').read_text().splitlines():
                key,_,value=line.partition(' '); props[key]=int(value,0)
        except (OSError,ValueError): continue
        if props.get('vendor_id')==0x1002 and props.get('device_id')==0x740f:
            found.append(int((node/'gpu_id').read_text().strip()))
    if len(found)!=1: raise RuntimeError('expected one exact MI210 KFD identity')
    return found[0]

def own_vram(pid):
    p=Path(f'/sys/class/kfd/kfd/proc/{pid}')
    vals=[]
    for f in [p/f'vram_{selected_mi210_gpu_id()}']:
        try: vals.append((f.name,int(f.read_text().strip())))
        except (OSError,ValueError): pass
    return vals

def request(url,method='GET',body=None):
    req=urllib.request.Request(url,data=body,method=method,headers={'Content-Type':'application/json'} if body else {})
    with urllib.request.urlopen(req,timeout=10) as response: return response.status,response.read()

def stat_identity(path):
    s=path.stat()
    return {'device':s.st_dev,'inode':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}

def check_run_limits():
    if STOP_SIGNAL is not None: raise RuntimeError(f'signal STOP {STOP_SIGNAL}')
    if Path(os.environ['FILLER_STOPFILE']).exists() or (D/'STOP').exists(): raise RuntimeError('STOP observed')
    hard=int(os.environ.get('FILLER_DEADLINE', str(int(os.environ['FILLER_END'])-90) if os.environ.get('FILLER_END') else str(int(time.time())+600)))
    if time.time()>=hard: raise RuntimeError('FILLER_DEADLINE reached')

class RunAbort(Exception): pass

def request_json(url,body):
    data=json.dumps(body,separators=(',',':')).encode()
    req=urllib.request.Request(url,data=data,method='POST',headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as response: return response.status,response.read()

def fixed_reference_wav():
    raw=(D/'reference.wav').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=REF_SHA256:
        raise RuntimeError('private fixed reference WAV seal mismatch')
    return raw

STOP_SIGNAL=None
OWNED={}
EXIT_CODES={}

def flag_stop(signum, frame):
    global STOP_SIGNAL
    STOP_SIGNAL=signum

def init_ownership():
    # Linux subreaper: orphaned descendants become our direct children, never
    # another session's. Signals only set a flag, including across Popen capture.
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER')
    if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
        raise RuntimeError('pidfd ownership support required')
    signal.signal(signal.SIGTERM,flag_stop); signal.signal(signal.SIGINT,flag_stop)

def capture(pid):
    if pid not in OWNED:
        birth=proc_birth(pid)
        fd=os.pidfd_open(pid)
        if proc_birth(pid)!=birth:
            os.close(fd); raise RuntimeError('child identity changed while capturing')
        OWNED[pid]=(birth,fd)

def spawn_owned(argv,**kwargs):
    child=subprocess.Popen(argv,**kwargs)
    capture(child.pid)
    return child

def discover_children():
    # Only this subreaper's direct children, including reparented descendants.
    for task in Path('/proc/self/task').iterdir():
        try: children=(task/'children').read_text().split()
        except FileNotFoundError: continue
        for value in children:
            try: capture(int(value))
            except ProcessLookupError: pass
            except FileNotFoundError: pass

def drain_owned():
    deadline=time.monotonic()+18
    while True:
        discover_children()
        live=[]
        for pid,(birth,fd) in list(OWNED.items()):
            try:
                # A zombie is reaped below; pidfds prevent PID reuse on signaling.
                if proc_birth(pid)!=birth: raise RuntimeError('owned PID birth changed')
                live.append((pid,fd))
            except FileNotFoundError:
                os.close(fd); del OWNED[pid]
        if not live: return
        sig=signal.SIGKILL if time.monotonic()>deadline-10 else signal.SIGTERM
        for pid,fd in live:
            try: signal.pidfd_send_signal(fd,sig)
            except ProcessLookupError: pass
            try:
                reaped,status=os.waitpid(pid,os.WNOHANG)
                if reaped: EXIT_CODES[pid]=os.waitstatus_to_exitcode(status)
            except ChildProcessError: pass
        if time.monotonic()>=deadline: raise RuntimeError('bounded owned-child drain failed')
        time.sleep(.05)

def run_owned(argv,env,stdout,stderr):
    child=spawn_owned(argv,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:
        while child.poll() is None:
            check_run_limits(); time.sleep(.1)
        if child.returncode!=0: raise subprocess.CalledProcessError(child.returncode,argv)
    finally:
        drain_owned()

def run_gpu():
    if os.environ.get('FILLER_NEEDGPU')!='1' or os.environ.get('FILLER_DRYRUN','0')!='0':
        raise RuntimeError('full execution requires explicit admitted GPU grant')
    if Path(os.environ['FILLER_STOPFILE']).exists(): raise RuntimeError('STOP already present')
    init_ownership()
    check_run_limits()
    r=verify_build()
    verify_model_pin_record()
    model_preverify=verify_model_preverification()
    # Grant-time custody is metadata-only; full model hashes are never recomputed.
    models_before={str(p):stat_identity(p) for p in (TALKER,CODEC)}
    if models_before!=MODEL_STAT_SNAPSHOT: raise RuntimeError('model stat identity differs from the captured stat snapshot')
    out=D/'out'; out.mkdir(exist_ok=True)
    server=B/'tts-server'; log=(out/'server.log').open('xb')
    env=os.environ.copy(); env['LD_LIBRARY_PATH']=f'{B}:/opt/rocm/lib'
    env['PATH']='/opt/rocm/bin:/usr/bin:/bin'
    with (out/'linkage.log').open('xb') as linkage_log:
        run_owned(['bash',str(D/'verify_ggml_linkage.sh'),str(server),str(B)],env,
                  stdout=linkage_log,stderr=subprocess.STDOUT)
    cmd=[str(server),'--model',str(TALKER),'--codec',str(CODEC),'--alias','kvu11c-gpu-smoke','--host','127.0.0.1','--port',str(PORT),'--lang','English','--threads',str(len(os.sched_getaffinity(0)))]
    p=None; birth=None; samples=[]; response_status=None; wav_bytes=None; failure=None; sampling=False; th=None
    deadline=min(time.monotonic()+600, time.monotonic()+max(0,int(float(os.environ.get('FILLER_DEADLINE',str(int(time.time())+600)))-time.time())))
    try:
        p=spawn_owned(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        birth=proc_birth(p.pid)
        healthy=False
        while time.monotonic()<deadline:
            check_run_limits()
            if p.poll() is not None: raise RuntimeError(f'tts-server exited early rc={p.returncode}')
            try:
                status,_=request(f'http://127.0.0.1:{PORT}/health')
                if status==200: healthy=True; break
            except Exception: pass
            time.sleep(.2)
        if not healthy: raise RuntimeError('server health timeout')
        # Exactly two during-residency samples; no registration, synthesis or output.
        for index in range(2):
            check_run_limits()
            if p.poll() is not None or proc_birth(p.pid)!=birth:
                raise RuntimeError('server identity lost during loaded control')
            status,_=request(f'http://127.0.0.1:{PORT}/health')
            if status!=200: raise RuntimeError('loaded health failed')
            samples.append({'monotonic_s':time.monotonic(),'pid':p.pid,'birth_ticks':birth,'vram':own_vram(p.pid)})
        live=[s for s in samples if any(n.startswith('vram_') and v>0 for n,v in s['vram'])]
        assert len(live)>=2, f'need at least two positive own-PID KFD VRAM samples, got {len(live)}'
        # Capture only mappings resolved from the candidate build directory.
        maps=Path(f'/proc/{p.pid}/maps').read_text()
        mapped=sorted({line.split()[-1] for line in maps.splitlines() if len(line.split())>=6 and '/libggml' in line and str(B) in line})
        assert any('libggml-base' in x for x in mapped) and any('libggml-hip' in x for x in mapped), 'candidate ggml-base/HIP mappings absent'
        models_after={str(p):stat_identity(p) for p in (TALKER,CODEC)}
        if models_before!=models_after: raise RuntimeError('model stat identity changed during run')
        check_run_limits()
        record={'schema':'kvu11c.gpu-startup-cleanup.v1','status':'startup_cleanup_pass','build_receipt_sha256':sha(RECEIPT),'build_files':r['files'],'model_preverify_receipt_sha256':model_preverify['receipt_sha256'],'preverified_model_sha256':MODEL_SHA256,'model_stat_identity_before':models_before,'model_stat_identity_after':models_after,'request_counts':{'voice_registration':0,'synthesis':0},'server':{'pid':p.pid,'birth_ticks':birth,'argv':cmd,'mapped_candidate_ggml':mapped,'own_pid_vram_samples':samples,'positive_samples':len(live),'clean_exit':None},'scope':'rebuilt candidate startup/loaded-health/cleanup only; distinct bytes from r3, no attribution to original crash'}
        # PASS remains in memory until the verified drain and final STOP check.
    except BaseException as e:
        failure=e
        raise
    finally:
        sampling=False
        if th is not None: th.join(timeout=2)
        try:
            drain_owned()
        finally:
            log.close()
        if p is not None:
            if p.pid in EXIT_CODES: p.returncode=EXIT_CODES[p.pid]
            else: p.poll()
        if failure is None:
            if p is None or p.returncode not in (0,-signal.SIGTERM):
                raise RuntimeError(f'owned server did not exit cleanly rc={p.returncode if p else None}')
            check_run_limits()
            record['server']['clean_exit']=True
            record['server']['exit_code']=p.returncode
            record['owned_children_drained']=True
            record['stop_observed']=False
            tmp=out/'RESULT.json.tmp'
            tmp.write_text(json.dumps(record,sort_keys=True)+'\n')
            check_run_limits()
            os.replace(tmp,out/'RESULT.json')


def complete():
    check_run_limits()
    if os.environ.get('FILLER_SMOKE')=='1' or os.environ.get('FILLER_DRYRUN')=='1':
        p=Path(os.environ['FILLER_DRYRUN_RESULT_PATH'])
        if not p.is_absolute() or p.resolve()==(D/'out/RESULT.json').resolve(): raise RuntimeError('invalid smoke result path')
        r=json.loads(p.read_text())
        if r.get('schema')!='kvu11c.gpu-mechanics.publisher-smoke.v1' or r.get('status')!='smoke_progress' or r.get('progress_units')!=1 or r.get('hip_allocation_freed') is not True or r.get('witness_duration_s',0)<24: raise RuntimeError('invalid publisher smoke')
        samples=r.get('own_pid_vram_samples',[])
        positive=[x for x in samples if x.get('pid')==r.get('helper_pid') and x.get('birth_ticks')==r.get('helper_birth_ticks') and x.get('vram_bytes',0)>0]
        if len(positive)<2 or positive[-1]['monotonic_s']-positive[0]['monotonic_s']<24: raise RuntimeError('invalid smoke residency witness')
        check_run_limits()
        return
    if (D/'out/FAILURE.json').exists(): raise RuntimeError('failed run cannot complete')
    p=D/'out/RESULT.json'
    if not p.is_file(): raise RuntimeError('full native mechanics result missing')
    r=json.loads(p.read_text())
    assert r.get('schema')=='kvu11c.gpu-startup-cleanup.v1' and r.get('status')=='startup_cleanup_pass'
    assert r['build_receipt_sha256']==sha(RECEIPT)
    assert r['request_counts']=={'voice_registration':0,'synthesis':0}
    assert r.get('owned_children_drained') is True and r.get('stop_observed') is False
    assert r['server']['clean_exit'] is True and r['server']['exit_code'] in (0,-signal.SIGTERM)
    assert r['server']['positive_samples']>=2
    assert all(s['pid']==r['server']['pid'] and s['birth_ticks']==r['server']['birth_ticks']
               for s in r['server']['own_pid_vram_samples'] if any(n.startswith('vram_') and v>0 for n,v in s['vram']))
    assert any('libggml-base' in x for x in r['server']['mapped_candidate_ggml'])
    assert any('libggml-hip' in x for x in r['server']['mapped_candidate_ggml'])
    assert r['preverified_model_sha256']==MODEL_SHA256
    assert r['model_preverify_receipt_sha256']==MODEL_RECEIPT_BODY_SHA256
    assert r['model_stat_identity_before']==MODEL_STAT_SNAPSHOT
    assert r['model_stat_identity_before']==r['model_stat_identity_after']

def main():
    signal.signal(signal.SIGTERM,flag_stop); signal.signal(signal.SIGINT,flag_stop)
    mode=sys.argv[1] if len(sys.argv)>1 else ''
    if mode=='--preflight': preflight()
    elif mode=='--complete': complete()
    elif os.environ.get('FILLER_SMOKE')=='1': gpu_smoke()
    elif os.environ.get('FILLER_DRYRUN')=='1': cpu_smoke()
    else:
        out=D/'out'; out.mkdir(exist_ok=True)
        if (out/'RESULT.json').exists() or (out/'FAILURE.json').exists():
            raise RuntimeError('single-use packet already has a terminal record')
        try:
            run_gpu()
        except BaseException as exc:
            (out/'RESULT.json').unlink(missing_ok=True)
            try: drain_owned()
            finally:
                (out/'FAILURE.json').write_text(json.dumps({'status':'failed','error':str(exc),'owned_exit_codes':EXIT_CODES,'build_receipt_sha256':sha(RECEIPT)})+'\n')
            raise
if __name__=='__main__': main()
