#!/usr/bin/env python3
"""Offline raw residency evidence inspector; custody is not authenticity."""
import argparse
import hashlib
import json
import re
from pathlib import Path

class Refusal(ValueError):
    pass

def require(value, reason):
    if not value:
        raise Refusal(reason)

def integer(x):
    return type(x) is int

def inspect(root, m):
    require(m['schema'] == 'epyc.kpf50.raw-residency.v1', 'schema')
    pid, birth = m['pid'], m['pid_starttime_ticks']
    require(integer(pid) and pid > 0 and integer(birth) and birth > 0, 'PID identity')
    step = m['step']
    require(step['clock'] == 'CLOCK_MONOTONIC' and integer(step['start_ns']) and integer(step['end_ns']) and 0 <= step['start_ns'] < step['end_ns'], 'unsupported step clock or interval')
    bdf = m['selected_device']['bdf']
    require(re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]', bdf) is not None, 'BDF')
    require(bool(m['selected_device']['identity']), 'device identity absent')
    root = root.resolve()
    def raw(ref, expected):
        require(ref['source'] == expected, 'wrong raw source: '+expected)
        p = (root / ref['path']).resolve()
        require(p.is_relative_to(root), 'artifact escapes bundle')
        data = p.read_bytes()
        require(hashlib.sha256(data).hexdigest() == ref['sha256'], 'artifact seal')
        return data.decode('utf-8')
    evidence, intervals = [], []
    for s in m['samples']:
        require(s['clock'] == step['clock'], 'sample clock mismatch')
        lo, hi = s['before_ns'], s['after_ns']
        require(integer(lo) and integer(hi) and 0 <= lo < hi, 'capture interval')
        # The complete raw capture, not merely a reported instant, must be during step.
        during = step['start_ns'] <= lo < hi <= step['end_ns']
        births = []
        for key in ('stat_before', 'stat_after'):
            stat = raw(s[key], f'/proc/{pid}/stat').strip()
            head, tail = stat.split(' (', 1)
            fields = tail.rsplit(') ', 1)[1].split()
            require(int(head) == pid and len(fields) >= 20, 'stat PID or truncation')
            births.append(int(fields[19]))  # field 22; tail begins at field 3
        require(births == [birth, birth], 'PID reused or birth mismatch')
        fds = s['fds']; require(type(fds) is list, 'FD list')
        kfd_open, vram = False, []
        clients = set()
        for fd in fds:
            n = fd['fd']; require(integer(n) and n >= 0, 'FD number')
            target = raw(fd['link'], f'/proc/{pid}/fd/{n}:readlink').strip()
            if target == '/dev/kfd':
                kfd_open = True
            if 'fdinfo' not in fd:
                continue
            info = raw(fd['fdinfo'], f'/proc/{pid}/fdinfo/{n}')
            pairs = {}
            for line in info.splitlines():
                if ':' in line:
                    key, val = line.split(':', 1)
                    require(key not in pairs, 'duplicate fdinfo field')
                    pairs[key] = val.strip()
            if pairs.get('drm-pdev') != bdf:
                continue
            require(target.startswith('/dev/dri/renderD') or target.startswith('/dev/dri/card'), 'DRM FD path')
            client = pairs.get('drm-client-id')
            require(client is not None and client.isdecimal(), 'DRM client identity')
            if client in clients:
                continue  # duplicated descriptors must never multiply memory
            clients.add(client)
            mem = pairs.get('drm-memory-vram', '')
            match = re.fullmatch(r'(\d+) (B|KiB|MiB|GiB)', mem)
            if match:
                vram.append(int(match[1]) * {'B':1,'KiB':1024,'MiB':1024**2,'GiB':1024**3}[match[2]])
        component = {'capture_interval_ns':[lo,hi], 'during_step':during,
                     'pid_birth_stable':True,'selected_bdf':bdf,
                     'kfd_fd_open':kfd_open,'drm_vram_bytes':sum(vram) if vram else None,
                     'positive_vram':bool(vram) and sum(vram)>0}
        evidence.append(component)
        if during and kfd_open and component['positive_vram']:
            intervals.append((lo,hi))
    intervals.sort()
    two = any(a[1] <= b[0] for i,a in enumerate(intervals) for b in intervals[i+1:])
    return {'schema':'epyc.kpf50.raw-residency-inspection.v1','status':'UNKNOWN',
            'native_verified':False,'synthetic':m.get('synthetic') is True,
            'two_disjoint_during_step_candidate_samples':two,'samples':evidence,
            'reasons':['Raw byte seals establish custody only; sampler identity, capture provenance, boot identity and clock provenance require independent authentication.',
                       'A /dev/kfd FD proves an open descriptor, not active KFD queues on the selected device.',
                       'DRM fdinfo VRAM accounting does not prove target dispatch execution or model tensor placement.'],
            'gate_verdict':'UNRESOLVED'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('bundle',type=Path)
    args=ap.parse_args()
    try:
        result=inspect(args.bundle,json.loads((args.bundle/'residency.json').read_text()))
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:
        result={'status':'UNKNOWN','native_verified':False,'reason':'missing, malformed or unsupported evidence: '+str(exc),'gate_verdict':'UNRESOLVED'}
    print(json.dumps(result,sort_keys=True))
    return 3

if __name__=='__main__':
    raise SystemExit(main())
