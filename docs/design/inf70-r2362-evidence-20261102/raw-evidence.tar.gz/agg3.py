#!/usr/bin/env python3
import sys
sys.path.insert(0, "/mnt/raid0/llm/tmp/inf70/agents/champion3")
import agg, json
agg.__dict__  # reuse loaders
Q = ["Q_P","Q_C1","Q_C3","Q_SH"]; R = ["R_P","R_C1","R_C3"]
print("### PER-ARM (confirmation window, pooled over 3 rounds)")
for a in Q+R:
    s = agg.summ(a)
    if s: print(json.dumps(s))
print("\n### PER-ROUND tps")
for a in Q+R:
    print(f"{a:<7}", [round(agg.tw(agg.dec(agg.load(f'{a}_r{r}'))),3) if agg.dec(agg.load(f'{a}_r{r}')) else None for r in (1,2,3)])
print("\n### PAIRED RATIOS")
for x,y in [("Q_P","Q_C1"),("Q_P","Q_C3"),("Q_C1","Q_C3"),("Q_SH","Q_C3"),("Q_C1","Q_SH"),
            ("R_P","R_C1"),("R_P","R_C3"),("R_C1","R_C3")]:
    v = agg.paired(x,y)
    if v: print(json.dumps(v))
