#!/bin/bash
# INF-70 CHAMPION-3 confirmation ABA on the SHIPPED binary (build 10241, shim default OFF).
# Arm order is ROTATED each round so no arm holds a fixed slot.
set -u
D=/mnt/raid0/llm/tmp/inf70/agents/champion3
A=$D/arm.sh
HEAD=/mnt/raid0/llm/models/unsloth/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf
MTP=(-md "$HEAD" --spec-type draft-mtp --spec-draft-n-max 4 --spec-draft-p-min 0.5)
FA=(-fa on -ctk f16 -ctv f16)
run(){ local lbl=$1 bin=$2 aenv=$3; shift 3
  [ -f "$D/runs/$lbl.rows.jsonl" ] && { echo "=== $lbl SKIP"; return 0; }
  echo "=== $lbl start $(date -u +%FT%TZ)"
  ARMENV="$aenv" CTX=8192 PORT=18497 bash "$A" "$lbl" "$D/$bin" "$@"
  echo "=== $lbl end rc=$? $(date -u +%FT%TZ)"; }
m(){ case $1 in
  Q_P)  run "Q_P_r$2"  bin-p  ""                          "${FA[@]}" "${MTP[@]}";;
  Q_C1) run "Q_C1_r$2" bin-c1 ""                          "${FA[@]}" "${MTP[@]}";;
  Q_C3) run "Q_C3_r$2" bin-c3 ""                          "${FA[@]}" "${MTP[@]}";;
  Q_SH) run "Q_SH_r$2" bin-c3 "GGML_NOHUGEPAGE_PROCESS=1" "${FA[@]}" "${MTP[@]}";;
esac; }
echo "### PHASE Q: MTP, 4 arms x 3 rounds, rotated order"
for a in Q_P  Q_C1 Q_C3 Q_SH; do m $a 1; done
for a in Q_SH Q_C3 Q_C1 Q_P ; do m $a 2; done
for a in Q_C1 Q_SH Q_P  Q_C3; do m $a 3; done
echo "### PHASE R: plain decode, 3 arms x 3 rounds, rotated order"
r(){ case $1 in
  R_P)  run "R_P_r$2"  bin-p  "" "${FA[@]}";;
  R_C1) run "R_C1_r$2" bin-c1 "" "${FA[@]}";;
  R_C3) run "R_C3_r$2" bin-c3 "" "${FA[@]}";;
esac; }
for a in R_P  R_C1 R_C3; do r $a 1; done
for a in R_C3 R_C1 R_P ; do r $a 2; done
for a in R_C1 R_P  R_C3; do r $a 3; done
echo "### ABA3 DONE $(date -u +%FT%TZ)"
