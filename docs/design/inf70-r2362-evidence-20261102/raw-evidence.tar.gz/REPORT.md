# INF-70 CHAMPION-3 — the champion rebuilt: V and Q folded in, the CHAMP-2 shim measured out

Agent `champion3`, 2026-09-07. Worktree `/mnt/raid0/llm/worktrees/inf70/champion2`, branch
**`inf70/champion3`** @ **`9c4f73e29`** (build id **10241**). **Committed, NOT pushed.**
`/mnt/raid0/llm/llama.cpp` (FROZEN, `0db32c06e`) was never touched, no branch was switched in a
shared clone, and nothing was written outside `/mnt/raid0/llm/`.

---

## 0. HEADLINE

**The champion is `6f032c48d` + `GGML_VEC_Q8K` + `GGML_QSPLIT` (multi-row only). The CHAMP-2
process-wide THP shim did NOT survive the fold: it is in the tree, correct and bit-identical, but
its default is OFF, because two independent same-window ABAs cannot agree that it helps at all.**

| MTP served — the number to quote | value |
|---|---|
| **champion-3, measured in-window** | **33.370 t/s · 29.967 ms per token** (window 3, the shipped binary) |
| | **34.433 t/s · 29.042 ms per token** (window 1, same configuration via the escape hatch) |
| **vs champion-1 `6f032c48d`, same window, paired** | **1.0427 (+4.27 %), 117 / 120 per-prompt wins** |
| **vs pristine `c51e4dabf`, same window, paired** | **1.4993 (+49.93 %), 120 / 120 wins** |
| **referred to the standing 35.407 t/s anchor** | **~36.9 t/s · ~27.1 ms per token** — a *projection*, see §6 |

Plain decode: **20.589 t/s · 48.569 ms per token**, **1.0568 over champion-1** (47/60) and
**1.7151 over pristine** (60/60).

**alpha is 0.8209 and drafted-per-token 0.8961 in every MTP arm of every binary in all three
windows.** Coherence is **20 COHERENT + 4 SHORT in every arm**; zero garbage, zero HTTP errors.
**No round and no arm was excluded from any number in this report.**

---

## 1. What was built, and how each default was set

Two clean merges onto `inf70/champion` @ `6f032c48d`, then two commits.

```
9c4f73e29  common: the CHAMP-2 process THP shim ships OPT-IN, not on      <- inf70/champion3
578cb6cc3  ggml-cpu: flip SYNC-15's V and Q on by default; QSPLIT multi-row only
1ef9824b6  Merge inf70/sync15  (56fe8ef0a)
a2dea1931  Merge inf70/champ2  (df0f37c62)
6f032c48d  the champion kernel - four validated levers ON BY DEFAULT (CHAMPION-1)
```

Both merges were `ort`, no conflicts. Total vs champion-1: **4 files, +334 / -3**.

| lever | shipped default | how | escape hatch |
|---|---|---|---|
| `GGML_VEC_Q8K` | **ON** | `(s==NULL || *s=='\0') ? 1 : (atoi(s)!=0)` | `=0` -> scalar reference |
| `GGML_QSPLIT` | **ON** | `(s==nullptr || *s=='\0') ? true : (atoi(s)!=0)` | `=0` -> D1's path |
| `GGML_QSPLIT_MIN` | **`INT64_MAX`** | multi-row branch only - §1.1 | set a number to opt in |
| `GGML_TINY_SOLO_ROWS` | **1 (inert)** | untouched; already the champion's behaviour | it *is* the hatch |
| `GGML_NOHUGEPAGE_PROCESS` | **OFF** | polarity **inverted**: `=1` opts in | §4 - this is the finding |
| `GGML_NOHUGEPAGE` (madvise) | **ON, unchanged** | CHAMPION-1's `ggml_aligned_malloc` lever | `=0` |
| `GGML_VEC_SIGMOID` | **OFF, untouched** | not bit-identical | - |

> **The distinction that matters, stated explicitly.** `GGML_NOHUGEPAGE` - the `MADV_NOHUGEPAGE`
> inside `ggml_aligned_malloc`, living in `libggml-base` - **stays ON**. It is the campaign's largest
> single win and it is *not* what was dropped. Only the *process-wide* `PR_SET_THP_DISABLE`
> constructor in `libllama-common` goes to default OFF. §3 proves the two are separable on a live
> server: with champion-3's defaults the process shows `THP_enabled=1` (shim not engaged) and
> AnonHugePages **0.057 %** (madvise very much engaged), against pristine's **99.888 %**.

### 1.1 Why `GGML_QSPLIT_MIN` defaults to `INT64_MAX`

SYNC-15 §8.1: Q's **single-row** branch buys a ~3.1 us barrier that pays at 12 us/row and loses at
2 us/row. `GGML_VEC_Q8K` takes the row to ~1.6 us (§2.2), so once V ships the single-row branch is a
net loss. `INT64_MAX` is above every `ne00` the graph carries, so the predicate
`rows_total > 1 || ne10 >= iqk_qsplit_min()` can only be satisfied by `rows_total > 1` - **the
multi-row branch alone**. Verified in the disassembly, §2.3.

A consequence worth recording: at plain decode `rows_total == 1`, so **Q is entirely inert in plain
mode**; the plain-decode gain over champion-1 is `GGML_VEC_Q8K` alone. Q earns its keep only in the
MTP serving config, where the trunk graph carries ~4 rows against 48 threads.

---

## 2. The build, audited without running it

| item | value |
|---|---|
| **champion-3** | build **10241** (`9c4f73e29`), GNU 15.2.0 |
| `libggml-cpu.so.0.16.0` | `2fb5b67ec39ab747e604ba2e6dd1ea898c199e3b664197851c99b92617e9ad87` |
| `libggml-base.so.0.16.0` | `fa004e2a782690315d66de29bd89656dd0c3f7a6ca79a7d03605c694848b2df0` |
| `libllama-common.so.0.0.10241` | `27b654efe66fa3ca654cfeab98d1d1f1283d24c2092006899757601d9e33352a` |
| `llama-server` | `9f69bac917d70b5288caa87427a38c64446be2175974bbb24eb45182053171bc` |
| **champion-2** (intermediate, 10240) | cpu lib `2fb5b67e...` - **byte-identical to champion-3** |
| **champion-1 anchor** | build **10234** (`6f032c48d`), cpu lib `1ac9e2c87a...` |
| **pristine control** | build **10221** (`c51e4dabf`), cpu lib `037d323e08...` |

**Every build directory was removed and rebuilt from scratch**; no pre-existing build tree was
reused. **`libggml-cpu.so` and `test-backend-ops` are byte-identical between champion-2 and
champion-3** - the only change between them is in `common/` - so every ggml-level result transfers
between the two verbatim.

### 2.1 `strings`-auditable markers

```
libggml-base.so.0.16.0      : INF70_CHAMPION_BASE_DEFAULT_ON=GGML_NOHUGEPAGE
libggml-cpu.so.0.16.0       : INF70_CHAMPION_CPU_DEFAULT_ON=GGML_ROWCOL_SPLIT,GGML_TINY_SOLO,GGML_EMPTY_SKIP;DEFAULT_OFF=GGML_VEC_SIGMOID
                              INF70_CHAMPION3_CPU_DEFAULT_ON=GGML_QSPLIT(multi-row-only,GGML_QSPLIT_MIN=INT64_MAX);DEFAULT_INERT=GGML_TINY_SOLO_ROWS=1,GGML_TINY_SOLO_ROWS_MAX
                              INF70_CHAMPION3_QUANTS_DEFAULT_ON=GGML_VEC_Q8K
libllama-common.so.0.0.10241: INF70_CHAMPION3_PROCESS_THP_DISABLE=DEFAULT_OFF;OPT_IN=GGML_NOHUGEPAGE_PROCESS=1;MASTER_OFF=GGML_NOHUGEPAGE=0
```

Every knob name is present in champion-3's libraries and **absent from pristine**.

### 2.2 `-ffp-contract=off` is carried, and the default is provably ON

The flag rides as `__attribute__((optimize("-ffp-contract=off")))` on the function itself, so it
cannot be lost by a build-config change. Verified two ways.

**Disassembly** of `quantize_row_q8_K_avx512` in the shipped `libggml-cpu.so`:
**0 `vfmadd`/`vfmsub` instructions, 16 `vmulps` + 16 `vaddps`** - the multiply and the
magic-number add are separate, rounding twice, exactly as bit-identity requires.

**Runtime**, linking a probe against the shipped library:

| `GGML_VEC_Q8K` | reference | dispatching entry point | speed-up | bytes |
|---|---:|---:|---:|---|
| **unset (the compiled default)** | 12.689 us/row | **1.643 us/row** | **7.72x** | IDENTICAL |
| **empty string** | 12.216 | 1.644 | 7.43x | IDENTICAL |
| `=0` (escape hatch) | 12.225 | **12.219** | **1.00x** | IDENTICAL |
| `=1` | 12.733 | 1.647 | 7.73x | IDENTICAL |

Unset *and* empty both take the fast path; `=0` lands exactly on the scalar reference.
Row-exactness re-run against **this** build over SYNC-15's adversarial generator (zeros, exact
absolute-value ties with mixed sign, denormals, large values, all-zero blocks): **1200 trials at
n = 10240 / 6144 / 2560 / 256, 0 mismatches.**

### 2.3 `GGML_QSPLIT`'s defaults, proven in the disassembly

`ggml_iqk_try_mul_mat` in champion-3 loads a `0x7fffffffffffffff` immediate; **champion-1's does
not**. The `iqk_qsplit_min` guarded initialiser reads: `getenv("GGML_QSPLIT_MIN")` ->
`movabs rax, 0x7fffffffffffffff` -> branch to the store if the pointer is NULL **or** the first byte
is `0` -> otherwise `strtoll`. That is the intended default, in machine code.

For `iqk_qsplit_enabled`, the initialiser calls `getenv("GGML_QSPLIT")` and, when the pointer is
NULL or the first byte is `0`, falls straight through to the store **without** calling `atoi`,
writing `r13b`. `r13b` is set by `setb` at `235b49` and the immediately following `test/je` is not
taken on any path reaching the initialiser, so `r13b == 1` there: **the compiled default is `true`.**

---

## 3. Whole-stack bit-identity, and every escape hatch

Greedy (`temperature 0`, `top_k 1`, `seed 42`), 256 max tokens, 5 prompts spanning **59 / 96 / 175 /
318 / 329** prompt tokens, sha256 of the full completion text, **plain and MTP**.

| pair | result |
|---|---|
| pristine -> champion-1 | 5/5 identical over 689 tokens (plain), 5/5 (MTP) |
| pristine -> **champion-3** | **5/5 identical (plain), 5/5 (MTP)** |
| champion-1 -> **champion-3** | **5/5 identical** |
| champion-2 -> champion-3 | 5/5 identical (plain), 5/5 (MTP) |
| champion-3 -> champion-3 with the shim opted in | 5/5 identical |
| pristine -> champion-3 with **every hatch engaged** | **5/5 identical** |

**16 arm-pairs across two windows, 0 differing sha256, in either serving mode.**

**Every hatch verified to actually disable its lever**, by mechanism rather than by output (all
levers are bit-identical, so token streams cannot prove a hatch works):

| hatch | evidence it fires |
|---|---|
| `GGML_VEC_Q8K=0` | dispatch time returns to the scalar reference, 7.7x -> 1.00x (§2.2) |
| `GGML_QSPLIT=0` | measured arm, MTP: -1.07 % vs champion-3's default (§4.3) |
| `GGML_NOHUGEPAGE_PROCESS=1` | `THP_enabled` 1 -> **0**, AnonHugePages 0.057 % -> **0.000 %** |
| `GGML_NOHUGEPAGE=0` + all four CHAMPION-1 hatches | AnonHugePages -> **99.892 %**, pristine's own profile, and the arm reproduces pristine's throughput (12.61 -> 12.56 t/s plain, 23.09 -> 23.44 MTP) |

The THP readings are the cleanest mechanism evidence in this report:

| configuration | `THP_enabled` | AnonHugePages / Rss |
|---|---|---|
| pristine `c51e4dabf` | 1 | **99.888 %** (92.2 GB of 92.3 GB) |
| champion-1 (madvise only) | 1 | **0.055 %** |
| **champion-3, shipped defaults** | 1 | **0.057 %** |
| champion-3 + `GGML_NOHUGEPAGE_PROCESS=1` | **0** | **0.000 %** |
| champion-3, all hatches engaged | 1 | **99.892 %** |

The madvise removes 99.83 pp of the huge pages; the process shim removes the last 0.057 pp. That
residual is the entire quantity CHAMP-2 was buying, and §4 is about what it is worth.

---

## 4. SYNC-15's falsifiable prediction - tested, and the answer is sharper than the hypothesis

SYNC-15 predicted CHAMP-2 and V+Q would be **partly, not fully, additive**: CHAMP-2 makes `wdata`
cheaper while V and Q make there be *less* `wdata`. **Two independent leave-one-out windows, plus a
third window that switches V and Q off, settle it.**

### 4.1 With V and Q ON, the shim's effect is not resolvable

Same binary, one environment variable apart. Two windows, three rounds each, arm order rotated in
window 3 so no arm holds a fixed slot.

| window | binary | shim OFF / shim ON | 95 % CI | wins | per-round off/on |
|---|---|---:|---|---|---|
| **1** | 10240 (shim default ON) | **1.0148 (+1.48 %)** | [1.0104, 1.0191] | 48/60 | 1.0082, 1.0169, 1.0174 |
| **3** | 10241 (shim default OFF) | **0.9885 (-1.15 %)** | [0.9816, 0.9952] | 25/60 | 0.9865, 1.0085, 0.9739 |
| **pooled** | both | **1.0016 (+0.16 %)** | - | **73/120** | - |

**The two windows disagree in sign, and each one's CI excludes the other's point estimate.** Neither
is wrong; the effect is simply smaller than the between-window drift the host carries. Pooled over
120 paired observations the shim is **+0.16 %, 73/120 wins - indistinguishable from zero.**

So the prediction is **confirmed in the direction it was posed, and then some**: CHAMP-2's +1.0 %
does **not** hold undiminished after V+Q. It does not survive at all. **Its win was a `wdata` win.**

### 4.2 The mechanism arm - the shim still wins when the traffic is there

Same binary (10241), `GGML_VEC_Q8K=0 GGML_QSPLIT=0` on both arms - which makes it behaviourally the
CHAMPION-1 kernel - with the shim the only difference. Three rounds, alternating.

| | t/s | ms/token |
|---|---:|---:|
| shim OFF (`== champion-1`) | 32.460 | 30.807 |
| shim ON (`== CHAMP-2`) | **32.805** | **30.483** |
| **paired ratio** | **1.0094 (+0.94 %)**, CI [1.0043, 1.0149], **42/60 wins** | |

**+0.94 % - CHAMP-2's original +1.0 %, reproduced in my own window on my own binary.** So:

> **The shim's value scales with `wdata` traffic.** With the scalar quantizer and D1's private-row
> path, `wdata` is large and hot, the brk heap's single-controller placement hurts, and
> de-huge-paging it is worth ~1 %. `GGML_VEC_Q8K` cuts the quantization cost ~7.7x, and
> `GGML_QSPLIT` replaces the multi-row broadcast with a block-partitioned one; between them the
> traffic the shim was placing well largely stops existing, and what remains of a process-wide
> `PR_SET_THP_DISABLE` is a TLB-reach cost on llama.cpp's own heap-resident state that roughly
> cancels it.

CHAMP-2's measurement was never wrong. It is simply **not additive with the levers that shipped
after it**.

### 4.3 The leave-one-out on V and Q (window 1, for the record)

| removed from champion-2 | ratio vs full stack | wins |
|---|---:|---|
| `GGML_VEC_Q8K` | 0.9932 (-0.68 %) | 21/60 |
| `GGML_QSPLIT` | 0.9893 (-1.07 %) | 22/60 |
| CHAMP-2 shim | 1.0148 (+1.48 %) | 48/60 |

These do not sum to the stack's gain (+3.15 % for champion-2 over champion-1, +4.27 % for
champion-3). **Leave-one-out does not decompose an interacting stack** - the same super-additivity
CHAMPION-1 recorded. The stack was measured; it was not inferred.

---

## 5. The measurement

24-prompt production harness (`e3-alpha/prompts.json`), `/v1/chat/completions`,
`enable_thinking:false`, temperature 0, `max_tokens 200`, `cache_prompt false`. Token-weighted
`sum(pred_n)/sum(pred_ms)` with a `pred_n >= 16` floor (20 of 24 rows enter the rate). Bootstrap CI,
2000 resamples. Per-prompt paired ratios are formed **within a round**, never across rounds.
Harness derived verbatim in structure from `champion1/arm.sh`, which came from `speed-claim/arm.sh`.

Serving config, placement and environment are identical to CHAMPION-1's, arm for arm:
`-fa on -ctk f16 -ctv f16`, `--spec-type draft-mtp --spec-draft-n-max 4 --spec-draft-p-min 0.5`,
`-np 1 -c 8192 -t 48 --no-mmap`, `taskset -c 0-95 numactl --interleave=all`,
`OMP_PROC_BIND=spread OMP_PLACES=cores OMP_WAIT_POLICY=active OMP_DYNAMIC=false GGML_IQK=1
GGML_FUSED_DECODE_OFF=1 GGML_FA_SPLIT_KV=0`, read back from `/proc/<pid>/environ` per arm,
`evict_nodes_force.sh 58` before every arm, `region-lock run --cpu-list 0-95 --role bench`.

**Placement was verified per arm** and converged on the first try in all 48 arms - 23.0-23.9 GB per
node, max deviation <= 0.1 %, against a 15 % limit.

**The `--fa 1` trap**: every server invocation was dry-run against a nonexistent model before each
window opened, on all four binaries, plain and MTP. All reached model load; none reported an
unrecognized argument. No arm was lost to a flag.

### 5.1 Per-arm results

**Window 1** (build 10240, 6 arms x 3 rounds MTP + 3 arms x 3 rounds plain):

| arm | t/s | ms/tok | CI95 | prefill pp/s |
|---|---:|---:|---|---:|
| pristine, MTP | 22.642 | 44.166 | [21.68, 23.56] | 134.9 |
| champion-1, MTP | 32.930 | 30.368 | [31.62, 34.13] | 172.3 |
| champion-2, MTP | 33.954 | 29.452 | [32.59, 35.25] | 180.7 |
| **champion-3 config, MTP** | **34.433** | **29.042** | [33.04, 35.75] | 185.6 |
| pristine, plain | 12.366 | 80.867 | [12.31, 12.41] | 141.2 |
| champion-1, plain | 19.722 | 50.705 | [19.63, 19.81] | 175.2 |
| champion-2, plain | 21.427 | 46.670 | [21.34, 21.51] | 195.4 |

**Window 3** (build 10241, the shipped binary, 4 arms x 3 rounds MTP + 3 arms x 3 rounds plain,
arm order rotated per round):

| arm | t/s | ms/tok | CI95 | prefill pp/s |
|---|---:|---:|---|---:|
| pristine, MTP | 22.521 | 44.403 | [21.54, 23.45] | 133.2 |
| champion-1, MTP | 32.115 | 31.138 | [30.80, 33.33] | 168.5 |
| **champion-3, MTP** | **33.370** | **29.967** | [31.94, 34.69] | 179.3 |
| champion-3 + shim, MTP | 33.728 | 29.649 | [32.40, 34.99] | 179.4 |
| pristine, plain | 12.018 | 83.206 | [11.85, 12.16] | 137.1 |
| champion-1, plain | 19.514 | 51.245 | [19.31, 19.71] | 181.1 |
| **champion-3, plain** | **20.589** | **48.569** | [20.30, 20.81] | 196.7 |

### 5.2 Paired ratios

| pair | mean | CI95 | wins |
|---|---:|---|---|
| **champion-3 / champion-1, MTP, pooled both windows** | **1.0427** | - | **117/120** |
| champion-3 / champion-1, MTP, window 1 | 1.0466 | [1.0425, 1.0508] | 60/60 |
| champion-3 / champion-1, MTP, window 3 | 1.0388 | [1.0316, 1.0461] | 57/60 |
| **champion-3 / pristine, MTP, pooled** | **1.4993** | - | **120/120** |
| champion-2 / champion-1, MTP, window 1 | 1.0315 | [1.0270, 1.0362] | 58/60 |
| champion-3 / champion-1, plain, window 3 | 1.0568 | [1.0413, 1.0714] | 47/60 |
| champion-2 / champion-1, plain, window 1 | 1.0868 | [1.0823, 1.0915] | 60/60 |
| champion-3 / pristine, plain, window 3 | 1.7151 | [1.6882, 1.7439] | 60/60 |

SYNC-15's solo prediction for V+Q was **+5.24 % MTP**. Measured in the stack: **+4.27 %** - close,
and the residual is the shim's absence plus the usual sub-additivity.

---

## 6. Contention, and why the absolutes must not be compared to the 35.407 anchor

**The GPU lane was live for most of this work.** The autokernel `llama-bench` is pinned
`Cpus_allowed_list=184-191`. The co-residency sampler labels that "disjoint-from-0-95" and **the
label is wrong**: 184-191 are the **SMT siblings of physical cores 88-95**, which are inside the
0-95 bench region. Distinct `llama-bench` PIDs were seen continuously across the MTP arms of both
windows - typically 10-17 distinct short-lived processes per arm family, present in essentially
every 20-second sample.

The cost is visible directly: **champion-1 reads 32.930 t/s (window 1) and 32.115 t/s (window 3)
against its own quiet-window anchor of 35.407 t/s** - a 7-9 % depression, matching what SYNC-15
reported for the same reason.

**Therefore: quote the ratios, not my absolutes.** The ratios are same-window, paired and stable
across two windows. The anchor-referred figure `35.407 x 1.0427 =` **36.9 t/s / 27.1 ms per token**
is a **projection**, not a measurement, and is labelled as such.

One further caveat, found in the co-residency data: **the GPU lane stopped partway through window
3's plain phase** - `R_P` saw `llama-bench` in 17 of 52 samples while `R_C1` and `R_C3` saw it in
**none**. Window 3's plain arms therefore straddle a contention change, which shows up as
champion-1's plain arm drifting 20.456 -> 19.324 -> 18.833 across rounds. Window 1's plain arms, run
under uniform contention, are much tighter (19.829 / 19.751 / 19.587) and are the better-conditioned
plain measurement. I have not excluded window 3's plain rounds - the paired within-round structure
absorbs most of it, and the direction of the result is not in question - but the plain ratio carries
more uncertainty than its CI suggests.

**Other foreign load**: agent-session `opencode`/`claude`/`htop` processes with
`Cpus_allowed_list=0-191` at 8-50 % of a core, stationary across every arm. HARNESS-1 disclosed ~4
core-seconds of unit tests on core 2 during window 3; that is far below anything actionable, it did
not touch the page cache, and **no round was dropped for it - or for anything else.**

---

## 7. `test-backend-ops test -b CPU`

Run with `-b CPU` (without it the run is vacuous), on all three binaries, inside the lock.
Per **HYG-3** this tree returns `rc=1` with a standing set of pre-existing failures, and
`LIGHTNING_INDEXER` churns between runs, so failure **sets** are compared with it excluded and its
count reported separately.

| binary | rc | tests passed | total FAIL lines | `LIGHTNING_INDEXER` | comparable set |
|---|---|---|---|---|---|
| pristine `c51e4dabf` (seeded control) | 1 | 16702 / 16762 | 62 | 49 | **7** |
| champion-1 `6f032c48d` | 1 | 16701 / 16762 | 63 | 50 | **7** |
| **champion-2 / champion-3** | 1 | 16701 / 16762 | 63 | 50 | **7** |

**The comparable failure sets are identical across all three** (`identical: True` against the
pristine control, in both directions). The churn is confined to `LIGHTNING_INDEXER` exactly as
HYG-3 describes. champion-3's `test-backend-ops` binary is byte-identical to champion-2's, so this
result is the shipped binary's.

---

## 8. What ships, and what is left on the table

**Ships**: `inf70/champion3` @ `9c4f73e29`, build 10241 - `GGML_VEC_Q8K` ON, `GGML_QSPLIT` ON
multi-row-only, everything CHAMPION-1 shipped unchanged, the CHAMP-2 shim present but opt-in.

**Kept but off**: the process THP shim. It is correct, bit-identical, placement-only, and it
**measurably wins (+0.94 %) in any configuration built without V and Q**. Deleting it would lose a
validated lever and its evidence; a future stack whose `wdata` traffic goes back up will want it.
`GGML_NOHUGEPAGE_PROCESS=1` turns it on with no rebuild.

**Not mine to fix, recorded for whoever picks it up**:

- **`GGML_QSPLIT`'s single-row branch is now dead code in practice.** `GGML_QSPLIT_MIN=INT64_MAX`
  means only the multi-row branch can fire, and plain decode (`rows_total == 1`) gets nothing from Q
  at all. If someone later wants the batch-1 split back they must set `GGML_QSPLIT_MIN` explicitly
  and re-measure against V, not against the scalar quantizer.
- **The shim's sign is window-dependent at +/-1.5 %.** A useful calibration of this host's
  between-window drift for anyone sizing a future lever: **an effect below ~1.5 % cannot be settled
  by one window, however many rounds it has.** Both of my windows had three rounds and tight CIs,
  and they still disagreed in sign.
- **The co-residency sampler mislabels 184-191 as disjoint from 0-95.** They are SMT siblings of
  88-95. The label is inherited from `champion1/arm.sh` and is wrong in every report that used it.
  A one-line fix in the sampler's Python would stop it misleading the next agent.

---

## 9. Files

Everything is under `/mnt/raid0/llm/tmp/inf70/agents/champion3/`:
`REPORT.md` (this file) - `runs/` (48 arms: rows, timelines, server logs, env readback, numastat,
smaps, co-residency) - `ident/` (13 bit-identity arms) - `agg.py`, `agg3.py`, `identcheck.py`,
`tbocmp.py` (analysis) - `arm.sh`, `driver.sh`, `driver3.sh`, `driver4.sh`, `ident.sh`, `ident3.sh`,
`tbo.sh`, `chain*.sh` (harness) - `q8kdefault.c`, `q8ktest.c` (quantizer proofs) -
`tbo.bin-*.log` - `binaries.sha256` - `agg.window1.txt`, `agg.window3.txt`, `agg.mech.txt`.
