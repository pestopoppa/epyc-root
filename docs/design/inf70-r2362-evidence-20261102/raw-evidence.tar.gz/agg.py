#!/usr/bin/env python3
"""INF-70 CHAMPION-3 ABA aggregation: pooled per-arm rates and paired per-prompt ratios
with win counts and bootstrap CIs. Method copied from champion1/analyze.py (which copied
speed-claim/aba.py), so the numbers are directly comparable to the 23.16 / 35.407 anchors."""
import json, os, sys, statistics as st, random
R = "/mnt/raid0/llm/tmp/inf70/agents/champion3/runs"
FLOOR = 16
def load(l):
    p = f"{R}/{l}.rows.jsonl"
    return [json.loads(x) for x in open(p) if x.strip()] if os.path.exists(p) else []
def dec(rows): return [r for r in rows if (r.get("pred_n") or 0) >= FLOOR and r.get("pred_ms")]
def tw(rows, num="pred_n", den="pred_ms"):
    d = sum(r[den] for r in rows)/1000.0
    return sum(r[num] for r in rows)/d if d else None
def pool(arm, rounds=(1,2,3)):
    out = []
    for r in rounds: out += dec(load(f"{arm}_r{r}"))
    return out
def allrows(arm, rounds=(1,2,3)):
    out = []
    for r in rounds: out += load(f"{arm}_r{r}")
    return out
def boot(rows, B=2000, seed=7):
    rnd = random.Random(seed); o = []
    for _ in range(B):
        s = [rows[rnd.randrange(len(rows))] for _ in rows]
        v = tw(s)
        if v: o.append(v)
    o.sort(); return o[int(.025*len(o))], o[int(.975*len(o))]
def summ(arm, rounds=(1,2,3)):
    d = pool(arm, rounds); a = allrows(arm, rounds)
    if not d: return None
    lo, hi = boot(d)
    reasons = {}
    for r in a: reasons[r.get("verdict","?")] = reasons.get(r.get("verdict","?"),0)+1
    pre = [r for r in a if r.get("prompt_ms") and r.get("prompt_n")]
    o = dict(arm=arm, n_rows=len(a), n_dec=len(d), tps=round(tw(d),4),
             ms_per_tok=round(1000.0/tw(d),3), ci95=[round(lo,3),round(hi,3)],
             pp=round(tw(pre,"prompt_n","prompt_ms"),2) if pre else None, reasons=reasons)
    dn = sum(r.get("draft_n") or 0 for r in a); da = sum(r.get("draft_acc") or 0 for r in a)
    tok = sum(r.get("pred_n") or 0 for r in a)
    if dn: o.update(alpha=round(da/dn,4), drafted_per_tok=round(dn/tok,4))
    return o
def paired(a, b, rounds=(1,2,3)):
    """per-prompt, per-round paired ratio b/a -- pairs only within the same round."""
    rr = []
    for r in rounds:
        ra = {x["id"]: x for x in dec(load(f"{a}_r{r}"))}
        rb = {x["id"]: x for x in dec(load(f"{b}_r{r}"))}
        for k in sorted(set(ra) & set(rb)):
            rr.append((rb[k]["pred_n"]/rb[k]["pred_ms"]) / (ra[k]["pred_n"]/ra[k]["pred_ms"]))
    if not rr: return None
    rnd = random.Random(11); bs = []
    for _ in range(2000):
        s = [rr[rnd.randrange(len(rr))] for _ in rr]; bs.append(st.mean(s))
    bs.sort()
    return dict(pair=f"{b}/{a}", n=len(rr), mean=round(st.mean(rr),4), median=round(st.median(rr),4),
                ci95=[round(bs[50],4), round(bs[1949],4)],
                pct=round(100*(st.mean(rr)-1),2), wins=f"{sum(1 for x in rr if x>1)}/{len(rr)}",
                min=round(min(rr),4), max=round(max(rr),4))
if __name__ == "__main__":
    M = ["M_P","M_C1","M_C2","M_LHP","M_LV","M_LQ"]
    P = ["P_P","P_C1","P_C2"]
    print("### PER-ARM (pooled over rounds present)")
    for arm in M+P:
        s = summ(arm)
        if s: print(json.dumps(s))
    print("\n### PER-ROUND tps")
    for arm in M+P:
        row = []
        for r in (1,2,3):
            d = dec(load(f"{arm}_r{r}"))
            row.append(round(tw(d),3) if d else None)
        print(f"{arm:<8} {row}")
    print("\n### PAIRED RATIOS (same round, same prompt)")
    for a,b in [("M_P","M_C1"),("M_P","M_C2"),("M_C1","M_C2"),
                ("M_C2","M_LHP"),("M_C2","M_LV"),("M_C2","M_LQ"),
                ("M_LHP","M_C2"),("M_LV","M_C2"),("M_LQ","M_C2"),
                ("P_P","P_C1"),("P_P","P_C2"),("P_C1","P_C2")]:
        x = paired(a,b)
        if x: print(json.dumps(x))
