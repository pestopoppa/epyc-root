# DF2-6b-bis readiness review (2026-11-01)

The task remains open and still needed. The October 20 DF2-17 run explicitly omitted ngram and retained DF2-6b-bis. Its condition "only if it adds no extra run" applied to the DF2-17 piggyback, not a cancellation of this standalone row.

This is a GPU task on gfx90a. The existing question concerns the matched quantized target and its GPU batched verification path. CPU may later supply independent backend evidence, but cannot settle this task's historical comparison. The old research driver hardcodes ROCm0 and -ngl 99; relabeling its row CPU would still consume the MI210.

Static build identity is available: October champion source is clean at 4348de400191c0b4c5127047037bf9ad83da19b6; every SHA256SUMS entry verifies. CMake binds that source directory and ROCWMMA_FATTN=ON/HIP_GRAPHS=ON. Source presence in the generic llama.cpp-experimental tree is not relevant: that tree is currently the old v9 commit 0db32c06e. Production and its kernels were untouched.

No valid v3 spec or launcher is emitted, since no existing runner implements the complete task. This is implementation preparation the owning session can finish, not an operator decision or external dependency. See readiness.json for exact gaps and recorded identities.

## Owning-session actions

1. Copy the DF2-17 baseline/control and probability-pass logic into a new stop-aware runner in this scratch directory. Avoid its old fixed ROOT, imported gpuq path and hardcoded port; declare the actual reserved port in the launcher. Keep f16 KV, greedy temp0/top_k1/seed42, same 12 prompts, fresh own server process per arm and exact-token A/A + serial controls. Retain generation outputs/token IDs and raw logs.
2. Freeze an explicit comparable-draft-volume rule before running: per-prompt draft_n > 0 is necessary but insufficient. State the allowed ngram-vs-dflash volume ratio and verify-width exposure criterion, with low exposure giving INCONCLUSIVE rather than immunity. Any repetition-rich extension must use identical frozen prompts in every arm and retain continuity-set results separately. Pin the choice of ngram-cache/mod and all parameters; never search arms using parity outcomes.
3. Capture verification rounds (LLAMA_SPEC_DIAG_ACCEPT diagnostics are in common/sampling.cpp and libllama-common; server trace can expose accepted/drafted per round); verify the parser against actual instrument strings. Report partial rounds and per-prompt volume next to token verdict. Baseline n_probs pass must reproduce the baseline tokens before classifying first fork as baseline top2 + margin <0.5, otherwise preserve an explicit unclassified/void outcome. Do not reuse speculative-row margins as baseline margins.
4. Bind source, libraries, models and prompts by digest; pin LD_LIBRARY_PATH to the candidate build and prove runtime linkage and in-window VRAM/KFD. Do not infer residency from the launch command. Build/store identities in readiness.json are static evidence only.
5. Create filler_run15.sh launcher, cpu+gpu/GPU lane, host cores 184-191, minimum bounded unit/clean stop, result JSONL append after each completed prompt (no fabricated measurement rows), truthful completion predicate and explicit decision_rule. Use rowflow static parsing/readiness checks first. Owner alone applies the row; keeper dry run is compute and must happen after publication under its grant/region lock.

No inference, tests, server launch, compute request, READY edit, grant edit or publication occurred in this review.
