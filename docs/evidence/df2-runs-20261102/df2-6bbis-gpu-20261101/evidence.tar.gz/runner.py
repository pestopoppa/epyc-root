#!/usr/bin/env python3
"""DF2-6b-bis prepared runner. Execution requires filler grant; no stand-alone run."""
import hashlib,json,os,re,signal,subprocess,time,urllib.request
from pathlib import Path
import gpuq
import launch_affinity
D=Path(__file__).resolve().parent
B=Path('/mnt/raid0/llm/kernels/builds/gpu-20261006-4348de400/bin')
SOURCE=Path('/mnt/raid0/llm/llama.cpp-experimental-champref-4348de400-20261006')
PORT=18139
ARMS=['off_A','off_B','serial_df7','dflash7','ngram_mod7']

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda:f.read(4*1024*1024),b''):h.update(c)
    return h.hexdigest()

def stopped():
    return Path(os.environ['FILLER_STOPFILE']).exists() or time.time()+850>=float(os.environ['FILLER_DEADLINE'])

def request(path,body=None,timeout=240):
    q=urllib.request.Request(f'http://127.0.0.1:{PORT}{path}',data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(q,timeout=timeout) as f:return json.load(f)

def body(prompt,probs=False):
    d={'prompt':prompt,'n_predict':256,'temperature':0,'top_k':1,'top_p':1,'min_p':0,'typical_p':1,'repeat_penalty':1,'seed':42,'stream':False,'cache_prompt':False,'return_tokens':True,'samplers':['top_k','temperature']}
    if probs:d.update(n_probs=2,post_sampling_probs=False)
    return d

def run(q,arm,identity):
    out=D/'arms'/q['id']/arm;out.mkdir(parents=True,exist_ok=True)
    marker=out/'record.json'
    if marker.exists():
        r=json.loads(marker.read_text());assert r['identity']==identity;return r
    a=['taskset','-c','184-191',str(B/'llama-server'),'-m',str(DICT['target']),'-np','1','-c','32768','--no-kv-unified','-t','8','-tb','8','-b','2048','-ub','2048','-ctk','f16','-ctv','f16','--device','ROCm0','-ngl','99','-fa','on','--host','127.0.0.1','--port',str(PORT),'--metrics','--slots']
    if arm.startswith('off'):a+=['--spec-type','none']
    elif arm=='ngram_mod7':a+=['--spec-type','ngram-mod','--spec-ngram-mod-n-min','1','--spec-ngram-mod-n-max','7','--spec-ngram-mod-n-match','4']
    else:a+=['--spec-type','draft-dflash','-md',str(DICT['draft']),'-ngld','99','--spec-draft-n-max','7']
    env=dict(os.environ)
    for k in list(env):
        if k.startswith(('LLAMA_ARG_','GGML_','LLAMA_SPEC_','HSA_OVERRIDE_')):env.pop(k)
    env.update(LD_LIBRARY_PATH=str(B)+':/opt/rocm/lib',LLAMA_TRACE='1',GGML_CUDA_LOG_MMVQ_ROUTE='2')
    if arm=='serial_df7':env['LLAMA_SPEC_EXACT']='serial'
    env.update(OMP_NUM_THREADS='8',ROCR_VISIBLE_DEVICES='0')
    launch_affinity.apply_pinned_launch_env(env,a)
    (out/'argv.json').write_text(json.dumps(a));(out/'env.json').write_text(json.dumps({k:env[k] for k in ['LD_LIBRARY_PATH','LLAMA_TRACE','GGML_CUDA_LOG_MMVQ_ROUTE','OMP_NUM_THREADS','ROCR_VISIBLE_DEVICES'] }|({'LLAMA_SPEC_EXACT':'serial'} if arm=='serial_df7' else {})))
    # Required common linkage guard plus /proc residency below (dlopen HIP is invisible to ldd).
    link=subprocess.run(['bash',DICT['linkage_guard'],str(B/'llama-server'),str(B.parent)],env=env,capture_output=True,text=True)
    (out/'linkage.txt').write_text(link.stdout+link.stderr);assert link.returncode==0,'linkage guard refused'
    log=out/'server.stderr'; holder={}; smp=gpuq.Sampler(.5,lambda:holder.get('pid'))
    with log.open('wb') as f,smp:
        proc=subprocess.Popen(a,stdout=f,stderr=subprocess.STDOUT,env=env);holder['pid']=proc.pid
        if os.environ.get('FILLER_PIDFILE'):
            with open(os.environ['FILLER_PIDFILE'],'a') as pf:pf.write(str(proc.pid)+'\n')
        try:
            deadline=time.time()+240
            while True:
                if proc.poll() is not None:raise RuntimeError('server exited')
                try:
                    if request('/health',timeout=2).get('status')=='ok':break
                except Exception:pass
                if time.time()>deadline:raise RuntimeError('startup timeout')
                time.sleep(1)
            affinity=launch_affinity.enforce_pinned_child(proc.pid,'184-191',label=arm)
            (out/'affinity.json').write_text(json.dumps(affinity))
            maps=Path(f'/proc/{proc.pid}/maps').read_text();(out/'maps.txt').write_text(maps)
            libs={line.split()[-1] for line in maps.splitlines() if '/' in line and any(x in line for x in ('libggml','libllama'))}
            assert libs and any('libggml-hip' in x for x in libs),'HIP not resident'
            assert all(Path(x).resolve().is_relative_to(B.resolve()) for x in libs),'foreign ggml/llama'
            # Sampling window begins immediately before generation, not at startup.
            start=time.time();r=request('/completion',body(q['prompt']));end=time.time()
            (out/'response.json').write_text(json.dumps(r))
            if arm=='off_A':
                margin=request('/completion',body(q['prompt'],True));(out/'margin_response.json').write_text(json.dumps(margin))
                assert margin.get('tokens')==r.get('tokens'),'baseline margin pass token mismatch'
        finally:
            if proc.poll() is None:
                proc.send_signal(signal.SIGTERM)
                try:proc.wait(timeout=30)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=30)
            assert proc.poll() is not None,'server not dead'
    samples=[x for x in smp.samples if start<=x['t']<=end]
    (out/'samples.json').write_text(json.dumps(smp.samples))
    assert sum(x['child_in_kfd'] and x['vram']>=8*1024**3 for x in samples)>=2,'insufficient during-generation residency samples'
    rounds=[(int(a),int(b)) for a,b in re.findall(r'accepted\s+(\d+)/\s*(\d+) draft tokens(?: \(restore checkpoint\))?\s*$',log.read_text(errors='replace'),re.M)]
    tm=r.get('timings') or {};dn=tm.get('draft_n');an=tm.get('draft_n_accepted')
    # C5 omits both counters when spec off. Only this known negative control
    # may normalize absent fields; null, bool, malformed and nonzero refuse.
    if arm.startswith('off'):
        dn=tm['draft_n'] if 'draft_n' in tm else 0
        an=tm['draft_n_accepted'] if 'draft_n_accepted' in tm else 0
        assert type(dn) is int and type(an) is int and dn==an==0,'baseline counter malformed or nonzero'
    else:
        if 'draft_n' not in tm and 'draft_n_accepted' not in tm:
            # C5 omits both fields for a successfully completed zero-draft arm.
            assert isinstance(r.get('tokens'),list) and r.get('stop_type') in ('limit','eos','word'),'zero-draft response not a valid completion'
            assert type(tm.get('predicted_n')) is int and tm['predicted_n']>=0,'zero-draft completion missing generated count'
            dn=an=0
        else:
            assert 'draft_n' in tm and 'draft_n_accepted' in tm,'partial speculative timing fields'
            assert type(dn) is int and type(an) is int and dn>=an>=0,'missing or malformed speculative timing counters'
    if arm=='serial_df7':assert dn>0 and ' = serial' in log.read_text(errors='replace'),'serial control inactive'
    trace_ok=(arm.startswith('off') or arm=='serial_df7' or ((bool(rounds) or dn==an==0) and sum(x[1] for x in rounds)==dn and sum(x[0] for x in rounds)==an))
    rec={'identity':identity,'id':q['id'],'corpus':q['corpus'],'arm':arm,'tokens':r.get('tokens') or [],'content_sha256':hashlib.sha256((r.get('content') or '').strip().encode()).hexdigest(),'response_sha256':sha(out/'response.json'),'draft_n':dn,'accepted_n':an,'predicted_n':tm.get('predicted_n'),'partial_acceptance_rounds':sum(0<a<b for a,b in rounds),'rejected_rounds':sum(a==0<b for a,b in rounds),'verify_width_histogram':{str(w):sum(b+1==w for _,b in rounds) for w in range(2,9)},'round_trace_reconciles':trace_ok,'generation_sample_count':len(samples),'raw':str(out)}
    marker.write_text(json.dumps(rec));
    with (D/'results.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
    return rec

def judge(q,rs):
    base=rs[0]['tokens'];controls=all(r['tokens']==base for r in rs[1:3]);m=json.loads((Path(rs[0]['raw'])/'margin_response.json').read_text());cp=m.get('completion_probabilities') or []
    report=[];ref=rs[3]
    for r in rs[3:]:
        same=r['tokens']==base;i=next((i for i,(a,b) in enumerate(zip(base,r['tokens'])) if a!=b),None)
        if i is None and not same:i=min(len(base),len(r['tokens']))
        label='PARITY' if same else 'UNCLASSIFIED';gap=None;top2=None
        if i is not None and i<len(cp) and i<len(r['tokens']):
            top=cp[i].get('top_logprobs') or cp[i].get('top_probs') or []
            if cp[i].get('id')==base[i] and len(top)>=2 and all('logprob' in x and 'id' in x for x in top):
                top=sorted(top,key=lambda x:-x['logprob']);gap=top[0]['logprob']-top[1]['logprob'];top2=top[1]['id']
                label='NEAR_TIE' if r['tokens'][i]==top2 and gap<.5 else 'DEGENERATIVE'
        ratio=r['draft_n']/ref['draft_n'] if ref['draft_n'] else None
        # Match both drafted volume and actual verification-width distribution.
        rh=r['verify_width_histogram'];dh=ref['verify_width_histogram'];rt=sum(rh.values());dt=sum(dh.values())
        tv=.5*sum(abs(rh[k]/rt-dh[k]/dt) for k in rh) if rt and dt else None
        exposure=bool(r['draft_n']>0 and ratio is not None and .5<=ratio<=2 and tv is not None and tv<=.25)
        status='VOID_CONTROLS' if not controls else ('INCONCLUSIVE_INSTRUMENT' if not r['round_trace_reconciles'] else ('INCONCLUSIVE_LOW_EXPOSURE' if r['draft_n']==0 or ref['draft_n']==0 or (r['arm']=='ngram_mod7' and not exposure) else label))
        report.append({'id':q['id'],'corpus':q['corpus'],'arm':r['arm'],'parity':same,'first_diff_generation_token_index':i,'baseline_margin_nats':gap,'baseline_top2':top2,'classification':label,'verdict':status,'draft_n':r['draft_n'],'draft_volume_ratio_to_dflash':ratio,'verify_width_distribution_total_variation':tv,'comparable':exposure,'partial_acceptance_rounds':r['partial_acceptance_rounds']})
    return report

if __name__=='__main__':
    assert os.environ.get('FILLER_ID')=='df2-6bbis-gpu-20261101','must run through declared filler engine'
    assert os.environ.get('FILLER_STOPFILE') and os.environ.get('FILLER_DEADLINE')
    DICT=json.loads((D/'identity.json').read_text());identity=sha(D/'identity.json')
    assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==DICT['source_commit']
    assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain','--untracked-files=no'],text=True).strip(),'tracked source dirty'
    for name,digest in DICT['files'].items():assert sha(name)==digest,f'identity mismatch: {name}'
    prompts=json.loads((D/'prompts.json').read_text());allrows=[]
    for q in prompts:
        rows=[]
        for arm in ARMS:
            if stopped():raise SystemExit(75)
            rows.append(run(q,arm,identity))
        allrows+=judge(q,rows)
        (D/'verdicts.json').write_text(json.dumps(allrows,indent=2))
    (D/'DONE.json').write_text(json.dumps({'identity':identity,'prompts':len(prompts),'arms':ARMS,'verdict_rows':len(allrows)}))
