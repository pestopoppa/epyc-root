"""Shared GPU-queue helpers: residency sampler DURING the run, own-PID process control."""
from __future__ import annotations
import json, os, signal, subprocess, threading, time
from pathlib import Path

VRAM = Path("/sys/class/drm/card2/device/mem_info_vram_used")
BUSY = Path("/sys/class/drm/card2/device/gpu_busy_percent")
KFD = Path("/sys/class/kfd/kfd/proc")

def _rd(p):
    try: return int(Path(p).read_text().strip())
    except Exception: return -1

class Sampler:
    """Samples VRAM / gpu_busy / KFD pids every `interval` s on a thread while the child runs."""
    def __init__(self, interval=0.5, pid_fn=None):
        self.interval, self.pid_fn = interval, pid_fn
        self.samples = []; self._stop = threading.Event(); self._t = None
    def _loop(self):
        while not self._stop.is_set():
            pid = self.pid_fn() if self.pid_fn else None
            try: kf = sorted(int(x) for x in os.listdir(KFD) if x.isdigit())
            except Exception: kf = []
            self.samples.append({"t": time.time(), "vram": _rd(VRAM), "busy": _rd(BUSY), "kfd_pids": len(kf),
                                 "child_in_kfd": (pid in kf) if pid else None})
            self._stop.wait(self.interval)
    def __enter__(self):
        self._t = threading.Thread(target=self._loop, daemon=True); self._t.start(); return self
    def __exit__(self, *a):
        self._stop.set(); self._t.join(timeout=5)
    @property
    def proof(self):
        s = self.samples
        if not s: return {"n": 0}
        return {"n": len(s), "vram_peak": max(x["vram"] for x in s), "vram_first": s[0]["vram"], "vram_last": s[-1]["vram"],
                "busy_max": max(x["busy"] for x in s), "busy_nonzero_samples": sum(1 for x in s if x["busy"] > 0),
                "kfd_pids_max": max(x["kfd_pids"] for x in s), "child_in_kfd_samples": sum(1 for x in s if x["child_in_kfd"])}

def run_logged(argv, env, log: Path, timeout=3600, cwd=None):
    """Run one child; sample residency during it. Returns (rc, proof, pid). Kills only its own child."""
    log.parent.mkdir(parents=True, exist_ok=True)
    holder = {}
    with log.open("wb") as f:
        proc = subprocess.Popen(argv, stdout=f, stderr=subprocess.STDOUT, env=env, cwd=cwd)
        holder["pid"] = proc.pid
        with Sampler(0.5, lambda: holder.get("pid")) as smp:
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.send_signal(signal.SIGTERM)
                try: rc = proc.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    proc.kill(); rc = proc.wait(timeout=60)
                rc = f"timeout/{rc}"
    return rc, smp.proof, proc.pid
