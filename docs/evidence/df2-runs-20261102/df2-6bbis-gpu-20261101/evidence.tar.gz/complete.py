#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
try:
 d=json.loads((p/'DONE.json').read_text());v=json.loads((p/'verdicts.json').read_text())
 ok=d['identity']==hashlib.sha256((p/'identity.json').read_bytes()).hexdigest() and d['prompts']==18 and d['verdict_rows']==36 and len(v)==36
except (OSError,ValueError,KeyError):ok=False
raise SystemExit(0 if ok else 1)
