
import json
from pathlib import Path
import signal
import sys
import time
from types import SimpleNamespace
from scripts.kernel_rnd.autokernel.loop import serial_run as sr, campaign_cli, legacy_targets
argv = sys.argv[1:]
out = Path(sr.option(argv, "--out"))
target_id = sr.option(argv, "--target-id")
root = out.parents[1]
with (root / "seen.jsonl").open("a") as f:
    f.write(json.dumps({"argv": argv, "pid": __import__('os').getpid()}) + "\n")
mode = (root / "mode").read_text() if (root / "mode").exists() else "good"
if mode == "noisy":
    sys.stdout.write("s" * (sr.MAX_SERIAL_CHILD_LOG_BYTES_PER_STREAM + 17))
    sys.stderr.write("e" * (sr.MAX_SERIAL_CHILD_LOG_BYTES_PER_STREAM + 29))
if mode == "missing":
    sys.exit(0)
if mode == "fail":
    sys.exit(3)
stopped = [False]
signal.signal(signal.SIGTERM, lambda *_args: stopped.__setitem__(0, True))
if mode in {"wait", "stop"}:
    (out / "ready").touch()
    if mode == "stop":
        (root / "STOP").touch()
    until = time.monotonic() + 10
    while not stopped[0] and time.monotonic() < until:
        time.sleep(.01)
resolved = campaign_cli.load_previous(Path(sr.option(argv, "--resolved-campaign")))
cpu = sr.option(argv, "--cpu-serving-launch") is not None
selected = legacy_targets.select_target(resolved, target_id, cpu_serving=cpu)
identity = {"campaign_id": resolved.campaign_id, "request_id": resolved.request_id,
            "manifest_digest": resolved.manifest_digest, "selected_id": target_id,
            "scope": "cpu_serving_selected_workload" if cpu else "legacy_gpu_screen",
            "original_target": selected.to_dict()}
held = None
selection_path = sr.option(argv, "--scheduler-selection")
if selection_path and mode == "original_cost":
    # Actual original private flock/PID/interval writer, no hardware or measurement.
    import fcntl
    from scripts.kernel_rnd.autokernel.loop import claim, scheduling
    from scripts.kernel_rnd.autokernel.loop.measurement_capture import ArtifactStore
    selection = scheduling.Selection.from_dict(json.loads(Path(selection_path).read_text()))
    with (root / "fixture-cost.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        owner = claim.HeldCpuClaim({"device_id": "cpu", "cpu_list": "0"},
            [root / "fixture-cost.lock"],
            region_fraction=selection.proposal.estimated_claims.physical_region_fraction,
            affinity=("0",))
        try:
            time.sleep(.02)
        finally:
            owner._closing()
            fcntl.flock(lock, fcntl.LOCK_UN)
            owner._released_now()
    store = ArtifactStore(out / "held-claim-artifacts")
    try:
        artifact = claim.publish_intervals(store, selection, [owner], target=identity)
    finally:
        store.close()
    held = {"schema": sr.HELD_REFERENCE_SCHEMA, "selection_digest": selection.digest,
            "evidence": artifact.to_dict()}
elif selection_path:
    from scripts.kernel_rnd.autokernel.loop import scheduling, serial_scheduling as ss
    from scripts.kernel_rnd.autokernel.loop.measurement_capture import ArtifactStore
    selection = scheduling.Selection.from_dict(json.loads(Path(selection_path).read_text()))
    if mode == "fail_preclaim":
        (out / "loop-preclaim-failure.json").write_text(json.dumps({
            "schema": "epyc.autokernel.preclaim_failure.v1",
            "selection_digest": selection.digest, "target": identity,
            "error_type": "ClaimRefused"}))
        sys.exit(3)
    proposal = selection.proposal
    def observation(pid, suffix):
        inode = sum(map(ord, suffix))
        return {"observed_at": 1.0, "started_monotonic_s": 1.0,
                "ended_monotonic_s": 1.1, "owner_pid": pid, "error": None,
                "status": "held", "locks": [{"path": "/locks/" + suffix,
                "device": 1, "inode": inode, "path_unchanged": True,
                "owners": [{"pid": pid, "kernel_row": "original"}],
                "same_holder": True}]}
    def component(device, start, end, fraction, suffix, gpu):
        pid = __import__('os').getpid()
        domain = {"kind": "direct_loop", "clock": "monotonic", "pid": pid,
                  "boot_id": "fixture-boot", "process_start_ticks": 1, "error": None}
        opened = observation(pid, suffix)
        inode = opened["locks"][0]["inode"]
        return {"context_id": ss._digest({"domain": domain, "started_at": start,
                                          "locks": opened["locks"]}),
                "domain": domain, "ownership_generation": 1, "allocation_generation": 1,
                "started_at": start, "ended_at": end, "device_id": device,
                "physical_claim_ids": [f"fixture-boot:flock:1:{inode}"],
                "physical_region_fraction": fraction, "gpu_device_ids": gpu,
                "memory_reservation_bytes": proposal.estimated_claims.memory_reservation_bytes,
                "affinity_cores": ["0"], "open": opened,
                "close": observation(pid, suffix), "released": True}
    base = float(int(out.name.rsplit("-", 1)[-1]) * 100)
    components = [component("cpu", base + 1.0, base + 4.0,
                            proposal.estimated_claims.physical_region_fraction,
                            "cpu", [])]
    if proposal.backend == "gpu":
        components[0]["ended_at"] = base + 6.0
        components.append(component(proposal.estimated_claims.gpu_devices[0], base + 2.0,
                                    base + 5.0,
                                    0.0, "gpu", list(proposal.estimated_claims.gpu_devices)))
    store = ArtifactStore(out / "held-claim-artifacts")
    try:
        artifact = store.write("direct-held-intervals", {
            "schema": ss.INTERVAL_SCHEMA, "selection": selection.to_dict(),
            "selection_digest": selection.digest, "target": identity,
            "components": components}).to_dict()
    finally:
        store.close()
    held = {"schema": ss.REFERENCE_SCHEMA, "selection_digest": selection.digest,
            "evidence": artifact}
    if mode == "fail_postclaim_publish":
        sys.exit(3)
    if mode == "fail_held":
        (out / "loop-held-claims.json").write_text(json.dumps(held))
        sys.exit(3)
    if mode == "gpu_missing_zero" and target_id == "gpu":
        (out / "loop-held-claims.json").write_text(json.dumps(held))
        sys.exit(0)
result_only_failure = mode == "gpu_result_only_failure" and target_id == "gpu"
lane_failure = mode == "lane_error"
science_abstention = mode == "abstained"
count = 0 if stopped[0] else int(sr.option(argv, "--iterations"))
prior = sr.option(argv, "--resume-run")
anchor = Path(sr.option(argv, "--anchor-build"))
if prior:
    original, _ = sr.load_resume(Path(prior), argv)
    anchor = Path(original["current_anchor"]["path"])
row = sr.continuation(argv=argv, binding=sr.input_binding(argv),
    terminal="stopped" if stopped[0] else "complete",
    worktree=sr.option(argv, "--worktree"),
    branch=sr.option(argv, "--experimental-branch") if cpu else sr.champion.CANONICAL_BRANCH,
    model=selected.execution.model.path, selected_target=identity,
    anchor_build=anchor, anchor_commit=("b" if cpu else "a") * 40,
    cor_build=None if cpu else anchor, cor_commit=None if cpu else "a" * 40,
    iterations_requested=int(sr.option(argv, "--iterations")),
    outcomes=[SimpleNamespace(status="bench_failed") for _ in range(count)]
    if result_only_failure else
    [SimpleNamespace(status="lane_error") for _ in range(count)]
    if lane_failure else
    [SimpleNamespace(status="abstained") for _ in range(count)]
    if science_abstention else
    [SimpleNamespace(status="kept" if cpu else "measured_null") for _ in range(count)],
    **({"runtime_recipe_reference": {"locator": "runtime-selection-fixture",
       "sha256": "b" * 64, "verified": True}}
       if mode == "runtime_ref" and cpu else {}),
    **({"cpu_screen": {"scope": sr.option(argv, "--cpu-screen-scope"),
       "full_execution_digest": "c" * 64,
       "measured_execution_digest": "d" * 64, "candidate": None}}
       if cpu and sr.option(argv, "--cpu-screen-scope") else {}),
    **({"held_claim_evidence": held} if held else {}))
if result_only_failure:
    (out / "loop-run.json").write_text(json.dumps({
        "schema": "epyc.autokernel.loop_run.v1",
        "epoch": "e" * 64, "anchor_commit": "a" * 40,
        "surface": "serving:fixture", "pairs": 5, "noise_floor_pct": 1.0,
        "elapsed_s": 1.0, "workers": 1,
        "iterations": [{"status": "bench_failed", "turn_recorded_at":
                        "2026-09-10T00:00:00Z", "reason": "GPU setup failed"}],
        "phase_seconds": {"setup": 1.0}, "phase_seconds_are_lane_seconds": True,
        "pool": {"workers": 1, "wall_seconds": 1.0, "tail_seconds": 1.0,
                 "tail_fraction": 1.0, "superseded": 0},
        "continuation": row,
        "target": identity,
        "runtime_preparation": {"status": "fixture"},
        "launch_snapshot": "f" * 64, "floor_request_digest": "d" * 64,
        **({"held_claim_evidence": held} if held else {}),
    }))
    sys.exit(3)  # Crash/failure after the full result, before the routing receipt.
(out / "loop-run.json").write_text(json.dumps({"fixture": "not measurement evidence"}))
if mode == "wrong_args":
    row["input_argv"].append("--forged")
    row["input_argv_sha256"] = sr._digest(row["input_argv"])

from scripts.kernel_rnd.autokernel.loop import status
status.write(Path(sr.option(argv, "--store")), state="complete", epoch="fixture",
    campaign_id="ak-loop", anchor_commit=row["current_anchor"]["commit"],
    model=row["model"], surface="serving:fixture-"+target_id, pairs=5,
    noise_floor_pct=7.8, target=identity, champion_head=row["current_anchor"]["commit"],
    batch={"output_dir": str(out), "pid": __import__("os").getpid()},
    iterations_planned=row["iterations_requested"], outcomes=[{
        "status":"kept" if cpu else "measured_null", "mechanism_id":"synthetic-"+target_id,
        "reason":"fixture-only, no measured hardware gain"} for _ in range(count)])
(out / "loop-continuation.json").write_text(json.dumps(row))
