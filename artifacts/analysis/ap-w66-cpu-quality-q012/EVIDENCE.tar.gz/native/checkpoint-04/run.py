import os,json,subprocess,time,pathlib,urllib.request,socket,hashlib,signal,threading
D=pathlib.Path(__file__).parent
os.sched_setaffinity(0,set(range(72)))
B=pathlib.Path('/mnt/raid0/llm/kernels/builds/cpu-20261126-ce6fcbbde-c22-composite')
M='/mnt/raid0/llm/models/Qwen3.6-35B-A3B-MTP-Q8_0.gguf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'bin/libggml-cpu.so')=='7cafa501d43a31f318cf29e51d34549cbd1d002d15f8f705e0a25543cd5d9822'
for line in (B/'SHA256SUMS').read_text().splitlines():
 h,n=line.split(None,1)
 if n in ['bin/llama-server','bin/libllama.so','bin/libggml-base.so','bin/libllama-common.so']:assert sha(B/n)==h
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
env=dict(os.environ,LD_LIBRARY_PATH='/usr/lib/llvm-20/lib:'+str(B/'bin'),OMP_NUM_THREADS='72',OMP_PROC_BIND='true',OMP_PLACES=','.join('{'+str(i)+'}' for i in range(72)),GGML_IQK='1',ROCR_VISIBLE_DEVICES='',HIP_VISIBLE_DEVICES='')
argv=['numactl','--physcpubind=0-71','--interleave=0,1,2','--',str(B/'bin/llama-server'),'-m',M,'--host','127.0.0.1','--port',str(port),'--metrics','--slots','--jinja','-ngl','0','-fa','on','-np','1','-c','131072','-t','72','-tb','72','-b','2048','-ub','2048','-ctk','f16','-ctv','f16','--reasoning','off','--spec-type','draft-mtp','--spec-draft-n-max','2','--no-kv-unified','--cache-ram','0','--no-mmap','--slot-save-path',str(D/'slots')]
log=(D/'server.log').open('w');p=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
(D/'launch.json').write_text(json.dumps({'pid':p.pid,'argv':argv,'environment':{k:env[k]for k in ['LD_LIBRARY_PATH','OMP_NUM_THREADS','OMP_PROC_BIND','OMP_PLACES','GGML_IQK','ROCR_VISIBLE_DEVICES','HIP_VISIBLE_DEVICES']},'source':json.loads((B/'BUILD-OK.json').read_text()),'started':time.time()},indent=2))
base=f'http://127.0.0.1:{port}'
def call(path,obj=None):
 req=urllib.request.Request(base+path,data=json.dumps(obj).encode() if obj is not None else None,headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=600))
stop=threading.Event()
def monitor():
 with (D/'resources.jsonl').open('w')as f:
  while not stop.wait(2):
   if p.poll() is not None:return
   statuses=[]
   for t in pathlib.Path(f'/proc/{p.pid}/task').glob('*/status'):
    try:
     vals={k:v.strip() for k,v in [x.split(':',1)for x in t.read_text().splitlines()if ':' in x]}
     statuses.append(vals['Cpus_allowed_list'])
    except FileNotFoundError:pass
   numa={}
   try:
    for line in pathlib.Path(f'/proc/{p.pid}/numa_maps').read_text().splitlines():
     for tok in line.split():
      if len(tok)>2 and tok[0]=='N' and tok[1].isdigit() and '='in tok:
       k,v=tok.split('=');numa[k]=numa.get(k,0)+int(v)
   except FileNotFoundError:pass
   rec={'time':time.time(),'affinities':sorted(set(statuses)),'threads':len(statuses),'numa_pages':numa,'kfd_present':pathlib.Path(f'/sys/class/kfd/kfd/proc/{p.pid}').exists()}
   f.write(json.dumps(rec)+'\n');f.flush()
   for a in statuses:
    for r in a.split(','):
     x=r.split('-');assert 0<=int(x[0])<=int(x[-1])<=71,a
   assert not rec['kfd_present']
threading.Thread(target=monitor,daemon=True).start()
try:
 for i in range(300):
  if p.poll()is not None:raise RuntimeError('server died')
  try:
   call('/health');break
  except Exception:time.sleep(1)
 else:raise RuntimeError('health timeout')
 import sys,shutil,gzip,sqlite3
 stock=pathlib.Path('/mnt/raid0/llm/tmp/ws58-a3b-frozen-revalidation-20261126/stock')
 sys.path.insert(0,str(stock))
 import sandbox,transport,drive
 original_docker=sandbox.docker
 def confined_docker(*args,**kwargs):
  if args[0]=='create':args=(args[0],'--cpuset-mems','0,1,2','--env','GIT_CONFIG_COUNT=1','--env','GIT_CONFIG_KEY_0=grep.threads','--env','GIT_CONFIG_VALUE_0=1','--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1',*args[1:])
  return original_docker(*args,**kwargs)
 sandbox.docker=confined_docker
 def api(self,path,data=None,*,method=None):
  args=['python3','-B','/bin/case-form.py',path,method or ('GET'if data is None else'POST')]
  if data is not None:args.append(json.dumps(data))
  r=self.command(args,capture_output=True,text=True)
  if r.returncode:raise RuntimeError(r.stderr)
  if not r.stdout:return None
  x=json.loads(r.stdout)
  return x['data']if isinstance(x,dict)and'data'in x else x
 sandbox.Sandbox.api=api
 checkpoint=json.loads((D/'checkpoint.json').read_text())
 old=pathlib.Path(checkpoint['source'])
 sid=checkpoint['session_id']
 followup=json.loads((old/'protocol.json').read_text())['guidance']
 protocol={'question':'Does preservation retain real W66 repair quality and speed on the same resumed inspection checkpoint?','source':checkpoint,'followup':followup,'wall_s_per_arm_after_warm':600,'request_cap':8192,'total_generated_per_arm':16000,'thinking':False,'sampling':{'temperature':0.6,'top_p':0.95,'top_k':20,'min_p':0.0,'presence_penalty':0.0,'repeat_penalty':1.0,'seed':223355},'stop':'two bounded continuations and independent original/scope/substitution grades; no autonomous-loop activation'}
 (D/'protocol.json').write_text(json.dumps(protocol,indent=2))
 tests=['python3','-m','pytest','-q','scripts/kernel_rnd/autokernel/loop/test_runtime_keep_source_continuity.py','scripts/kernel_rnd/autokernel/loop/test_serial_run.py::test_actual_cpu_post_keep_resume_rebinds_original_launch_without_recalibration']
 for preserve in [False,True]:
  arm=D/('preserve-on'if preserve else'preserve-off');arm.mkdir()
  call('/slots/0?action=erase',{})
  warm=json.loads(gzip.decompress(pathlib.Path(checkpoint['last_request']).read_bytes()))
  warm['stream']=False;warm.pop('stream_options',None);warm['max_completion_tokens']=1
  warm['chat_template_kwargs'].update(preserve_thinking=preserve,preserve_reasoning=preserve,enable_thinking=False)
  t0=time.monotonic();result=call('/v1/chat/completions',warm)
  (arm/'warm.json').write_text(json.dumps({'wall_s':time.monotonic()-t0,'result':result},indent=2))
  limits=transport.Limits(wall_s=600,output_cap=8192,cumulative_output=16000)
  with transport.proxy(port,arm/'wire',limits=limits,backend='cpu',slot=0,task='DS41-W-66',label=arm.name,thinking=False,sampling=protocol['sampling'])as proxy:
   proxy.preserve_resume=preserve
   box=sandbox.Sandbox(arm/'sandbox',proxy.server_port,cpus='0-71',ctx=131072,cap=8192,form_api=True)
   shutil.copytree(old/'preserve-off/sandbox/work',box.workspace,dirs_exist_ok=True)
   shutil.copytree(old/'preserve-off/sandbox/session',box.session,dirs_exist_ok=True)
   db=box.session/'data/opencode/opencode.db'
   for suffix in ['-wal','-shm']:
    f=pathlib.Path(str(db)+suffix)
    if f.exists():f.unlink()
   shutil.copy2(D/'checkpoint.db',db)
   with box.running():
    restored=box.export(sid);(arm/'restored-session.json').write_text(json.dumps(restored,indent=2))
    t0=time.monotonic();status='returned'
    try:
     session,export,answers=drive.run(box,limits,proxy.rows,followup,session=sid)
     (arm/'followup-session.json').write_text(json.dumps(export,indent=2))
     (arm/'followup-answers.json').write_text(json.dumps(answers,indent=2))
    except TimeoutError:
     status='timeout'
     (arm/'followup-session.json').write_text(json.dumps(box.export(sid),indent=2))
    # Wait for the acknowledged interruption to settle before freezing bytes.
    for i in range(40):
     if not box.active():break
     time.sleep(.25)
    else:raise RuntimeError('session still active after interrupt')
    check=box.command(tests,capture_output=True,text=True,timeout=90)
    (arm/'followup-tests.log').write_text(check.stdout+check.stderr)
    (arm/'followup.patch').write_bytes(subprocess.check_output(['git','-C',str(box.workspace),'diff','--binary']))
    changed=subprocess.check_output(['git','-C',str(box.workspace),'diff','--name-only'],text=True).splitlines()
    rec={'status':status,'test_rc':check.returncode,'wall_s':time.monotonic()-t0,'session':sid,'generated_tokens':limits.observed,'unknown_requests':limits.unknown,'requests':len(proxy.rows),'changed':changed,'scope_ok':changed==['scripts/kernel_rnd/autokernel/loop/test_runtime_keep_source_continuity.py']}
    tmp=arm/'followup-result.tmp';tmp.write_text(json.dumps(rec,indent=2));tmp.rename(arm/'followup-result.json')
    print(arm.name,json.dumps(rec),flush=True)

finally:
 stop.set()
 if p.poll()is None:
  p.terminate()
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 (D/'cleanup.json').write_text(json.dumps({'pid':p.pid,'returncode':p.returncode,'exists':pathlib.Path(f'/proc/{p.pid}').exists(),'ended':time.time()}))
