import os,json,subprocess,time,pathlib,urllib.request,socket,hashlib,signal,threading
D=pathlib.Path(__file__).parent
os.sched_setaffinity(0,set(range(72)))
B=pathlib.Path('/mnt/raid0/llm/kernels/builds/cpu-20261126-ce6fcbbde-c22-composite')
M='/mnt/raid0/llm/models/Qwen3.6-35B-A3B-MTP-Q8_0.gguf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'bin/libggml-cpu.so')=='7cafa501d43a31f318cf29e51d34549cbd1d002d15f8f705e0a25543cd5d9822'
for line in (B/'SHA256SUMS').read_text().splitlines():
 h,n=line.split(None,1)
 if n in ['bin/llama-server','bin/libllama.so','bin/libggml-base.so','bin/libllama-common.so']:assert sha(B/n)==h
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
env=dict(os.environ,LD_LIBRARY_PATH='/usr/lib/llvm-20/lib:'+str(B/'bin'),OMP_NUM_THREADS='72',OMP_PROC_BIND='true',OMP_PLACES=','.join('{'+str(i)+'}' for i in range(72)),GGML_IQK='1',ROCR_VISIBLE_DEVICES='',HIP_VISIBLE_DEVICES='')
argv=['numactl','--physcpubind=0-71','--interleave=0,1,2','--',str(B/'bin/llama-server'),'-m',M,'--host','127.0.0.1','--port',str(port),'--metrics','--slots','--jinja','-ngl','0','-fa','on','-np','1','-c','131072','-t','72','-tb','72','-b','2048','-ub','2048','-ctk','f16','-ctv','f16','--reasoning','off','--spec-type','draft-mtp','--spec-draft-n-max','2','--no-kv-unified','--cache-ram','0','--no-mmap','--slot-save-path',str(D/'slots')]
log=(D/'server.log').open('w');p=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
(D/'launch.json').write_text(json.dumps({'pid':p.pid,'argv':argv,'environment':{k:env[k]for k in ['LD_LIBRARY_PATH','OMP_NUM_THREADS','OMP_PROC_BIND','OMP_PLACES','GGML_IQK','ROCR_VISIBLE_DEVICES','HIP_VISIBLE_DEVICES']},'source':json.loads((B/'BUILD-OK.json').read_text()),'started':time.time()},indent=2))
base=f'http://127.0.0.1:{port}'
def call(path,obj=None):
 req=urllib.request.Request(base+path,data=json.dumps(obj).encode() if obj is not None else None,headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=600))
stop=threading.Event()
def monitor():
 with (D/'resources.jsonl').open('w')as f:
  while not stop.wait(2):
   if p.poll() is not None:return
   statuses=[]
   for t in pathlib.Path(f'/proc/{p.pid}/task').glob('*/status'):
    try:
     vals={k:v.strip() for k,v in [x.split(':',1)for x in t.read_text().splitlines()if ':' in x]}
     statuses.append(vals['Cpus_allowed_list'])
    except FileNotFoundError:pass
   numa={}
   try:
    for line in pathlib.Path(f'/proc/{p.pid}/numa_maps').read_text().splitlines():
     for tok in line.split():
      if len(tok)>2 and tok[0]=='N' and tok[1].isdigit() and '='in tok:
       k,v=tok.split('=');numa[k]=numa.get(k,0)+int(v)
   except FileNotFoundError:pass
   rec={'time':time.time(),'affinities':sorted(set(statuses)),'threads':len(statuses),'numa_pages':numa,'kfd_present':pathlib.Path(f'/sys/class/kfd/kfd/proc/{p.pid}').exists()}
   f.write(json.dumps(rec)+'\n');f.flush()
   for a in statuses:
    for r in a.split(','):
     x=r.split('-');assert 0<=int(x[0])<=int(x[-1])<=71,a
   assert not rec['kfd_present']
threading.Thread(target=monitor,daemon=True).start()
try:
 for i in range(300):
  if p.poll()is not None:raise RuntimeError('server died')
  try:
   call('/health');break
  except Exception:time.sleep(1)
 else:raise RuntimeError('health timeout')
 import sys,shutil,importlib.util
 stock=pathlib.Path('/mnt/raid0/llm/tmp/ws58-a3b-frozen-revalidation-20261126/stock')
 sys.path.insert(0,str(stock))
 import sandbox,transport,drive
 original_docker=sandbox.docker
 def confined_docker(*args,**kwargs):
  if args[0]=='create':args=(args[0],'--cpuset-mems','0,1,2','--env','GIT_CONFIG_COUNT=1','--env','GIT_CONFIG_KEY_0=grep.threads','--env','GIT_CONFIG_VALUE_0=1','--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1',*args[1:])
  return original_docker(*args,**kwargs)
 sandbox.docker=confined_docker
 case=pathlib.Path('/mnt/raid0/llm/tmp/ws58-a3b-revalidate-20261126/coverage/w66-light-brief-v2/cases/DS41-W-66')
 prompt=(case/'prompt.md').read_text()
 followup="Run the listed acceptance checks again. Verify the repaired fixture still proves that the continuation carries the exact receipt produced by selection_reference. It must reject a substituted receipt with identical JSON payload but different locator and digest. Preserve the original private-lock isolation and other assertions, and repair only the allowlisted test module if needed."
 (D/'protocol.json').write_text(json.dumps({'question':'Does consistent reasoning preservation retain real W66 repair quality through a follow-up turn?','source_case':str(case),'preserve_order':[False,True],'initial_wall_s':900,'total_wall_s':1200,'generated_budget':24000,'request_cap':8192,'thinking':False,'sampling':{'temperature':0,'seed':1234},'guidance':followup,'acceptance':'original tests, edit scope and independent substituted-receipt control','stop':'one initial and one common follow-up turn per arm, two arms only','scope':'CPU q0-q2 only; no main-only comparator'},indent=2))
 testargs=['python3','-m','pytest','-q','scripts/kernel_rnd/autokernel/loop/test_runtime_keep_source_continuity.py','scripts/kernel_rnd/autokernel/loop/test_serial_run.py::test_actual_cpu_post_keep_resume_rebinds_original_launch_without_recalibration']
 for preserve in [False,True]:
  arm=D/('preserve-on'if preserve else'preserve-off');arm.mkdir()
  call('/slots/0?action=erase',{})
  limits=transport.Limits(wall_s=1200,output_cap=8192,cumulative_output=24000)
  with transport.proxy(port,arm/'wire',limits=limits,backend='cpu',slot=0,task='DS41-W-66',label=arm.name,thinking=False,sampling={'temperature':0,'seed':1234})as proxy:
   proxy.preserve_resume=preserve
   box=sandbox.Sandbox(arm/'sandbox',proxy.server_port,cpus='0-71',ctx=131072,cap=8192,form_api=True)
   shutil.copytree(case/'baseline',box.workspace,dirs_exist_ok=True)
   subprocess.run(['git','init','-q',str(box.workspace)],check=True)
   subprocess.run(['git','-C',str(box.workspace),'add','.'],check=True)
   subprocess.run(['git','-C',str(box.workspace),'-c','user.name=Fixture','-c','user.email=fixture@local','commit','-qm','Pinned fixture'],check=True)
   with box.running():
    baseline=box.command(testargs,capture_output=True,text=True,timeout=90)
    (arm/'baseline.log').write_text(baseline.stdout+baseline.stderr)
    assert baseline.returncode==1 and 'FAILED' in baseline.stdout,(baseline.returncode,baseline.stdout[-2000:],baseline.stderr)
    rows=proxy.rows
    class Phase:
     def __init__(self,deadline):self.deadline=deadline
     def seconds_left(self):return max(0,self.deadline-time.monotonic())
    session=box.new_session()
    for phase,msg,wall in [('initial',prompt,900),('followup',followup,300)]:
     t0=time.monotonic();status='returned'
     try:
      session,export,answers=drive.run(box,Phase(min(limits.deadline,time.monotonic()+wall)),rows,msg,session=session)
      (arm/(phase+'-session.json')).write_text(json.dumps(export,indent=2))
      (arm/(phase+'-answers.json')).write_text(json.dumps(answers,indent=2))
     except TimeoutError:
      status='timeout'
      if session is None:
       active=box.active()
       (arm/(phase+'-active.json')).write_text(json.dumps(active))
     result=box.command(testargs,capture_output=True,text=True,timeout=90)
     (arm/(phase+'-tests.log')).write_text(result.stdout+result.stderr)
     patch=subprocess.check_output(['git','-C',str(box.workspace),'diff','--binary'])
     (arm/(phase+'.patch')).write_bytes(patch)
     changed=subprocess.check_output(['git','-C',str(box.workspace),'diff','--name-only'],text=True).splitlines()
     record={'status':status,'test_rc':result.returncode,'wall_s':time.monotonic()-t0,'session':session,'generated_tokens':limits.observed,'requests':len(rows),'changed':changed,'scope_ok':changed==['scripts/kernel_rnd/autokernel/loop/test_runtime_keep_source_continuity.py']}
     (arm/(phase+'-result.json')).write_text(json.dumps(record,indent=2));print(arm.name,phase,json.dumps(record),flush=True)
     if status=='timeout'and session is None:break
    (arm/'container-final.json').write_text(subprocess.check_output(['docker','inspect',box.container],text=True))

finally:
 stop.set()
 if p.poll()is None:
  p.terminate()
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 (D/'cleanup.json').write_text(json.dumps({'pid':p.pid,'returncode':p.returncode,'exists':pathlib.Path(f'/proc/{p.pid}').exists(),'ended':time.time()}))
