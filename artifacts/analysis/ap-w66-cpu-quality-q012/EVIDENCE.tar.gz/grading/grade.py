#!/usr/bin/env -S taskset -c 0-71 numactl --interleave=0,1,2 /usr/bin/python3 -B
"""Independently grade sealed CPU W66 patches without exposing host service state."""
import argparse
import ast
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
RUN = HERE.with_name("w66-cpu-quality-q012") / "checkpoint-04"
OLD = HERE.with_name("ws58-a3b-revalidate-20261126")
CASE = OLD / "coverage/w66-light-brief-v2/cases/DS41-W-66"
STOCK_DEPS = HERE.with_name("ws58-a3b-frozen-revalidation-20261126") / "stock/py312-deps"
SOURCE = "scripts/kernel_rnd/autokernel/loop/test_runtime_keep_source_continuity.py"
SOURCE_TEST = "test_runtime_keep_then_source_reuses_actual_recipe_and_fresh_source_floor"
SERIAL_TEST = "test_actual_cpu_post_keep_resume_rebinds_original_launch_without_recalibration"
APP_PATH = "src/runtime/cpu_region_lock.py"
APP_REV = "332ceb2e14d16f2031bd17b1f7c839ce8276a24b"
APP_SHA = "a94b7cb2613f4ceb13ef1928627e06f9749512e14b0127e5e8de793019ac297f"
CASE_SHA = "2b155290349cae145c253bc57411d6b699ef1d1fc42abd3e9abce5889253f61f"
ORACLE_SHA = "54968138d7f0005acbe2f1c9ad07706015cab7baebb1e73f4d114ec84d9b8d5a"
OBSERVER_SHA = "2b251ee54206e8281640c776634e5b88cbf42409fcc5bc7b0781acd9f1055f4d"
GOLDEN_PATCH = OLD / ("coverage/persistent-w66-light-identity/runs/identity-01/units/"
                      "gpu-DS41-W-66-off-common-light-v2-identity-1/independent/candidate.patch")
GOLDEN_SHA = "86e3e718041bbf66303640a45008fe0c78c700d705a7b35b0252621c93e97c1b"
CHECKS_MOUNT = "/grading/trusted/checks"
IMAGE = "sha256:9c429a17180a9b3ce2bce942d1bb05a7b7dfbf8218edbc267d190c35fe2b7635"
ARMS = ("preserve-off", "preserve-on")
PHASES = ("followup",)
BOUND = ["taskset", "-c", "0-71"]
RECEIPT_ASSERTION = 'assert continuation["runtime_recipe_reference"] == {"locator": "fixture-runtime-selection", "sha256": "b" * 64, "verified": True}'


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def read_pin(path, expected):
    blob = path.read_bytes()
    if digest(blob) != expected:
        raise ValueError(f"Unexpected pinned content at {path}")
    return blob


def write_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
    temporary.replace(path)


def run(arguments, **kwargs):
    return subprocess.run([*BOUND, *arguments], capture_output=True, **kwargs)


def tracked_tree(root):
    tree = {}
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"Symlink in staged source at {path}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError(f"Nonregular staged source at {path}")
        st = path.stat()
        tree[path.relative_to(root).as_posix()] = {
            "bytes": st.st_size, "executable": bool(st.st_mode & 0o111), "sha256": digest(path.read_bytes()),
        }
    return tree


def assertions(source):
    return Counter(ast.unparse(node) for node in ast.walk(ast.parse(source)) if isinstance(node, ast.Assert))


def static_review(work):
    original = assertions((CASE / "baseline" / SOURCE).read_text())
    replacement = next(iter(assertions(RECEIPT_ASSERTION)))
    assert original.pop(replacement) == 1
    candidate = assertions((work / SOURCE).read_text())
    return {"original_nonreceipt_assertions_missing_verbatim": list((original - candidate).elements())}


def snapshot(arm, phase):
    source = RUN / arm
    patch = source / f"{phase}.patch"
    terminal = source / f"{phase}-result.json"
    if not patch.is_file() or not terminal.is_file():
        return None
    terminal_bytes = terminal.read_bytes()
    try:
        receipt = json.loads(terminal_bytes)
    except json.JSONDecodeError:
        return None
    raw = patch.read_bytes()
    if raw != patch.read_bytes() or terminal_bytes != terminal.read_bytes():
        return None
    return raw, receipt, digest(terminal_bytes)


def stage_patch(work, frozen, baseline):
    raw = frozen.read_bytes()
    if not raw:
        return {"scope_pass": False, "reason": "empty patch"}
    stats = run(["git", "apply", "--numstat", "-z", "--", str(frozen)], cwd=work, check=True, timeout=15)
    paths = [row.split(b"\t", 2)[-1].decode() for row in stats.stdout.rstrip(b"\0").split(b"\0")]
    if paths != [SOURCE]:
        return {"scope_pass": False, "patch_paths": paths}
    run(["git", "-c", "core.hooksPath=/dev/null", "apply", "--", str(frozen)],
        cwd=work, check=True, timeout=15)
    after = tracked_tree(work)
    changed = sorted(path for path in baseline.keys() | after.keys() if baseline.get(path) != after.get(path))
    return {
        "scope_pass": changed == [SOURCE] and SOURCE in after
        and baseline[SOURCE]["executable"] == after[SOURCE]["executable"],
        "changed": changed,
        "source": after.get(SOURCE),
    }


def mount(path, target, readonly=True):
    options = f"type=bind,source={path.resolve(strict=True)},target={target}"
    return ["--mount", options + (",readonly" if readonly else "")]


def grade_tests(work, checks, private, output, mode):
    output.mkdir()
    scratch = private / mode
    scratch.mkdir()
    (scratch / "home").mkdir()
    (scratch / "root/scripts/vidya/adapters").mkdir(parents=True)
    env = {
        "HOME": "/private/home",
        "TMPDIR": "/private",
        "EPYC_ROOT_REPO": "/private/root",
        "EPYC_ORCHESTRATOR_REPO": "/app",
        "PYTHONPATH": "/python-packages",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTEST_ADDOPTS": "--junitxml=/evidence/junit.xml",
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "NO_COLOR": "1",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": "grep.threads",
        "GIT_CONFIG_VALUE_0": "1",
    }
    arguments = [
        "docker", "run", "--rm", "--pull", "never", "--network", "none", "--read-only",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--user", f"{os.getuid()}:{os.getgid()}",
        "--cpuset-cpus", "0-71", "--cpuset-mems", "0,1,2", "--memory", "1g", "--pids-limit", "64",
        "--workdir", "/case", "--entrypoint", "/usr/bin/timeout",
        *mount(work, "/case"), *mount(checks, CHECKS_MOUNT), *mount(private / "app", "/app"),
        *mount(STOCK_DEPS, "/python-packages"), *mount(output, "/evidence", readonly=False),
        *mount(scratch, "/private", readonly=False),
    ]
    for name, value in env.items():
        arguments += ["--env", f"{name}={value}"]
    arguments += [IMAGE, "90", "/usr/bin/taskset", "-c", "0-71", "/usr/bin/python3", "-B"]
    if mode == "baseline":
        arguments += [f"{CHECKS_MOUNT}/oracle.py", "--pytest", "/private/pytest"]
    else:
        arguments += [
            f"{CHECKS_MOUNT}/observer.py", f"{CHECKS_MOUNT}/oracle.py", "/private/pytest", mode, "/evidence/OBSERVATION.json",
        ]
    result = run(arguments, timeout=110)
    (output / "stdout.log").write_bytes(result.stdout)
    (output / "stderr.log").write_bytes(result.stderr)
    junit = output / "junit.xml"
    cases = {}
    if junit.is_file():
        for case in ET.parse(junit).iter("testcase"):
            error = next(iter(case), None)
            cases[case.attrib["name"]] = (
                {"outcome": "passed"} if error is None else
                {"outcome": error.tag, "message": error.attrib.get("message"), "trace": error.text}
            )
    observation = output / "OBSERVATION.json"
    status = {
        "exit": result.returncode, "tests": cases,
        "observation": json.loads(observation.read_bytes()) if observation.is_file() else None,
        "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr),
    }
    write_json(output / "RESULT.json", status)
    return status


def exercised_receipt(run):
    obs = run["observation"] or {}
    routing = obs.get("routing") or {}
    return (
        obs.get("rc") == run["exit"] and obs.get("oracle_claim_observations") == 2
        and obs.get("journal_completion_observations", 0) > 0
        and routing.get("phase_verified_before_change") is True
        and routing.get("original_read_proof_verified") is True
        and bool(routing.get("verified_runtime_journal_references"))
    )


def classify(normal, mutated):
    normal_pass = (
        normal["exit"] == 0 and exercised_receipt(normal)
        and {name: result["outcome"] for name, result in normal["tests"].items()}
        == {SOURCE_TEST: "passed", SERIAL_TEST: "passed"}
    )
    mutation = (mutated["observation"] or {}).get("routing") or {}
    original, replacement = mutation.get("original", {}), mutation.get("replacement", {})
    substituted = (
        exercised_receipt(mutated) and mutation.get("same_content") is True
        and original.get("locator") != replacement.get("locator")
        and original.get("sha256") != replacement.get("sha256")
    )
    source_test = mutated["tests"].get(SOURCE_TEST, {})
    source_failed = source_test.get("outcome") == "failure"
    fixture_assertion = (
        SOURCE in (source_test.get("trace") or "")
        and "AssertionError" in (source_test.get("message") or "")
    )
    if not substituted:
        control = "substitution_not_observed"
    elif mutated["exit"] == 0:
        control = "substitution_accepted"
    elif (mutated["exit"] == 1 and source_failed and fixture_assertion
          and mutated["tests"].get(SERIAL_TEST, {}).get("outcome") == "passed"):
        trace = source_test.get("trace") or ""
        changed_identity_in_trace = all(
            reference[key] in trace for reference in (original, replacement) for key in ("locator", "sha256")
        )
        control = "substitution_rejected" if changed_identity_in_trace else "fixture_assertion_failed_review_required"
    else:
        control = "unqualified_failure"
    return {"normal_pass": normal_pass, "mutation": control}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    control = parser.add_mutually_exclusive_group()
    control.add_argument("--baseline", action="store_true")
    control.add_argument("--positive-control", action="store_true")
    parser.add_argument("--arm", choices=ARMS)
    parser.add_argument("--phase", choices=PHASES)
    args = parser.parse_args()

    manifest = json.loads(read_pin(CASE / "case.json", CASE_SHA))
    assert manifest["editable_paths"] == [SOURCE]
    assert manifest["repo_base_sha"] == "dd090a874c22be58e09b18fc1fc86da7b46b1d85"
    assert manifest["oracle_sha256"] == ORACLE_SHA
    baseline = manifest["baseline_files"]
    assert tracked_tree(CASE / "baseline") == baseline
    oracle = read_pin(CASE / "oracle.py", ORACLE_SHA)
    observer = read_pin(OLD / "w66-receipt-identity-followup-grade/observer.py", OBSERVER_SHA)
    app = run(["git", "-C", "/workspace/repos/epyc-orchestrator", "show", f"{APP_REV}:{APP_PATH}"],
              check=True, timeout=15).stdout
    assert digest(app) == APP_SHA

    if args.baseline:
        jobs = [("baseline", "original", None)]
    elif args.positive_control:
        jobs = [("historical-control", "prequalified", (read_pin(GOLDEN_PATCH, GOLDEN_SHA), None, None))]
    else:
        jobs = [
            (arm, phase, snapshot(arm, phase))
            for arm in ((args.arm,) if args.arm else ARMS)
            for phase in ((args.phase,) if args.phase else PHASES)
        ]
    for arm, phase, inputs in jobs:
        if inputs is None and not args.baseline:
            print(json.dumps({"arm": arm, "phase": phase, "status": "pending"}), flush=True)
            continue
        output = HERE / "runs" / arm / phase
        if (output / "RESULT.json").exists():
            print(json.dumps(json.loads((output / "RESULT.json").read_bytes())), flush=True)
            continue
        output.mkdir(parents=True, exist_ok=False)
        summary = {
            "arm": arm, "phase": phase, "case_sha256": CASE_SHA, "oracle_sha256": ORACLE_SHA,
            "observer_sha256": OBSERVER_SHA, "app_commit": APP_REV, "app_sha256": APP_SHA,
            "baseline_file_count": len(baseline), "image": IMAGE, "model_calls": 0,
            "isolated_environment": {"git_grep_threads": 1, "cpuset": "0-71", "memory_nodes": [0, 1, 2]},
        }
        with TemporaryDirectory(prefix="private-", dir=output) as directory:
            private = Path(directory)
            checks = private / "checks"
            checks.mkdir()
            (checks / "oracle.py").write_bytes(oracle)
            (checks / "observer.py").write_bytes(observer)
            app_destination = private / "app" / APP_PATH
            app_destination.parent.mkdir(parents=True)
            app_destination.write_bytes(app)
            work = private / "candidate"
            shutil.copytree(CASE / "baseline", work)
            assert tracked_tree(work) == baseline
            if args.baseline:
                baseline_run = grade_tests(work, checks, private, output / "baseline", "baseline")
                summary["test_exit"] = baseline_run["exit"]
                outcomes = {name: result["outcome"] for name, result in baseline_run["tests"].items()}
                summary["negative_control_pass"] = (
                    baseline_run["exit"] == 1 and outcomes.get(SOURCE_TEST) == "failure"
                    and outcomes.get(SERIAL_TEST) == "passed"
                    and "FileNotFoundError" in (baseline_run["tests"][SOURCE_TEST].get("trace") or "")
                )
            else:
                patch, terminal, terminal_sha = inputs
                frozen = output / "candidate.patch"
                staging = output / "candidate.patch.tmp"
                staging.write_bytes(patch)
                staging.chmod(0o444)
                staging.replace(frozen)
                summary.update(
                    patch_sha256=digest(patch), worker_terminal=terminal, worker_terminal_sha256=terminal_sha,
                )
                try:
                    summary.update(stage_patch(work, frozen, baseline))
                except (subprocess.CalledProcessError, ValueError) as error:
                    summary.update(scope_pass=False, scope_error=str(error))
                if summary["scope_pass"]:
                    try:
                        summary.update(static_review(work))
                    except SyntaxError as error:
                        summary["source_syntax_error"] = str(error)
                    expected = tracked_tree(work)
                    normal = grade_tests(work, checks, private, output / "original", "original")
                    mutated = grade_tests(work, checks, private, output / "mutated", "mutated")
                    assert tracked_tree(work) == expected
                    summary.update(classify(normal, mutated))
            write_json(output / "RESULT.json", summary)
        print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
