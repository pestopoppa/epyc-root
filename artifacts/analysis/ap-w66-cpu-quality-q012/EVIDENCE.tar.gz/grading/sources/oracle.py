"""Independent regression check for DS41-W-66."""
import hashlib
import importlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / "ws58-a3b-finish-20261126"
LOOP = "scripts/kernel_rnd/autokernel/loop"
TESTS = [
    f"{LOOP}/test_runtime_keep_source_continuity.py::test_runtime_keep_then_source_reuses_actual_recipe_and_fresh_source_floor",
    f"{LOOP}/test_serial_run.py::test_actual_cpu_post_keep_resume_rebinds_original_launch_without_recalibration",
]


class ObserveIsolation:
    def __init__(self, base):
        self.base = Path(base)
        self.calls = 0
        self.completions = 0

    def pytest_runtest_call(self, item):
        prefix = item.module.__package__
        claim = importlib.import_module(f"{prefix}.claim")
        assert claim.DEVICE_LOCK.is_relative_to(self.base), claim.DEVICE_LOCK
        assert Path(os.environ["ORCHESTRATOR_TMP_DIR"]).is_relative_to(self.base)
        assert claim.INHERITED_DEVICE_LOCK_ENV not in os.environ
        self.calls += 1
        if "runtime_keep_then_source" in item.name:
            journal = importlib.import_module(f"{prefix}.phase_journal")
            original = journal._verify_terminal

            def observe(row, store):
                original(row, store)
                if (row["event"] == "COMPLETE" and row["phase"] == "integration"
                        and row["mutation"]["kind"] == "runtime"):
                    name, _, digest = row["result"].rpartition("#")
                    receipt = Path(name)
                    assert receipt.is_relative_to(self.base.parent), receipt
                    assert hashlib.sha256(receipt.read_bytes()).hexdigest() == digest
                    self.completions += 1

            item.funcargs["monkeypatch"].setattr(journal, "_verify_terminal", observe)


def run_pytest():
    import pytest

    check = ObserveIsolation(sys.argv[2])
    rc = pytest.main(["-q", "-p", "no:cacheprovider", "--basetemp", sys.argv[2], *TESTS],
                     plugins=[check])
    if rc == 0 and (check.calls != 2 or check.completions < 1):
        raise SystemExit("Expected two isolated calls and one verified runtime completion")
    raise SystemExit(rc)


def main():
    checkout = Path(sys.argv[1]).resolve()
    with tempfile.TemporaryDirectory(prefix="ds41-w66-", dir=HERE / "research-tmp") as tmp:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_ADDOPTS="",
                   OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1",
                   EPYC_ROOT_REPO=str(ROOT), EPYC_ORCHESTRATOR_REPO=str(HERE / "app"), TMPDIR=tmp)
        subprocess.run(["taskset", "-c", "180-183", "/usr/bin/python3", str(Path(__file__).resolve()),
                        "--pytest", str(Path(tmp) / "pytest")], cwd=checkout, env=env,
                       timeout=60, check=True)


if __name__ == "__main__":
    if sys.argv[1] == "--pytest":
        run_pytest()
    else:
        main()
