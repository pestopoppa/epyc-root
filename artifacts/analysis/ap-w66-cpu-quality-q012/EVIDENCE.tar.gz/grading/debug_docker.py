import grade
from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
out = grade.HERE / "runs/docker-diagnostic"
out.mkdir()
with TemporaryDirectory(dir=out) as d:
    private = Path(d)
    work = private / "candidate"
    shutil.copytree(grade.CASE / "baseline", work)
    baseline = grade.tracked_tree(work)
    grade.stage_patch(work, grade.GOLDEN_PATCH, baseline)
    checks = private / "checks"
    checks.mkdir()
    shutil.copy2(grade.CASE / "oracle.py", checks / "oracle.py")
    old = (grade.OLD / "w66-receipt-identity-followup-grade/observer.py").read_text()
    new = old.replace('                result = json.loads(detailed.read_bytes())', '                result = json.loads(detailed.read_bytes())\n                Path("/evidence/loop-run.diagnostic.json").write_bytes(detailed.read_bytes())')
    (checks / "observer.py").write_text(new)
    app = private / "app" / grade.APP_PATH
    app.parent.mkdir(parents=True)
    app.write_bytes(grade.run(["git", "-C", "/workspace/repos/epyc-orchestrator", "show",
                              f"{grade.APP_REV}:{grade.APP_PATH}"], check=True).stdout)
    grade.grade_tests(work, checks, private, out / "original", "original")
