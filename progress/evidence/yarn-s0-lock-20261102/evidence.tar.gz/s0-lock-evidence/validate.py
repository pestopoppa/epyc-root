#!/usr/bin/env python3
import collections,json
from pathlib import Path
D=Path(__file__).resolve().parent
r=json.loads((D/'result.json').read_text());t=json.loads((D/'trace-result.json').read_text());samples=[json.loads(x) for x in (D/'samples.jsonl').read_text().splitlines()];trace=[json.loads(x) for x in (D/'syscalls.jsonl').read_text().splitlines()]
assert t['exited']==0 and t['traced_pid']==r['owner']['pid'] and r['churn_exit']==0
assert len(trace)==t['recorded_stops']==t['syscall_stops_total'] and len(samples)==r['iterations']
assert all(x['phase']==('entry' if i%2==0 else 'exit') for i,x in enumerate(trace))
s,e=r['start']['monotonic_ns'],r['end']['monotonic_ns'];assert not [x for x in trace if s<=x['mono_ns']<=e]
before=[x for x in trace if x['mono_ns']<s][-1];after=[x for x in trace if x['mono_ns']>e][0]
assert before['nr']==after['nr']==61 and before['phase']=='entry' and after['phase']=='exit' and before['args'][0]==after['rax']
expected=r['start']['fd_rows'];assert r['end']['fd_rows']==expected
assert all(r['start']['owner_fdinfo'][n]['cloexec'] for n in ('GLOBAL','build'))
errs=[]
for i,x in enumerate(samples,1):
 assert x['iteration']==i
 for name in ('before','after'):
  obs=x[name];assert obs['fd_rows']==expected and obs['independent_flock']=={'GLOBAL':'exclusive_conflict','build':'exclusive_conflict'} and obs['observer_inherited_lock_fd'] is False
  assert all(obs['owner_fdinfo'][n]['cloexec'] for n in ('GLOBAL','build'))
 if x['old_guard']!='pass':errs.append({'iteration':i,'message':x['old_guard']})
assert errs==r['failures'] and any(x['message']=='lock lost' for x in errs)
print(json.dumps({'owner':r['owner']['pid'],'wait4_child':before['args'][0],'duration_s':(e-s)/1e9,'iterations':len(samples),'guard_outcomes':dict(collections.Counter(x['old_guard'] for x in samples)),'fd_and_probe_observations':2*len(samples),'cli_syscall_stops_in_window':0,'all_cli_stops':len(trace)},sort_keys=True))
