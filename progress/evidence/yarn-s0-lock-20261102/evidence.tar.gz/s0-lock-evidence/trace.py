#!/usr/bin/env python3
"""Trace only our direct child, the CLI, from exec through exit on Linux x86_64."""
import ctypes,json,os,platform,signal,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent
assert platform.machine()=='x86_64'
libc=ctypes.CDLL(None,use_errno=True);libc.ptrace.restype=ctypes.c_long
TRACEME=0;SYSCALL=24;GETREGS=12;SETOPTIONS=0x4200;TRACESYSGOOD=1
class Regs(ctypes.Structure):
 _fields_=[(n,ctypes.c_ulonglong) for n in ('r15','r14','r13','r12','rbp','rbx','r11','r10','r9','r8','rax','rcx','rdx','rsi','rdi','orig_rax','rip','cs','eflags','rsp','ss','fs_base','gs_base','ds','es','fs','gs')]
def ptrace(req,pid,addr=0,data=0):
 ctypes.set_errno(0);r=libc.ptrace(req,pid,ctypes.c_void_p(addr),ctypes.c_void_p(data))
 if r==-1 and ctypes.get_errno():raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
 return r
names={2:'open',3:'close',32:'dup',33:'dup2',56:'clone',57:'fork',58:'vfork',59:'execve',60:'exit',72:'fcntl',73:'flock',231:'exit_group',257:'openat',292:'dup3',322:'execveat',435:'clone3',436:'close_range',438:'pidfd_getfd',437:'openat2'}
root=D/'locks';root.mkdir();env=dict(os.environ,ORCHESTRATOR_TMP_DIR=str(root));os.chdir('/mnt/raid0/llm/epyc-orchestrator')
exe='/workspace/repos/epyc-orchestrator/.venv/bin/python3'
argv=[exe,'-m','src.runtime.region_lock_cli','run','--cpu-list','0-23','--role','build','--timeout-s','10','--tag','s0-v34-syscall-trace','--','/usr/bin/python3','-B',str(D/'observer.py')]
pid=os.fork()
if pid==0:
 try:ptrace(TRACEME,0);os.execve(exe,argv,env)
 finally:os._exit(127)
log=(D/'syscalls.jsonl').open('w',buffering=1);entering=True;events=0;total=0
try:
 got,status=os.waitpid(pid,0);assert got==pid and os.WIFSTOPPED(status) and os.WSTOPSIG(status)==signal.SIGTRAP
 ptrace(SETOPTIONS,pid,0,TRACESYSGOOD)
 while True:
  ptrace(SYSCALL,pid)
  got,status=os.waitpid(pid,0)
  if os.WIFEXITED(status):exitcode=os.WEXITSTATUS(status);break
  if os.WIFSIGNALED(status):exitcode=128+os.WTERMSIG(status);break
  sig=os.WSTOPSIG(status)
  if sig != (signal.SIGTRAP|0x80):
   # SIGCHLD is informational; all other unexpected stops fail the run.
   if sig==signal.SIGCHLD:continue
   raise RuntimeError('unexpected traced stop '+str(sig))
  regs=Regs();ptrace(GETREGS,pid,0,ctypes.addressof(regs));number=regs.orig_rax;total+=1
  if True:
   item={'mono_ns':time.monotonic_ns(),'phase':'entry' if entering else 'exit','nr':number,'name':names.get(number, 'sys_'+str(number)),'args':[regs.rdi,regs.rsi,regs.rdx,regs.r10,regs.r8,regs.r9],'rax':ctypes.c_longlong(regs.rax).value}
   log.write(json.dumps(item,sort_keys=True)+'\n');events+=1
  entering=not entering
finally:log.close()
summary={'traced_pid':pid,'exited':exitcode,'syscall_stops_total':total,'recorded_stops':events,'argv':argv,'options':['PTRACE_TRACEME','PTRACE_O_TRACESYSGOOD','PTRACE_SYSCALL'],'notes':'Only original CLI process traced; child not traced. Time sampled at syscall-stop after kernel entry/exit. Entry/exit phase alternates.'}
(D/'trace-result.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(exitcode)
