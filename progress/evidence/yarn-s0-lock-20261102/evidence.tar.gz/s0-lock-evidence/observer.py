#!/usr/bin/env python3
"""Observe unmodified v33 global-table guard under bounded private flock churn."""
import fcntl,importlib,importlib.util,json,os,subprocess,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent;S=D/'sources';sys.path.insert(0,str(S))
new=importlib.import_module('lock_witness')
spec=importlib.util.spec_from_file_location('old_witness',S/'old_witness.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
root=D/'locks';paths={n:root/('cpu_region.'+n+'.q0.lock') for n in ('GLOBAL','build')}
row=next(r for r in new.ancestors() if new.is_transport(r));auth=new.authenticate_cli(row)
def sample():
 rows=new.held(row,paths);probes={}
 for name,path in paths.items():
  with path.open('rb') as f:
   st=os.fstat(f.fileno());expected=rows[name]
   if (st.st_dev,st.st_ino)!=(expected['device'],expected['inode']):raise RuntimeError('probe inode mismatch')
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:probes[name]='exclusive_conflict'
   else:
    fcntl.flock(f,fcntl.LOCK_UN);raise RuntimeError('independent probe acquired '+name)
 details={}
 for name,record in rows.items():
  text=Path(f"/proc/{row['pid']}/fdinfo/{record['fd']}").read_text()
  flags=int(next(line.split()[1] for line in text.splitlines() if line.startswith('flags:')),8)
  if not flags & os.O_CLOEXEC:raise RuntimeError('lock fd missing CLOEXEC')
  details[name]={'fdinfo':text,'flags_octal':oct(flags),'cloexec':True}
 for fd in Path('/proc/self/fd').iterdir():
  try:st=fd.stat()
  except FileNotFoundError:continue
  if any((st.st_dev,st.st_ino)==(entry['device'],entry['inode']) for entry in rows.values()):raise RuntimeError('observer inherited a lock fd')
 return {'monotonic_ns':time.monotonic_ns(),'fd_rows':rows,'owner_fdinfo':details,'observer_inherited_lock_fd':False,'independent_flock':probes}
start=sample();churn_dir=D/'churn';churn_dir.mkdir();p=subprocess.Popen([sys.executable,'-B',str(S/'churn_locks.py'),str(churn_dir)],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
failures=[];count=0;last=start;deadline=time.monotonic()+9
try:
 with (D/'samples.jsonl').open('w',buffering=1) as out:
  while count<100000 and time.monotonic()<deadline:
   if p.poll() is not None:raise RuntimeError('churn exited prematurely')
   before=sample();error=None
   try:owner,identity=old.capture(paths['GLOBAL']);old.verify(owner,identity,paths['GLOBAL'])
   except RuntimeError as exc:error=str(exc)
   after=sample();count+=1
   record={'iteration':count,'before':before,'old_guard':error or 'pass','after':after}
   out.write(json.dumps(record,sort_keys=True)+'\n');last=after
   if error:failures.append({'iteration':count,'message':error})
finally:
 (churn_dir/'STOP').touch()
 try:p.wait(timeout=3)
 except subprocess.TimeoutExpired:
  p.terminate()
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:p.kill();p.wait(timeout=2)
 stderr=p.stderr.read().decode(errors='replace');p.stderr.close()
summary={'scope':'canonical CLI private locks, unrelated private churn, no inference','owner':row,'authentication':auth,'start':start,'end':last,'iterations':count,'failures':failures,'churn_pid':p.pid,'churn_exit':p.returncode,'churn_stderr':stderr,'window_bound_seconds':9,'continuous_lock_proof':False,'source_bound_at_runtime':False}
(D/'result.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'iterations':count,'failures':failures,'churn_exit':p.returncode}),flush=True)
