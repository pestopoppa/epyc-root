#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
m=json.loads((D/'MANIFEST.json').read_text())
for name,want in m['files'].items():
 p=D/name
 if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:raise SystemExit('mismatch: '+name)
print('manifest: '+str(len(m['files']))+' files verified')
