from pathlib import Path
import json,shutil
p=Path(__file__).parent
f=p/'capture.py';s=f.read_text().replace("mode='smoke' if os.environ.get('FILLER_DRYRUN')=='1' else 'official'","mode='capture-control'").replace("speed_arms=['Q4KM'] if os.environ.get('FILLER_DRYRUN')=='1' else ['Q4KM','IQ4KT','IQ2XXS','IQ2KT']","speed_arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT']").replace("paired_items=0 if os.environ.get('FILLER_DRYRUN')=='1' else 1","paired_items=1");a=s.index(" if run['mode']=='smoke' and row.get('kind')=='speed'");b=s.index('\n return row',a);s=s[:a]+s[b:];f.write_text(s)
f=p/'diagnostic.py';s=f.read_text().replace("arms=['Q4KM'] if mode=='smoke' else ['Q4KM','IQ4KT','IQ2XXS','IQ2KT']","arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT']").replace("if mode!='smoke':", "if True:");s=s.replace("out=Path(os.environ['OUT']);run=begin(out);", "out=Path(os.environ['OUT']);\nif len(os.sched_getaffinity(0))!=4 or os.environ['FILLER_THREADS']!='4':raise SystemExit('diagnostic requires exactly four allocated CPUs and four native threads')\nrun=begin(out);");f.write_text(s)
f=p/'run.sh';f.write_text('''#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-exp01-wire-20261104
ATTEMPT=$(python3 -c 'import uuid;print(uuid.uuid4().hex)')
export OUT="$D/control/$ATTEMPT" MODELSET="$D/models.env" CAP_S=900
mkdir -p "$OUT"
finish() {
 local rc=$?
 python3 "$D/reader.py" finalize "$OUT" "$rc" || return 1
}
trap finish EXIT
python3 "$D/diagnostic.py"
''')
f=p/'launch.sh';f.write_text('''#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-exp01-wire-20261104
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id vidya-exp01-proxy-wire-20261104 --class cpu --role bench --gpu-quiet none --claim-cpus "${WS58_REGIONS:-0-3}" --min-window 300 --stop "$D/STOP" --workdir "$D" --complete-cmd "python3 '$D/reader.py' complete '$D'" --precond-cmd "python3 '$D/capture.py' check" --cmd "/bin/bash '$D/run.sh'"
''')
f=p/'reader.py';s=f.read_text().replace("run.get('mode') not in ('official','smoke')", "run.get('mode')!='capture-control'").replace("arms=['Q4KM'] if run['mode']=='smoke' else ['Q4KM','IQ4KT','IQ2XXS','IQ2KT']", "arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT']").replace("paired_items=0 if run['mode']=='smoke' else 1","paired_items=1").replace("[:0 if run['mode']=='smoke' else 1]","[:1]").replace("terminal['state']='smoke-only' if run['mode']=='smoke' else 'complete-observation'", "terminal['state']='complete-capture-control'").replace("terminal.get('state')!=('smoke-only' if run['mode']=='smoke' else 'complete-observation')", "terminal.get('state')!='complete-capture-control'")
s=s.replace("finally:(out/'TERMINAL.json').write_text(json.dumps(terminal,sort_keys=True)+'\\n')", """finally:(out/'TERMINAL.json').write_text(json.dumps(terminal,sort_keys=True)+'\\n')
 verified=read(out)
 result=dict(schema='epyc.exp01.capture_control_result.v1',run_id=run['run_id'],purpose='source-capture-projection-control-only',measurement=False,state='complete',native_speed_units=4,fixed_paired_items=1,projected_observations=len(verified),source_sha256=run['source_sha256'],result_path=str(out/'NATIVE.json'),limitations=comparison['limitations'])
 data=json.dumps(result,sort_keys=True)+'\\n';(out/'RESULT.json').write_text(data)
 if os.environ.get('FILLER_DRYRUN_RESULT_PATH'):Path(os.environ['FILLER_DRYRUN_RESULT_PATH']).write_text(data)
 (P/'LATEST_COMPLETE.json').write_text(json.dumps(dict(out=str(out),run_id=run['run_id'],source_sha256=run['source_sha256']))+'\\n')""")
a=s.index("   mode='smoke' if os.environ.get(");b=s.index("  else:print(json.dumps(read(sys.argv[1])))",a)
s=s[:a]+"""   pointer=load(Path(sys.argv[2])/'LATEST_COMPLETE.json');out=Path(pointer['out'])
   if pointer['source_sha256']!=artifact(P/'SOURCE.json')['sha256']:raise ValueError('stale completed control')
   observations=read(out);result=load(out/'RESULT.json')
   sys.exit(0 if len(observations)==4 and result.get('measurement') is False and result.get('run_id')==pointer['run_id'] else 1)
"""+s[b:];f.write_text(s)
f=p/'test_capture.py';s=f.read_text().replace("mode='official'","mode='capture-control'").replace("mode='official'","mode='capture-control'").replace("cap=dict(run_id=run['run_id'],mode='official'", "cap=dict(run_id=run['run_id'],mode='capture-control'")
# Model-free finalize writes completion pointer; avoid mutating real candidate completion during tests.
s=s.replace("reader.finalize(p,0);out=reader.read(p)", "run,raw,comparison=reader.evaluate(p);(p/'NATIVE.json').write_text(json.dumps(dict(comparison=comparison,belief_measurements=reader.mappings(run,raw,comparison,p))));(p/'TERMINAL.json').write_text(json.dumps(dict(run_id=run['run_id'],state='complete-capture-control',rc=0)));out=reader.read(p)");f.write_text(s)
# Preserve the original declaration as evidence/source, with no runnable pilot call in the launcher.
shutil.copy2('/mnt/raid0/llm/worktrees/mains/h-vidya-belief-substrate/scripts/experiments/exp01-pilot/job_r3.sh',p/'reference_job_r3.sh')
# Reusable linkage verifier dependency is pinned before capture, no live unbound import.
f=p/'prepare_pins.py';s=f.read_text().replace("rowflow=Path(","linkage_verifier=Path('/mnt/raid0/llm/epyc-inference-research/scripts/utils/verify_ggml_linkage.sh'),original_producer=P/'reference_job_r3.sh',rowflow=Path(");f.write_text(s)
f=p/'spec.json';d=json.loads(f.read_text());d.update(estimate_s=300,measurement=False,result_path=str(p/'control/*/RESULT.json'),result_format='json',regions='0-3',keep=['*.py','*.sh','*.json','*.env','*.md','SHA256SUMS','control/**']);d['smoke_predicate']='python3 '+str(p/'reader.py')+' complete '+str(p);d['decision_rule']='Source-capture/projection control ONLY, same bounded workload on exactly 4 CPUs/4 native threads: one original pp512/tg128 native speed unit per Q4KM/IQ4KT/IQ2XXS/IQ2KT arm plus the first fixed pinned paired item on Q4KM and IQ4KT. No separate smoke/official workload or duplicate scheduled run. Emit one declared measurement:false result only after full six native launches and strict source/runtime/resource/paired-item projection pass; failures/partials retain raw records and never satisfy completion. Provisional estimate 300s, absolute cap <=900s bounded by allocator deadline. No pilot ratio/look/port/futility decision, optimization evidence, historical warrant, or combination with r3.';f.write_text(json.dumps(d,indent=2)+'\n')
