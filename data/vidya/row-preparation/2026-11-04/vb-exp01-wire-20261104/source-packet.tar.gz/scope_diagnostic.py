from pathlib import Path
p=Path(__file__).parent;f=p/'reader.py';s=f.read_text()
s=s.replace("if run.get('pins')!=pins or run.get('mode')!='official':raise ValueError('mixed pin or smoke is not official evidence')", "if run.get('pins')!=pins or run.get('mode') not in ('official','smoke'):raise ValueError('mixed pins or unknown mode')")
a=s.index(" if run.get('planned')!=dict(");b=s.index('\n units=set()',a)
s=s[:a]+" arms=['Q4KM'] if run['mode']=='smoke' else ['Q4KM','IQ4KT','IQ2XXS','IQ2KT']\n expected_plan=dict(purpose='source-capture-diagnostic-only',speed_arms=arms,launches_per_arm=1,paired_items=0 if run['mode']=='smoke' else 1,item_selection='first original pinned item in file order',pp=512,tg=128,no_pilot_decision=True)\n if run.get('planned')!=expected_plan:raise ValueError('changed diagnostic plan')"+s[b:]
s=s.replace("capture.get('mode')!='official'", "capture.get('mode')!=run['mode']")
a=s.index("  elif r.get('kind')=='look':");b=s.index('\n  prefix.append(r)',a)
s=s[:a]+"  elif r.get('kind')!='validity':raise ValueError('unexpected pilot look or native kind')"+s[b:]
a=s.index(' expected_units=[];');b=s.index(' for r in quality:',a)
s=s[:a]+''' expected_units=[f'speed-{a}-1' for a in arms]
 if [r['unit'] for r in speed]!=expected_units:raise ValueError('extra/missing/reordered diagnostic launches')
 items=[json.loads(s) for s in Path(pins['artifacts']['items']['path']).read_text().splitlines()][:0 if run['mode']=='smoke' else 1]
 expected_quality=[f"q-{arm}-{item['id']}" for item in items for arm in ('Q4KM','IQ4KT')]
 if [r.get('unit') for r in rows]!=['validity']+expected_units+expected_quality:raise ValueError('extra/missing/reordered diagnostic units')
 if [r['unit'] for r in quality]!=expected_quality:raise ValueError('incomplete fixed paired item')
'''+s[b:]
a=s.index(" comparison=dict(");b=s.index('\n return run,raw,comparison',a)
s=s[:a]+''' comparison=dict(schema='epyc.exp01.capture_diagnostic.v1',run_id=run['run_id'],mode=run['mode'],speed_units=[dict(arm=r['arm'],unit=r['unit'],tg=r['tg'],pp=r['pp']) for r in speed],paired_item=[] if not items else [dict(item=items[0]['id'],control=quality[0]['correct'],intervention=quality[1]['correct'])],limitations='Minimal source-capture diagnostic only; single original unit per arm. No pilot ratio/look, speed advantage, port/futility, formal gate, or combination with r3.')'''+s[b:]
a=s.index('def mappings(');b=s.index('\ndef finalize(',a)
s=s[:a]+'''def mappings(run,raw,comparison,out):
 result=[]
 for c in comparison['speed_units']:
  model=run['pins']['models'][c['arm']]
  result.append(dict(measurement_id='exp01-capture:'+run['run_id']+':'+c['unit'],metric='tg128_native_tokens_per_s',value=c['tg'],date=datetime.fromtimestamp(run['started_at'],timezone.utc).date().isoformat(),category='CANDIDATE',claim=f"EXP01 source-capture diagnostic {c['arm']} original single native tg128 unit; no performance comparison",metric_direction='higher_better',protocol_id='',reps=1,reps_basis='scored:one independent original llama-bench launch',unit='tokens/s',attestation_locator=str(Path(out)/'results.jsonl'),attestation_sha256=hashlib.sha256(raw).hexdigest(),attestation_present=True,attestation_verified=True,source_kind='exp01-proxy-capture-diagnostic',applicability=dict(model_file=model['metadata']['path'],model_sha256=model['sha256_pinned'],backend='cpu',build_sha=run['pins']['trees']['/mnt/raid0/llm/ik_llama.cpp'],run_id=run['run_id'],threads=int(run['allocation']['FILLER_THREADS']),scope_basis='native'),observation=dict(outcome_native='capture-diagnostic-only',outcome_reason=comparison['limitations']),extra=dict(mode=run['mode'],native_unit=c,paired_item=comparison['paired_item'],limitations=comparison['limitations'])))
 return result
'''+s[b:]
a=s.index("  if run['mode']=='smoke':");b=s.index('  run,raw,comparison=evaluate(out)',a);s=s[:a]+s[b:]
s=s.replace("terminal['state']='complete-observation'", "terminal['state']='smoke-only' if run['mode']=='smoke' else 'complete-observation'")
s=s.replace("terminal.get('state')!='complete-observation'", "terminal.get('state')!=('smoke-only' if run['mode']=='smoke' else 'complete-observation')")
f.write_text(s)
f=p/'test_capture.py';s=f.read_text();s=s.replace("for i in range(24)","for i in range(24)")
a=s.index("planned=dict(launches=3,");b=s.index(");(p/'RUN.json')",a)
s=s[:a]+"planned=dict(purpose='source-capture-diagnostic-only',speed_arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT'],launches_per_arm=1,paired_items=1,item_selection='first original pinned item in file order',pp=512,tg=128,no_pilot_decision=True)"+s[b:]
a=s.index('  for i in range(1,4):');b=s.index('  import hashlib',a)
s=s[:a]+'''  for arm in ('Q4KM','IQ4KT','IQ2XXS','IQ2KT'):
   add(dict(unit=f'speed-{arm}-1',kind='speed',arm=arm,launch=1,rc=0,cpus='0-3',threads=4,tg=100.,pp=100.,build_commit='c04881fc0'))
'''+s[b:]
s=s.replace('  for item in items:', '  for item in items[:1]:').replace('self.assertEqual(len(out),2)','self.assertEqual(len(out),4)').replace("'raw','look'","'raw','quality'").replace("elif change=='look':next(x for x in rows if x['kind']=='look')['ratio']=4.", "elif change=='quality':rows[-1]['output']='tampered'")
f.write_text(s)
