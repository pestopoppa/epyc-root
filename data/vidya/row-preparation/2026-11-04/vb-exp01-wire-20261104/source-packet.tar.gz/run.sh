#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-exp01-wire-20261104
ATTEMPT=$(python3 -c 'import uuid;print(uuid.uuid4().hex)')
export OUT="$D/control/$ATTEMPT" MODELSET="$D/models.env" CAP_S=900
mkdir -p "$OUT"
finish() {
 local rc=$?
 python3 "$D/reader.py" finalize "$OUT" "$rc" || return 1
}
trap finish EXIT
python3 "$D/diagnostic.py"
