"""Model-free controls only. Synthetic records never leave temp directories."""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import reader
from capture import artifact

class ProspectiveControls(unittest.TestCase):
 def fixture(self,p):
  allocation=dict(FILLER_ID='synthetic',FILLER_CPUS='0-3',FILLER_THREADS='4',FILLER_DEADLINE='2000000000')
  items=[dict(id=str(i),prompt='synthetic',expect_regex='yes') for i in range(24)];ip=p/'items.jsonl';ip.write_text(''.join(json.dumps(x)+'\n' for x in items))
  pins=dict(models={a:dict(metadata=dict(path='/synthetic/'+a+'.gguf',size=10,mtime_ns=100000000000),sha256_pinned='a'*64) for a in ('Q4KM','IQ4KT','IQ2XXS','IQ2KT')},artifacts=dict(bench=dict(path='/synthetic/bench',sha256='b'*64),cli=dict(path='/synthetic/cli',sha256='c'*64),items=artifact(ip),**{'instrument-lib:ggml':dict(path='/synthetic/libggml.so',sha256='d'*64)}),trees={'/mnt/raid0/llm/ik_llama.cpp':'c04881fc0f31dae5f8ec59c1d683889f0c9dfa11'})
  run=dict(run_id='SYNTHETIC',mode='capture-control',started_at=100.,grant=dict(raw='synthetic-control-only'),pins=pins,source_sha256=artifact(reader.P/'SOURCE.json')['sha256'],allocation=allocation,planned=dict(purpose='source-capture-diagnostic-only',speed_arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT'],launches_per_arm=1,paired_items=1,item_selection='first original pinned item in file order',pp=512,tg=128,no_pilot_decision=True));(p/'RUN.json').write_text(json.dumps(run));(p/'launches').mkdir()
  rows=[]
  def add(r):
   r=copy.deepcopy(r);cap=dict(run_id=run['run_id'],mode='capture-control',allocation=allocation)
   if r.get('kind') in ('speed','quality'):
    u=r['unit'];mode='bench' if r['kind']=='speed' else 'cli';stdout=p/'launches'/(u+'.stdout')
    if r['kind']=='speed':
     raw=[dict(n_gen=0,n_prompt=512,n_threads=4,avg_ts=100.,build_commit='c04881fc0'),dict(n_gen=128,n_threads=4,avg_ts=r['tg'],build_commit='c04881fc0')];rp=p/(u+'.json');rp.write_text(json.dumps(raw));stdout.write_bytes(rp.read_bytes());cap['raw']=artifact(rp)
    else:stdout.write_text(r['output'])
    launch=dict(unit=u,rc=0,disposition='complete',started_at=101.,ended_at=102.,pid=1234,started_monotonic_s=float(len(rows)*2),ended_monotonic_s=float(len(rows)*2+1),samples=[dict(own_pid=1234,monotonic_s=len(rows)*2+t,affinity=[0,1,2,3],mapped=['/synthetic/libggml.so']) for t in (.1,.2)],mapped_artifacts={'ggml':pins['artifacts']['instrument-lib:ggml']},executable=pins['artifacts'][mode],argv=[pins['artifacts'][mode]['path'],'-m',pins['models'][r['arm']]['metadata']['path'],'-t','4'],stdout=artifact(stdout));launch['argv']=[pins['artifacts'][mode]['path'],'-m',pins['models'][r['arm']]['metadata']['path']]+(['-p','512','-n','128','-r','1','-t','4','-o','json'] if mode=='bench' else ['-p',r['item_native']['prompt'],'-n','256','--temp','0','--seed','42','-t','4','--no-display-prompt']);lp=p/'launches'/(u+'.json');lp.write_text(json.dumps(launch));cap['launch']=artifact(lp)
   r['belief_capture']=cap;rows.append(r);(p/'results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
  add(dict(unit='validity',ok=True,instrument=dict(fixture=False,commit=pins['trees']['/mnt/raid0/llm/ik_llama.cpp'],tracked_dirty=False,linkage_rc=0,kt_kernel_strings=1),arms={arm:dict(path=model['metadata']['path'],sha256_pinned=model['sha256_pinned'],size=10,mtime=100,arch_supported_by_instrument=True) for arm,model in pins['models'].items()}))
  for arm in ('Q4KM','IQ4KT','IQ2XXS','IQ2KT'):
   add(dict(unit=f'speed-{arm}-1',kind='speed',arm=arm,launch=1,rc=0,cpus='0-3',threads=4,tg=100.,pp=100.,build_commit='c04881fc0'))
  import hashlib
  for item in items[:1]:
   for a in ('Q4KM','IQ4KT'):add(dict(unit=f"q-{a}-{item['id']}",kind='quality',arm=a,item=item['id'],item_native=item,item_hash=hashlib.sha256((item['prompt']+item['expect_regex']).encode()).hexdigest()[:16],rc=0,cpus='0-3',threads=4,output='yes',correct=True))
  return pins,rows
 def test_exact_original_validity_row_has_no_kind(self):
  native=json.loads((reader.P/'native-validity-r1.json').read_text())
  self.assertEqual(native['unit'],'validity');self.assertNotIn('kind',native)
  self.assertEqual(reader.native_kind(native),'validity')
  for altered in (dict(native,kind='validity'),dict(native,kind='unexpected'),dict(native,unit='unknown'),dict(native,unit='look-Q4KM-IQ4KT',kind='look')):
   with self.assertRaises(ValueError):reader.native_kind(altered)
 def test_positive_native_shared_grade(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);pins,rows=self.fixture(p)
   with patch.object(reader,'checked',return_value=pins):
    run,raw,comparison=reader.evaluate(p);(p/'NATIVE.json').write_text(json.dumps(dict(comparison=comparison,belief_measurements=reader.mappings(run,raw,comparison,p))));(p/'TERMINAL.json').write_text(json.dumps(dict(run_id=run['run_id'],state='complete-capture-control',rc=0)));out=reader.read(p)
   self.assertEqual(len(out),4);self.assertTrue(all(x['grade'][:2]==('Judged','Located') for x in out))
 def test_refuse_partial_mixed_resources_smoke(self):
  for change in ('partial','resource','smoke','raw','quality'):
   with self.subTest(change=change),tempfile.TemporaryDirectory() as d:
    p=Path(d);pins,rows=self.fixture(p)
    if change=='partial':rows.pop()
    elif change=='resource':rows[1]['threads']=24
    elif change=='smoke':rows[1]['belief_capture']['mode']='smoke'
    elif change=='raw':(p/(rows[1]['unit']+'.json')).write_text('[]')
    elif change=='quality':rows[-1]['output']='tampered'
    (p/'results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
    with patch.object(reader,'checked',return_value=pins),self.assertRaises(ValueError):reader.evaluate(p)
 def test_finalize_emits_complete_control_once_without_pilot_marker(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);pins,rows=self.fixture(p)
   # Redirect only the completion pointer; every synthetic source stays in this temp directory.
   original_path=reader.P
   with patch.object(reader,'checked',return_value=pins),patch.object(reader,'P',p),patch.object(reader,'read',return_value=[{}]*4):
    with patch.object(reader,'evaluate',wraps=lambda out: (json.loads((p/'RUN.json').read_text()),(p/'results.jsonl').read_bytes(),dict(speed_units=[dict(arm=a,unit=f'speed-{a}-1',tg=100.,pp=100.) for a in ('Q4KM','IQ4KT','IQ2XXS','IQ2KT')],paired_item=[dict(item='0',control=True,intervention=True)],limitations='synthetic capture control only'))):reader.finalize(p,0)
   result=json.loads((p/'RESULT.json').read_text());self.assertIs(result['measurement'],False);self.assertEqual(result['native_speed_units'],4);self.assertFalse((p/'COMPLETE').exists())
 def test_refuse_no_prospective_envelope(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);pins,rows=self.fixture(p);del rows[0]['belief_capture'];(p/'results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
   with patch.object(reader,'checked',return_value=pins),self.assertRaises(ValueError):reader.evaluate(p)
if __name__=='__main__':unittest.main()
