"""Prospective original-run envelopes; no new warrant or grading rule."""
import hashlib,json,os,re,subprocess,time,uuid
from pathlib import Path
P=Path(__file__).parent

def artifact(path,hash_bytes=True):
 p=Path(path).resolve(strict=True);st=p.stat()
 result=dict(path=str(p),size=st.st_size,dev=st.st_dev,ino=st.st_ino,mtime_ns=st.st_mtime_ns,ctime_ns=st.st_ctime_ns)
 if hash_bytes:
  with p.open('rb') as f:result['sha256']=hashlib.file_digest(f,'sha256').hexdigest()
  after=p.stat()
  if (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)!=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns):raise ValueError('artifact changed during hashing')
 return result

def checked():
 pin=json.loads((P/'PINS.json').read_text())
 for name,item in pin['artifacts'].items():
  if artifact(item['path'])!=item:raise ValueError('artifact pin changed: '+name)
 for name,item in pin['models'].items():
  if artifact(item['metadata']['path'],False)!=item['metadata']:raise ValueError('prepared model identity changed: '+name)
 for tree,head in pin['trees'].items():
  if subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip()!=head or subprocess.check_output(['git','-C',tree,'status','--porcelain','--untracked-files=no'],text=True).strip():raise ValueError('source tree head/clean mismatch')
 if subprocess.run(['git','-C',str(P/'root-code'),'symbolic-ref','-q','HEAD'],capture_output=True).returncode!=1:raise ValueError('root-code must stay detached')
 for name,sha in json.loads((P/'SOURCE.json').read_text()).items():
  if artifact(P/name)['sha256']!=sha:raise ValueError('producer source differs: '+name)
 return pin

def begin(out):
 pin=checked();out=Path(out);out.mkdir(parents=True,exist_ok=True)
 marker=out/'RUN.json'
 if marker.exists():raise ValueError('prospective run directory already exists; fresh attempt required')
 grant_id=os.environ['FILLER_ID'];gp=Path(os.environ.get('FILLER_GRANTS_DIR','/mnt/raid0/llm/tmp/compute-flags/grants'))/(grant_id+'.grant')
 grant_raw=gp.read_text()
 if len(grant_raw)>65536:raise ValueError('unbounded grant')
 run=dict(schema='epyc.exp01.capture.v1',run_id=uuid.uuid4().hex,mode='capture-control',started_at=time.time(),pins=pin,source_sha256=artifact(P/'SOURCE.json')['sha256'],grant=dict(identity=artifact(gp),raw=grant_raw),allocation={k:os.environ[k] for k in ('FILLER_ID','FILLER_CPUS','FILLER_THREADS','FILLER_DEADLINE')},planned=dict(purpose='source-capture-diagnostic-only',speed_arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT'],launches_per_arm=1,paired_items=1,item_selection='first original pinned item in file order',pp=512,tg=128,no_pilot_decision=True))
 marker.write_text(json.dumps(run,sort_keys=True)+'\n');return run

def emit(result,row):
 result=Path(result);run=json.loads((result.parent/'RUN.json').read_text())
 row=dict(row);row['belief_capture']=dict(schema='epyc.exp01.unit_capture.v1',run_id=run['run_id'],mode=run['mode'],allocation=run['allocation'],written_at=time.time())
 if row.get('kind') in ('speed','quality') and row.get('rc') is not None:
  launch=result.parent/'launches'/(row['unit']+'.json')
  if not launch.is_file():raise ValueError('missing original launch capture')
  row['belief_capture']['launch']=artifact(launch)
 if row.get('kind')=='speed':
  row['belief_capture']['raw']=artifact(result.parent/(row['unit']+'.json'))
 with result.open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())

 return row
if __name__=='__main__':
 import sys
 if sys.argv[1]=='begin':begin(sys.argv[2])
 elif sys.argv[1]=='check':checked()
 elif sys.argv[1]=='emit':emit(sys.argv[2],json.loads(sys.argv[3]))
