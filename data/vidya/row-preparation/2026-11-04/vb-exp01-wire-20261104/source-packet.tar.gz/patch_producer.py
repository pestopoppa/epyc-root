from pathlib import Path
P=Path(__file__).parent
f=P/'job.sh';s=f.read_text().replace('/mnt/raid0/llm/tmp/brf-exp01/bin/',str(P)+'/').replace('MODELSET=${MODELSET:-/mnt/raid0/llm/tmp/brf-exp01/models.env}',f'MODELSET=${{MODELSET:-{P}/models.env}}');s=s.replace('BENCH="$IK/build/bin/llama-bench"; CLI="$IK/build/bin/llama-cli"',f'BENCH="{P}/bench.sh"; CLI="{P}/cli.sh"')
a=s.index('  python3 - "$R" "$1" <<\'PY_EMIT\'');b=s.index('\nPY_EMIT',a)+len('\nPY_EMIT');s=s[:a]+f'  python3 "{P}/capture.py" emit "$R" "$1"'+s[b:]
s=s.replace('taskset -c "$CPUS" "$BENCH"','EXP01_LAUNCH_UNIT="$u" taskset -c "$CPUS" "$BENCH"');s=s.replace('    done\n    [ "$i"', '      if [ "${FILLER_DRYRUN:-0}" = 1 ]; then break 3; fi\n    done\n    [ "$i"')
s=s.replace('if [ -n "${ITEMS:-}" ]', 'if [ "${FILLER_DRYRUN:-0}" != 1 ] && [ -n "${ITEMS:-}" ]')
s=s.replace('"$BENCH" "$IK/build"', '"$IK/build/bin/llama-bench" "$IK/build"')
f.write_text(s)
f=P/'quality.py';s=f.read_text().replace('R, items, cli, cpus, threads, end, stop', 'from capture import emit\n\nR, items, cli, cpus, threads, end, stop');s=s.replace('capture_output=True, text=True, timeout=900)', 'capture_output=True, text=True, timeout=900, env=dict(os.environ,EXP01_LAUNCH_UNIT=u))');s=s.replace('"output": out[-2000:]', '"output": out, "item_native":it, "cpus":cpus,"threads":int(threads)');a=s.index('        with open(R, "a")');s=s[:a]+'        emit(R,rec)\n';f.write_text(s)
for name,mode in [('bench','bench'),('cli','cli')]:
 (P/(name+'.sh')).write_text('#!/bin/bash\nset -euo pipefail\nexec python3 '+str(P)+'/launch_capture.py '+mode+' "$@"\n');(P/(name+'.sh')).chmod(0o755)
