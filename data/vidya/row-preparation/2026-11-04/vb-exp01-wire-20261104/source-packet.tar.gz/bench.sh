#!/bin/bash
set -euo pipefail
exec python3 /mnt/raid0/llm/tmp/vb-exp01-wire-20261104/launch_capture.py bench "$@"
