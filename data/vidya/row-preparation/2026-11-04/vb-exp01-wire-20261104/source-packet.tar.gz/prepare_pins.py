from pathlib import Path
import json,re,subprocess
from capture import artifact,P
D=Path('/mnt/raid0/llm/tmp/brf-exp01');IK=Path('/mnt/raid0/llm/ik_llama.cpp');root=P/'root-code'
env={}
for line in (P/'models.env').read_text().splitlines():
 m=re.match(r'([A-Z0-9_]+)=(.*)',line)
 if m:env[m[1]]=m[2].strip('"\'')
recorded={a:(sha,int(size)) for a,sha,size in (s.split() for s in (D/'models.sha256').read_text().splitlines())}
build=json.loads((D/'build/BUILD-DONE.json').read_text())
models={}
for a in ('Q4KM','IQ4KT','IQ2XXS','IQ2KT'):
 meta=artifact(env[a],False)
 if recorded[a]!=(env[a+'_SHA'],meta['size']) or build['arms'][a]['path']!=meta['path'] or build['arms'][a]['size']!=meta['size'] or build['arms'][a]['mtime']!=int(meta['mtime_ns']/1e9):raise ValueError('existing prepared model proof differs')
 models[a]=dict(metadata=meta,sha256_pinned=env[a+'_SHA'],basis='existing pre-grant models.sha256 + BUILD-DONE matching exact file metadata')
artifacts={k:artifact(v) for k,v in dict(bench=IK/'build/bin/llama-bench',cli=IK/'build/bin/llama-cli',items=env['ITEMS'],modelset=P/'models.env',prepared_hashes=D/'models.sha256',build_done=D/'build/BUILD-DONE.json',interpreter=Path('/usr/bin/python3'),linkage_verifier=Path('/mnt/raid0/llm/epyc-inference-research/scripts/utils/verify_ggml_linkage.sh'),original_producer=P/'reference_job_r3.sh',rowflow=Path('/mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh')).items()}
if artifacts['items']['sha256']!=env['ITEMS_SHA']:raise ValueError('pinned items differ')
for f in sorted((IK/'build').rglob('*.so*')):
 if f.is_file():artifacts['instrument-lib:'+str(f.relative_to(IK))]=artifact(f)
for f in sorted((root/'scripts/vidya').rglob('*.py')):artifacts['root-source:'+str(f.relative_to(root))]=artifact(f)
pins=dict(models=models,artifacts=artifacts,trees={str(x):subprocess.check_output(['git','-C',str(x),'rev-parse','HEAD'],text=True).strip() for x in (IK,root)})
(P/'PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
