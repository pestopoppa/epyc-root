#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-exp01-wire-20261104
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id vidya-exp01-proxy-wire-20261104 --class cpu --role bench --gpu-quiet none --claim-cpus "${WS58_REGIONS:-0-3}" --min-window 300 --stop "$D/STOP" --workdir "$D" --complete-cmd "python3 '$D/reader.py' complete '$D'" --precond-cmd "python3 '$D/capture.py' check" --cmd "/bin/bash '$D/run.sh'"
