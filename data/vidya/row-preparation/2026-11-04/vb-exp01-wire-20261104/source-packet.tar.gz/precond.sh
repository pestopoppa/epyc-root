#!/bin/bash
# --precond-cmd for EXP-01: rc!=0 + first line = reason when the arm identity is not runnable on the instrument.
# FAILS CLOSED until the build row (brf-exp01-trellis-build-20261102-r5) has produced all four arms: there is no allocator
# dependency field, so this is the dependency. Order: build manifest -> sizes -> pinned shas -> items pin -> instrument identity.
set -euo pipefail
D=/mnt/raid0/llm/tmp/brf-exp01
IK=/mnt/raid0/llm/ik_llama.cpp
MS=${MODELSET:-$D/models.env}
python3 -I - "$D/build/BUILD-DONE.json" "$MS" <<'PY'
import hashlib, json, os, re, sys
man, ms = sys.argv[1:]
if not os.path.exists(man):
    print("build row brf-exp01-trellis-build-20261102 not complete (no build/BUILD-DONE.json)"); sys.exit(1)
bd = json.load(open(man))
if bd.get("row") != "brf-exp01-trellis-build-20261102-r5":
    print("build/BUILD-DONE.json is not stamped by the r2 build row brf-exp01-trellis-build-20261102-r5 (row=%r)" % bd.get("row")); sys.exit(1)
b = bd["arms"]
env = {}
for line in open(ms):
    m = re.match(r"\s*(?:export\s+)?([A-Z0-9_]+)=(.*)", line)
    if m: env[m.group(1)] = m.group(2).strip().strip('"\'')
for arm in ("Q4KM", "IQ4KT", "IQ2XXS", "IQ2KT"):
    p = env.get(arm, "")
    if p != b[arm]["path"] or not os.path.exists(p):
        print(f"{arm}: {p!r} missing or not the built path"); sys.exit(1)
    st = os.stat(p)
    if st.st_size != b[arm]["size"] or int(st.st_mtime) != b[arm]["mtime"]:
        print(f"{arm}: size/mtime differs from BUILD-DONE manifest"); sys.exit(1)
    if not re.fullmatch(r"[0-9a-f]{64}", env.get(arm + "_SHA", "")):
        print(f"{arm}_SHA not pinned in models.env (pin from the built file before publishing the measurement row)"); sys.exit(1)
it = env.get("ITEMS", "")
if not os.path.exists(it) or hashlib.sha256(open(it, "rb").read()).hexdigest() != env.get("ITEMS_SHA"):
    print("ITEMS missing or its sha256 differs from ITEMS_SHA"); sys.exit(1)
PY
v=$(/mnt/raid0/llm/epyc-inference-research/.venv/bin/python3 -I $D/bin/identity.py "$MS" "$IK" 0 1)
python3 -I -c 'import json,sys; v=json.loads(sys.argv[1]); print("ok" if v["ok"] else "; ".join(v["why"])); sys.exit(0 if v["ok"] else 1)' "$v"
