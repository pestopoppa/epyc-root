#!/usr/bin/env python3
"""EXP-01 completion predicate: the measure row is complete only when SUMMARY.json shows every arm's planned
launches captured, or the planned look stopped the run (answer/futility on the main pair). A smoke's partial
SUMMARY (1 of 3 launches on one arm) is NOT completion. Exit 0 = complete."""
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(1)
cap = d.get("capture_completeness") or {}
full = bool(cap) and all(isinstance(v, list) and len(v) == 2 and v[1] and v[0] >= v[1] for v in cap.values())
stopped = any((lk or {}).get("stop") in ("answer", "futility") for lk in (d.get("looks") or {}).values())
sys.exit(0 if (d.get("validity_ok") and (full or stopped)) else 1)
