# EXP01 prospective source-capture control candidate

Owner-review/publication candidate only; no inference, grants, publication,
central ingestion, planning-context canary, or commits were performed here.

This control does not replay or extend the closed r3 pilot. The SAME workload
runs once on four allocated CPUs/four threads, independently of allocator mode:
one original pp512/tg128 native unit on each declared Q4KM/IQ4KT/IQ2XXS/IQ2KT arm,
then the FIRST original pinned item on Q4KM and IQ4KT. There are six native child
launches total. No pilot look, arm ratio, optimization evidence, port/futility
judgment, or r3 sample combination is produced. Original producer declaration
is preserved as reference_job_r3.sh. It is not the launched command.

launcher: launch.sh; row: spec.json; diagnostic driver: diagnostic.py.
The launcher honors WS58_REGIONS; every runtime launch must prove exactly four
allocated CPUs and four native threads. Estimate 300s is provisional, based on
the previous bounded instrument pilot duration. Hard cap is 900s, shortened by
the allocator deadline. Every child is sampled while alive; the wrapper owns and
terminates only its own Popen PID. Native stdout/stderr and failed/partial states
remain available. A cap or missing native record refuses completion.

The declared measurement:false RESULT.json answers capture/projection only.
It is emitted ONCE after all six native launches, original validity checks,
source/model/item/resource/runtime joins, paired item outputs and strict shared
ClaimTuple/grade projection complete. The four speed observations stay explicitly
single-unit source controls, with no ratified protocol or optimization judgment.
No first-speed smoke result is emitted. The sole declared output is the full control/<uuid>/RESULT.json; no allocator
result copy or per-attempt native-result branch exists.
LATEST_COMPLETE.json plus the strict complete predicate lets the owner complete
from that same actual control; no second scheduled replay is needed.

Run IDs are fresh control/<uuid> directories. Results never resume or read r3.
PINS.json reuses existing pre-grant models.sha256 + BUILD-DONE and exact current
metadata; no model weights are hashed under grant. All current executable/DSO,
item-set, original producer, launcher/reader source, linkage verifier and prepared
pin-record bytes are bound. root-code is a sparse detached checkout pinned at
1ea56a495413be89ea9bcc89407f547a47f3e9f2. Every scripts/vidya Python source hash is
pinned; preflight/native begin/final reader verify clean HEAD and source bytes.
No volatile lane import exists. Instrument ik tree is read-only reference at
c04881fc0f31dae5f8ec59c1d683889f0c9dfa11, with runtime native build_commit check.
Mapped ggml/llama hashes and four-CPU affinity require two in-window own-PID
samples. Unresolved, failed or mismatched joins remain UNKNOWN/refused.

Model-free controls use synthetic records only in TemporaryDirectory: positive
native projection/shared grade; five refusal variants (partial, resources,
foreign mode, raw source, original quality output); absent-envelope refusal.
These synthetic records are never publisher/keeper output. No real canary has
passed, so this source is not declared wired. Central CLI adapter registration
and planning consumer integration remain owner work after real control evidence.

SOURCE.json pins all candidate source/config inputs; SHA256SUMS pins the final
packet. Changes require refreshing them. The row grants no authority to restart
the closed pilot, add launches, change the original producer estimator, or port.
