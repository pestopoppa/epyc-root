"""Strict prospective EXP01 projection; shared measurement ladder only."""
import dataclasses,hashlib,json,math,os,re,statistics,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
from capture import P,artifact,checked
ROOT=P/'root-code/scripts/vidya';sys.path.insert(0,str(ROOT))
from claim_tuple import ClaimTuple,grade
import claim_tuple
if Path(claim_tuple.__file__).resolve()!=ROOT/'claim_tuple.py':raise ValueError('claim_tuple outside pinned source')
PAIRS=[('Q4KM','IQ4KT'),('IQ2XXS','IQ2KT')]

def load(path,bound=64<<20):
 path=Path(path)
 if not path.is_file() or path.is_symlink() or path.stat().st_size>bound:raise ValueError('unbounded/nonregular source')
 return json.loads(path.read_bytes())
def cpuset(text):
 result=set()
 for x in text.split(','):
  a,_,b=x.partition('-');result.update(range(int(a),int(b or a)+1))
 return result

def native_kind(row):
 """Original identity.py emits unit=validity and NO kind field; no other omission is valid."""
 if row.get('unit')=='validity':
  if 'kind' in row:raise ValueError('native validity must omit kind')
  return 'validity'
 kind=row.get('kind')
 if kind not in ('speed','quality'):raise ValueError('unexpected pilot look or native kind')
 return kind

def evaluate(out):
 out=Path(out);run=load(out/'RUN.json');pins=checked()
 if run.get('pins')!=pins or run.get('mode')!='capture-control':raise ValueError('mixed pins or unknown mode')
 if run.get('source_sha256')!=artifact(P/'SOURCE.json')['sha256']:raise ValueError('producer closure mismatch')
 raw=(out/'results.jsonl').read_bytes()
 if len(raw)>64<<20:raise ValueError('unit stream exceeds bound')
 rows=[json.loads(s) for s in raw.splitlines() if s.strip()]
 if not rows or rows[0].get('unit')!='validity' or rows[0].get('ok') is not True or rows[0].get('instrument',{}).get('fixture'):raise ValueError('missing native validity')
 arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT']
 expected_plan=dict(purpose='source-capture-diagnostic-only',speed_arms=arms,launches_per_arm=1,paired_items=1,item_selection='first original pinned item in file order',pp=512,tg=128,no_pilot_decision=True)
 if run.get('planned')!=expected_plan:raise ValueError('changed diagnostic plan')
 validity=rows[0];instrument=validity.get('instrument',{})
 if instrument.get('commit')!=pins['trees']['/mnt/raid0/llm/ik_llama.cpp'] or instrument.get('tracked_dirty') is not False or instrument.get('linkage_rc')!=0 or instrument.get('kt_kernel_strings',0)<=0:raise ValueError('native instrument validity differs')
 for arm,model in pins['models'].items():
  native_arm=validity.get('arms',{}).get(arm,{})
  if native_arm.get('path')!=model['metadata']['path'] or native_arm.get('sha256_pinned')!=model['sha256_pinned'] or native_arm.get('size')!=model['metadata']['size'] or native_arm.get('mtime')!=int(model['metadata']['mtime_ns']/1e9) or native_arm.get('arch_supported_by_instrument') is not True:raise ValueError('native arm validity differs')
 if not run.get('grant',{}).get('raw'):raise ValueError('original grant capture missing')

 if len(mask:=cpuset(run['allocation']['FILLER_CPUS']))!=4 or run['allocation']['FILLER_THREADS']!='4':raise ValueError('diagnostic requires four CPUs/four threads')
 units=set();speed=[];quality=[];looks=[];prefix=[];previous_end=None;allocation=run['allocation'];mask=cpuset(allocation['FILLER_CPUS']);threads=int(allocation['FILLER_THREADS'])
 for r in rows:
  kind=native_kind(r)
  capture=r.get('belief_capture',{})
  if capture.get('run_id')!=run['run_id'] or capture.get('mode')!=run['mode'] or capture.get('allocation')!=allocation:raise ValueError('mixed run/allocation')
  if r.get('kind')!='look':
   if r.get('unit') in units:raise ValueError('duplicate unit')
   units.add(r.get('unit'))
  if r.get('kind') in ('speed','quality'):
   if r.get('rc')!=0 or r.get('cpus')!=allocation['FILLER_CPUS'] or r.get('threads')!=threads:raise ValueError('failed or mismatched resource unit')
   ref=capture['launch'];path=out/'launches'/(r['unit']+'.json')
   if artifact(path)!=ref:raise ValueError('launch source differs')
   launch=load(path)
   if launch.get('unit')!=r['unit'] or launch.get('rc')!=0 or launch.get('disposition')!='complete':raise ValueError('failed launch')
   if not run['started_at']<=launch['started_at']<=launch['ended_at']<=min(float(allocation['FILLER_DEADLINE']),run['started_at']+900):raise ValueError('outside original grant/control window')
   if type(launch.get('pid')) is not int or launch['pid']<=0:raise ValueError('missing own child PID')
   if previous_end is not None and launch['started_monotonic_s']<previous_end:raise ValueError('overlap/reset launch window')
   previous_end=launch['ended_monotonic_s']
   samples=launch.get('samples',[]);mapped=launch.get('mapped_artifacts',{})
   if len(samples)<2:raise ValueError('missing in-window runtime samples')
   for sample in samples:
    if sample.get('own_pid')!=launch['pid'] or set(sample['affinity'])!=mask or not launch['started_monotonic_s']<=sample['monotonic_s']<=launch['ended_monotonic_s']:raise ValueError('runtime allocation/window mismatch')
   expected_libs=[v for k,v in pins['artifacts'].items() if k.startswith('instrument-lib:')]
   required=[v for v in expected_libs if Path(v['path']).name in ('libggml.so','libllama.so')]
   # Canonical paths may include sonames; match the exact prepared library identities by digest.
   if not required:required=expected_libs
   if sum(all(v['path'] in sample.get('mapped',[]) for v in required) for sample in samples)<2:raise ValueError('missing persistent in-window instrument mappings')
   if not required or any(not any(x['sha256']==v['sha256'] and x['path']==v['path'] for x in mapped.values()) for v in required):raise ValueError('instrument mapped identity missing')
   stdout_path=out/'launches'/(r['unit']+'.stdout')
   if artifact(stdout_path)!=launch.get('stdout'):raise ValueError('launch stdout source differs')
   mode='bench' if r['kind']=='speed' else 'cli'
   if launch['executable']!=pins['artifacts'][mode]:raise ValueError('wrong executable')
   argv=launch['argv'];model=pins['models'][r['arm']]['metadata']['path']
   if argv[argv.index('-m')+1]!=model or argv[argv.index('-t')+1]!=str(threads):raise ValueError('invocation model/thread mismatch')
   if r['kind']=='speed':
    if argv!=[pins['artifacts']['bench']['path'],'-m',model,'-p','512','-n','128','-r','1','-t',str(threads),'-o','json']:raise ValueError('speed invocation differs from plan')
    native_path=out/(r['unit']+'.json')
    if artifact(native_path)!=capture['raw']:raise ValueError('raw speed source differs')
    if native_path.read_bytes()!=stdout_path.read_bytes():raise ValueError('native stdout join differs')
    native=load(native_path);tg=[x for x in native if x.get('n_gen',0)>0];pp=[x for x in native if x.get('n_gen',0)==0 and x.get('n_prompt',0)>0]
    if len(tg)!=1 or len(pp)!=1 or tg[0]['n_gen']!=128 or pp[0]['n_prompt']!=512:raise ValueError('changed benchmark cell')
    if any(x.get('n_threads')!=threads for x in native) or (r.get('tg'),r.get('pp'),r.get('build_commit'))!=(tg[0]['avg_ts'],pp[0]['avg_ts'],tg[0].get('build_commit')):raise ValueError('speed does not rederive')
    if not pins['trees']['/mnt/raid0/llm/ik_llama.cpp'].startswith(str(r.get('build_commit'))):raise ValueError('native build commit differs')
    if not math.isfinite(r['tg']) or r['tg']<=0:raise ValueError('invalid native speed')
    speed.append(r)
   else:
    if argv!=[pins['artifacts']['cli']['path'],'-m',model,'-p',r['item_native']['prompt'],'-n','256','--temp','0','--seed','42','-t',str(threads),'--no-display-prompt']:raise ValueError('quality invocation differs from original item plan')
    if r['output']!=stdout_path.read_text():raise ValueError('quality output differs from original launch')
    quality.append(r)
  elif kind!='validity':raise ValueError('unexpected pilot look or native kind')
  prefix.append(r)
 expected_units=[f'speed-{a}-1' for a in arms]
 if [r['unit'] for r in speed]!=expected_units:raise ValueError('extra/missing/reordered diagnostic launches')
 items=[json.loads(s) for s in Path(pins['artifacts']['items']['path']).read_text().splitlines()][:1]
 expected_quality=[f"q-{arm}-{item['id']}" for item in items for arm in ('Q4KM','IQ4KT')]
 if [r.get('unit') for r in rows]!=['validity']+expected_units+expected_quality:raise ValueError('extra/missing/reordered diagnostic units')
 if [r['unit'] for r in quality]!=expected_quality:raise ValueError('incomplete fixed paired item')
 for r in quality:
  item=next(x for x in items if x['id']==r['item'])
  if r.get('item_native')!=item or r['item_hash']!=hashlib.sha256((item['prompt']+item['expect_regex']).encode()).hexdigest()[:16] or r['correct']!=bool(re.search(item['expect_regex'],r['output'])):raise ValueError('paired item/output mismatch')
 comparison=dict(schema='epyc.exp01.capture_diagnostic.v1',run_id=run['run_id'],mode=run['mode'],speed_units=[dict(arm=r['arm'],unit=r['unit'],tg=r['tg'],pp=r['pp']) for r in speed],paired_item=[] if not items else [dict(item=items[0]['id'],control=quality[0]['correct'],intervention=quality[1]['correct'])],limitations='Minimal source-capture diagnostic only; single original unit per arm. No pilot ratio/look, speed advantage, port/futility, formal gate, or combination with r3.')
 return run,raw,comparison

def mappings(run,raw,comparison,out):
 result=[]
 for c in comparison['speed_units']:
  model=run['pins']['models'][c['arm']]
  result.append(dict(measurement_id='exp01-capture:'+run['run_id']+':'+c['unit'],metric='tg128_native_tokens_per_s',value=c['tg'],date=datetime.fromtimestamp(run['started_at'],timezone.utc).date().isoformat(),category='CANDIDATE',claim=f"EXP01 source-capture diagnostic {c['arm']} original single native tg128 unit; no performance comparison",metric_direction='higher_better',protocol_id='',reps=1,reps_basis='scored:one independent original llama-bench launch',unit='tokens/s',attestation_locator=str(Path(out)/'results.jsonl'),attestation_sha256=hashlib.sha256(raw).hexdigest(),attestation_present=True,attestation_verified=True,source_kind='exp01-proxy-capture-diagnostic',applicability=dict(model_file=model['metadata']['path'],model_sha256=model['sha256_pinned'],backend='cpu',build_sha=run['pins']['trees']['/mnt/raid0/llm/ik_llama.cpp'],run_id=run['run_id'],threads=int(run['allocation']['FILLER_THREADS']),scope_basis='native'),observation=dict(outcome_native='capture-diagnostic-only',outcome_reason=comparison['limitations']),extra=dict(mode=run['mode'],native_unit=c,paired_item=comparison['paired_item'],limitations=comparison['limitations'])))
 return result

def finalize(out,rc):
 out=Path(out);run=load(out/'RUN.json');terminal=dict(run_id=run['run_id'],mode=run['mode'],rc=int(rc),ended_at=time.time(),state='partial-or-failed')
 try:
  if int(rc)!=0:raise ValueError('producer failed')
  run,raw,comparison=evaluate(out);packet=dict(comparison=comparison,belief_measurements=mappings(run,raw,comparison,out))
  (out/'NATIVE.json').write_text(json.dumps(packet,sort_keys=True)+'\n');terminal['state']='complete-capture-control'
 except Exception as exc:
  terminal['reason']=f'{type(exc).__name__}: {exc}';raise
 finally:(out/'TERMINAL.json').write_text(json.dumps(terminal,sort_keys=True)+'\n')
 verified=read(out)
 result=dict(schema='epyc.exp01.capture_control_result.v1',run_id=run['run_id'],purpose='source-capture-projection-control-only',measurement=False,state='complete',native_speed_units=4,fixed_paired_items=1,projected_observations=len(verified),source_sha256=run['source_sha256'],result_path=str(out/'NATIVE.json'),limitations=comparison['limitations'])
 data=json.dumps(result,sort_keys=True)+'\n';(out/'RESULT.json').write_text(data)
 (P/'LATEST_COMPLETE.json').write_text(json.dumps(dict(out=str(out),run_id=run['run_id'],source_sha256=run['source_sha256']))+'\n')
def read(out):
 run,raw,comparison=evaluate(out);packet=load(Path(out)/'NATIVE.json')
 terminal=load(Path(out)/'TERMINAL.json')
 if terminal.get('run_id')!=run['run_id'] or terminal.get('state')!='complete-capture-control' or terminal.get('rc')!=0:raise ValueError('no matching successful native terminal')
 if packet!=dict(comparison=comparison,belief_measurements=mappings(run,raw,comparison,out)):raise ValueError('native mappings/comparison changed')
 return [dict(measurement=dataclasses.asdict(t),grade=grade(t)) for t in [ClaimTuple(**x) for x in packet['belief_measurements']]]
if __name__=='__main__':
 try:
  if sys.argv[1]=='finalize':finalize(sys.argv[2],sys.argv[3])
  elif sys.argv[1]=='complete':
   pointer=load(Path(sys.argv[2])/'LATEST_COMPLETE.json');out=Path(pointer['out'])
   if pointer['source_sha256']!=artifact(P/'SOURCE.json')['sha256']:raise ValueError('stale completed control')
   observations=read(out);result=load(out/'RESULT.json')
   sys.exit(0 if len(observations)==4 and result.get('measurement') is False and result.get('run_id')==pointer['run_id'] else 1)
  else:print(json.dumps(read(sys.argv[1])))
 except Exception as exc:print(json.dumps(dict(state='UNKNOWN',refused=str(exc))));sys.exit(1)
