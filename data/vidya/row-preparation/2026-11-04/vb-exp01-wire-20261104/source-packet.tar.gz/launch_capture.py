#!/usr/bin/env python3
"""Own child PID capture while the actual CPU instrument runs."""
import json,os,subprocess,sys,time
from pathlib import Path
from capture import artifact
P=Path(__file__).parent
mode=sys.argv[1];args=sys.argv[2:];out=Path(os.environ['OUT']);unit=os.environ['EXP01_LAUNCH_UNIT']
pins=json.loads((P/'PINS.json').read_text());exe=pins['artifacts'][mode]['path']
expected=set()
for bit in os.environ['FILLER_CPUS'].split(','):
 a,_,b=bit.partition('-');expected.update(range(int(a),int(b or a)+1))
if set(os.sched_getaffinity(0))!=expected:raise SystemExit('proxy affinity differs from allocation')
argv=[exe]+args;record=dict(schema='epyc.exp01.launch.v1',unit=unit,argv=argv,executable=artifact(exe),started_at=time.time(),started_monotonic_s=time.monotonic(),samples=[],disposition='started')
dest=out/'launches';dest.mkdir(exist_ok=True)
stdout_path=dest/(unit+'.stdout');stderr_path=dest/(unit+'.stderr')
stdout_file=stdout_path.open('wb');stderr_file=stderr_path.open('wb')
proc=None
try:
 proc=subprocess.Popen(argv,stdout=stdout_file,stderr=stderr_file);record['pid']=proc.pid
 seen={}
 deadline=min(float(os.environ['FILLER_DEADLINE']),float(os.environ['EXP01_CONTROL_END']))
 while proc.poll() is None:
  if stdout_path.stat().st_size>32<<20 or stderr_path.stat().st_size>32<<20:
   proc.terminate()
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
   record['failure']='native output bound exceeded';break
  if time.time()>=deadline:
   proc.terminate()
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
   record['failure']='launch deadline reached';break
  try:
   mask=sorted(os.sched_getaffinity(proc.pid));paths=set()
   for line in Path('/proc',str(proc.pid),'maps').read_text().splitlines():
    bits=line.split(maxsplit=5)
    if len(bits)==6 and bits[5].startswith('/') and '.so' in bits[5]:paths.add(bits[5])
   record['samples'].append(dict(own_pid=proc.pid,monotonic_s=time.monotonic(),affinity=mask,mapped=sorted(paths)))
   for path in paths:
    if path not in seen:seen[path]=artifact(path)
  except (FileNotFoundError,ProcessLookupError):pass
  time.sleep(.1)
 stdout_file.close();stderr_file.close()
 record['stdout']=artifact(stdout_path);record['stderr']=artifact(stderr_path)
 sys.stdout.buffer.write(stdout_path.read_bytes());sys.stdout.buffer.flush()
 sys.stderr.buffer.write(stderr_path.read_bytes());sys.stderr.buffer.flush()
 record.update(rc=proc.returncode,mapped_artifacts=seen,disposition='complete' if proc.returncode==0 else 'failed')
except BaseException as exc:
 record.update(disposition='failed',failure=f'{type(exc).__name__}: {exc}')
 if proc is not None and proc.poll() is None:
  proc.terminate()
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
 raise
finally:
 stdout_file.close();stderr_file.close()
 record.update(ended_at=time.time(),ended_monotonic_s=time.monotonic())
 dest=out/'launches';dest.mkdir(exist_ok=True);(dest/(unit+'.json')).write_text(json.dumps(record,sort_keys=True)+'\n')
sys.exit(proc.returncode)
