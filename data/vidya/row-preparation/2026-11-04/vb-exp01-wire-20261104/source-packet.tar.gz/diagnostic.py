#!/usr/bin/env python3
"""Separate minimal source-capture diagnostic. Never replay a closed pilot decision."""
import json,os,re,subprocess,sys,time
from pathlib import Path
from capture import P,begin,emit
out=Path(os.environ['OUT']);
if len(os.sched_getaffinity(0))!=4 or os.environ['FILLER_THREADS']!='4':
 (out/'REFUSAL.json').write_text(json.dumps(dict(state='refused',reason='diagnostic requires exactly four allocated CPUs and four native threads',actual_allowed_cpus=sorted(os.sched_getaffinity(0)),native_threads=os.environ.get('FILLER_THREADS')))+'\n')
 raise SystemExit('diagnostic requires exactly four allocated CPUs and four native threads')
run=begin(out);os.environ['EXP01_CONTROL_END']=str(min(float(os.environ['FILLER_DEADLINE']),run['started_at']+900));results=out/'results.jsonl';results.touch();pins=run['pins'];cpus=os.environ['FILLER_CPUS'];threads=os.environ['FILLER_THREADS'];ik='/mnt/raid0/llm/ik_llama.cpp'
os.environ['LD_LIBRARY_PATH']=ik+'/build/ggml/src:'+ik+'/build/src'
# Retain the original producer's monolithic-ggml validity interpretation.
verify=pins['artifacts']['linkage_verifier']['path'];link=subprocess.run(['bash',verify,pins['artifacts']['bench']['path'],ik+'/build'],capture_output=True,text=True);text=link.stdout+link.stderr
(out/'linkage.log').write_text(text)
link_rc=link.returncode
if link_rc and '  BAD ' not in text and '  OK   libggml.so ' in text and '  OK   libllama.so ' in text and re.search(r'libggml-base.so seen\s*: 0',text):link_rc=0
symbols=subprocess.check_output(['strings',ik+'/build/ggml/src/libggml.so'],text=True);n=sum('iq4_kt' in s.lower() for s in symbols.splitlines())
valid=json.loads(subprocess.check_output(['/mnt/raid0/llm/epyc-inference-research/.venv/bin/python3','-I',str(P/'identity.py'),str(P/'models.env'),ik,str(link_rc),str(n)],text=True));emit(results,valid)
if not valid['ok']:raise SystemExit(3)
mode=run['mode'];arms=['Q4KM','IQ4KT','IQ2XXS','IQ2KT']
for arm in arms:
 if time.time()>=float(os.environ['EXP01_CONTROL_END']) or Path(os.environ['FILLER_STOPFILE']).exists():raise SystemExit(75)
 unit=f'speed-{arm}-1';model=pins['models'][arm]['metadata']['path'];started=time.time()
 args=['taskset','-c',cpus,str(P/'bench.sh'),'-m',model,'-p','512','-n','128','-r','1','-t',threads,'-o','json']
 proc=subprocess.run(args,capture_output=True,env=dict(os.environ,EXP01_LAUNCH_UNIT=unit));(out/(unit+'.json')).write_bytes(proc.stdout);(out/(unit+'.err')).write_bytes(proc.stderr)
 row=dict(unit=unit,kind='speed',arm=arm,launch=1,rc=proc.returncode,duration_s=round(time.time()-started,2),gguf=model,cpus=cpus,threads=int(threads))
 try:
  for r in json.loads(proc.stdout):
   if r.get('n_gen',0)>0:row.update(tg=r['avg_ts'],tg_n=r['n_gen'])
   elif r.get('n_prompt',0)>0:row.update(pp=r['avg_ts'],pp_n=r['n_prompt'])
   row.update(build_commit=r.get('build_commit'),type_k=r.get('model_type'))
   if r.get('n_threads')!=int(threads):raise ValueError('native n_threads does not match allocation')
 except Exception as exc:
  row.update(parse_error=str(exc),rc=4)
  for key in ('tg','pp','tg_n','pp_n'):row.pop(key,None)
 emit(results,row)
 if row['rc']:raise SystemExit(row['rc'])
if True:
 item=json.loads(Path(pins['artifacts']['items']['path']).read_text().splitlines()[0]);fixed=out/'fixed-item.jsonl';fixed.write_text(json.dumps(item)+'\n')
 subprocess.run([sys.executable,str(P/'quality.py'),str(results),str(fixed),str(P/'cli.sh'),cpus,threads,str(int(float(os.environ['EXP01_CONTROL_END']))),os.environ['FILLER_STOPFILE'],'Q4KM='+pins['models']['Q4KM']['metadata']['path'],'IQ4KT='+pins['models']['IQ4KT']['metadata']['path']],check=True)
