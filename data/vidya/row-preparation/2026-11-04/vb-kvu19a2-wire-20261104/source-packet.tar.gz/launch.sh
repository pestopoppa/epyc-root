#!/bin/bash
set -euo pipefail
packet=/mnt/raid0/llm/tmp/vb-kvu19a2-wire-20261104
python3 "$packet/preflight.py"
: "${KVU19A2_GRANT_RECEIPT:?owning scheduler must provide actual grant receipt}"
: "${KVU19A2_GRANT_SHA256:?owning scheduler must pin actual receipt}"
: "${KVU19A2_ROW_ID:?owning scheduler must bind actual row}"
if [ "${FILLER_DRYRUN:-0}" = 1 ]; then
  : "${FILLER_DRYRUN_DIR:?allocator isolated smoke dir required}"
  : "${FILLER_DRYRUN_RESULT_PATH:?allocator smoke result path required}"
else
  : "${KVU19A2_REPEAT_OUT:?fresh absolute output path required}"
fi
export EPYC_VIDYA_ROOT=/mnt/raid0/llm/tmp/vb-kvu19a2-wire-20261104/root-code/scripts/vidya
export KVU19A2_EXE=/dev/shm/kvu19a2-immutable-build-v2-20261102/harness/fa_harness
export KVU19A2_SOURCE_ARCHIVE=/dev/shm/kvu19a2-root-source-20261102/source.tar
export KVU19A2_BUILD_RECEIPT_SHA256=3b327e7b729e02e38ed377847f4ea890d42852aa4e2300f681be07e86742511f
export KVU19A2_EXE_SHA256=a41b12fd64a28af97e13d50bcd28a1bb31a9c7a95c5182d7a08c0fa54fef5ed7
export KVU19A2_HARNESS_RECEIPT_SHA256=15e966e5488629fe0f1c9baf309056dda08ea60b262171e8f5df078647a9f3d3
exec python3 "$packet/kvu19a2_repeat_rootbuild.py"
