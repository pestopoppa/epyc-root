from pathlib import Path
import hashlib,json,shutil
p=Path('/mnt/raid0/llm/tmp/vb-kvu19a2-wire-20261104')
src=Path('/mnt/raid0/llm/worktrees/vb-sl2-steps-r1-code')
for f in ('kvu19a2_custody.py','kvu19a2_repeat_rootbuild.py'):
 shutil.copyfile(src/'scripts/benchmark'/f,p/f)
a=src/'artifacts/kvu19a2-repeat-20261102'
for f in ('canonical-input-hashes.json','PREDECLARATION-ROOTBUILD.md'):
 shutil.copyfile(a/f,p/f)
f=p/'kvu19a2_repeat_rootbuild.py'; s=f.read_text()
s=s.replace('artifact = Path(__file__).resolve().parents[2] / "artifacts/kvu19a2-repeat-20261102"','artifact = Path(__file__).resolve().parent')
s=s.replace('OUT.mkdir(exist_ok=False)', '''grant_path = Path(os.environ["KVU19A2_GRANT_RECEIPT"]).resolve()
    grant_sha = os.environ["KVU19A2_GRANT_SHA256"]
    if sha_file(grant_path) != grant_sha:
        raise ValueError("actual scheduler grant receipt changed")
    # Admission belongs to scheduler; retain its original receipt without reinterpreting it.
    grant = {"path": str(grant_path), "sha256": grant_sha,
             "row_id": os.environ["KVU19A2_ROW_ID"]}
    OUT.mkdir(exist_ok=False)
    (OUT / "grant-receipt.original").write_bytes(grant_path.read_bytes())''')
s=s.replace('"started_at": start, "ended_at": end}', '"started_at": start, "ended_at": end, "grant": grant,\n                       "pid": child.pid, "birth_ticks": birth, "rc": rc, "cleanup_verified": child.poll() is not None}')
s=s.replace('raise TimeoutError("native child timed out")','pass  # Preserve timed-out launch as a missing native observation; never redraw.')
s=s.replace('captured = target.is_file() and rc == 0','captured = (target.is_file() and rc == 0 and input_hashes == canonical[str(case)]\n                            and bool(mapping) and any(s["kfd"] and s["vram_bytes"] is not None\n                            and s["vram_bytes"] > 0 for s in samples))')
s=s.replace('missing_reason="no completed native output"','missing_reason="missing output, failed process, input mismatch, mapping or residency unknown"')
s=s.replace('birth = process_birth(Path("/proc") / str(child.pid))\n                    try:', 'birth = None\n                    try:\n                        birth = process_birth(Path("/proc") / str(child.pid))')
s=s.replace('"runtime_library_pins": preflight_libs,', '"grant": grant, "runtime_library_pins": preflight_libs,')
f.write_text(s)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
r=Path('/dev/shm/kvu19a2-immutable-build-v2-20261102')
paths=[r/'build-receipt.json',r/'harness/harness-receipt.json',r/'harness/fa_harness',Path('/dev/shm/kvu19a2-root-source-20261102/source.tar'),p/'kvu19a2_repeat_rootbuild.py',p/'kvu19a2_custody.py',p/'canonical-input-hashes.json',p/'PREDECLARATION-ROOTBUILD.md']
for arm in ('base','candidate'):
 paths.extend(x.resolve() for x in (r/arm/'bin').glob('libggml*.so.0.16.0'))
spec={'schema':'kvu19a2.prospective-ready.v1','row_id':'handoff-vidya-kvu19a2-wire-20261104','status':'prepared-unpublished-ungranted','task':'VB-KVU19A2-WIRE','backend':'gpu','device':'gfx90a','model_free':True,'production_kernel_access':False,'question':'Do five fresh exact-input launches per arm/case produce identical output bytes? Native NaN counts are lower_better; no speed conclusion.','cases':[78,80],'repetitions_per_arm_case':5,'arms':['base','candidate'],'max_processes':20,'timeout_s_per_process':90,'wall_budget_s':2100,'checkpoints':'retain each raw output/log; no redraw; inspect only after all predeclared launches','stop_rules':'stop on custody or grant failure; incomplete residency/input/process gives UNKNOWN; bounded 20 launches','target':{'model_file':'Qwen3.8-27B-Q8_0.gguf','quant':'Q8_0','backend':'gpu','device':'gfx90a'},'pins':{str(x):sha(x) for x in paths},'source_build_binding':'root-owned read-only to build UID; root mutable and transitive toolchain not fully pinned','launcher':str(p/'launch.sh'),'acceptance':'fresh native sidecar ingest refused=[] then private prepare lists kvu19a2-native host claim; canonical consumer canary remains owning-session step','grant_requirement':'owning scheduler must admit row with exclusive gfx90a grant and supply original grant receipt path/hash and row ID; this packet neither grants nor publishes'}
(p/'spec.ready.json').write_text(json.dumps(spec,indent=2)+'\n')
