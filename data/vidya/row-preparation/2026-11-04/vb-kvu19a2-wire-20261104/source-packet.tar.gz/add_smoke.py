from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
f=p/'kvu19a2_repeat_rootbuild.py';s=f.read_text()
s=s.replace('OUT = Path(os.environ["KVU19A2_REPEAT_OUT"]).resolve()', '''SMOKE = os.environ.get("FILLER_DRYRUN", "0") == "1"
OUT = (Path(os.environ["FILLER_DRYRUN_DIR"]) / "kvu19a2-native-smoke" if SMOKE
       else Path(os.environ["KVU19A2_REPEAT_OUT"])).resolve()''')
# Only run loop, not comparator loops.
s=s.replace('for case in (78, 80):\n        for repeat in range(1, 6):', 'for case in ((78,) if SMOKE else (78, 80)):\n        for repeat in (range(1, 2) if SMOKE else range(1, 6)):')
s=s.replace('arms = ("base", "candidate") if repeat % 2 else ("candidate", "base")','arms = ("base",) if SMOKE else (("base", "candidate") if repeat % 2 else ("candidate", "base"))')
s=s.replace('run_id = f"case{case}-{arm}-r{repeat}"','run_id = f"{\'smoke\' if SMOKE else \'run\'}-case{case}-{arm}-r{repeat}"')
s=s.replace('result = {"schema": "kvu19a2.repeat-diagnostic.v1",', 'result = {"schema": "kvu19a2.repeat-diagnostic.v1", "measurement": False, "smoke": SMOKE, "run_id": OUT.name,')
s=s.replace('record_run(OUT, run_id=OUT.name, producer=str(Path(__file__).resolve()), observations=observations)', '''record_run(OUT, run_id=OUT.name, producer=str(Path(__file__).resolve()), observations=observations)
    if SMOKE:
        result_path = Path(os.environ["FILLER_DRYRUN_RESULT_PATH"])
        with result_path.open("x") as stream:
            json.dump(result, stream, sort_keys=True); stream.write("\\n"); stream.flush(); os.fsync(stream.fileno())''')
f.write_text(s)
f=p/'launch.sh';s=f.read_text().replace(': "${KVU19A2_REPEAT_OUT:?fresh absolute output path required}"', '''if [ "${FILLER_DRYRUN:-0}" = 1 ]; then
  : "${FILLER_DRYRUN_DIR:?allocator isolated smoke dir required}"
  : "${FILLER_DRYRUN_RESULT_PATH:?allocator smoke result path required}"
else
  : "${KVU19A2_REPEAT_OUT:?fresh absolute output path required}"
fi''');f.write_text(s)
spec=p/'spec.ready.json';d=json.loads(spec.read_text());d['smoke_predicate']='python3 '+str(p/'smoke_predicate.py');d['first_progress_s']=120;d['smoke_policy']='One genuine case78/base native launch only; separate smoke run id/output; result at allocator FILLER_DRYRUN_RESULT_PATH; no compute during preparation.'
spec.write_text(json.dumps(d,indent=2)+'\n')
