"""Isolated actual ingest/prepare check. --synthetic is model-free wiring control only."""
import argparse,hashlib,json,struct,sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,'/mnt/raid0/llm/tmp/vb-kvu19a2-wire-20261104/root-code/scripts/vidya')
from adapters import kvu19a2_native as n
import ingest_sources,loop_beliefs
from ledger import Ledger
p=argparse.ArgumentParser();p.add_argument('--synthetic',action='store_true');p.add_argument('--sidecar',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if a.synthetic:
 raw=a.out/'raw.bin';raw.write_bytes(struct.pack('<f',2.0))
 log=a.out/'fixture.log';log.write_text('Device 0: synthetic, gfx90a\n')
 obs={'observed':True,'arm':'base','case':'SYNTHETIC-wiring-control','nan_elements':0,'raw_path':str(raw),'raw_sha256':sha(raw),'source_archive_sha256':'a'*64,'executable_sha256':'b'*64,'hip_sha256':'c'*64,'mapped_ggml':{'/fixture/libggml-hip.so':'c'*64},'mapping_sample_present':True,'samples':[{'kfd':True,'vram_bytes':1024}],'log_path':str(log),'log_sha256':sha(log),'applicability':{'backend':'gpu','device':'gfx90a'}}
 _,sidecar=n.record_run(a.out/'fixture-native',run_id='SYNTHETIC-private-control',producer=str(Path(__file__).resolve()),observations=[obs])
else:
 sidecar=a.sidecar
 if sidecar is None: p.error('--sidecar required for fresh native acceptance')
asof=datetime.now(timezone.utc).isoformat()
report=ingest_sources.ingest(Ledger(a.out/'private-ledger.jsonl'),'kvu19a2-native',[sidecar],as_of=asof)
(a.out/'ingest.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
assert not report['refused'] and report['frames_emitted']>0,report
class PrivateSync:
 def status(self,*args):return {'fresh':True,'lag_entries':0,'index_max_id':0,'synced_max_id':0,'last_sync':asof}
target={'model_file':'Qwen3.8-27B-Q8_0.gguf','quant':'Q8_0','backend':'gpu','device':'gfx90a'}
answer=loop_beliefs.prepare('kvu19a2.private-wiring',target,ledger=a.out/'private-ledger.jsonl',index_path=a.out/'unused-index',as_of=asof,sync_module=PrivateSync(),known_good=a.out/'known-good.json',alarm_state=a.out/'alarm.json',alarm_config=a.out/'alarm.yaml',read_log=a.out/'reads.jsonl')
(a.out/'prepare.json').write_text(json.dumps(answer,indent=2,default=str)+'\n')
assert answer['status']=='ready',answer
assert 'kvu19a2-native' in json.dumps(answer),answer
print(json.dumps({'status':'private-wiring-pass','synthetic':a.synthetic,'canonical_canary':False,'refused':len(report['refused']),'scope':'private freshness fixture; real shared ingest and prepare, host scope only'}))
