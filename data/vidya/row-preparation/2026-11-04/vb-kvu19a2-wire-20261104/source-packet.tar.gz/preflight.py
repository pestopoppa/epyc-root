from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent
s=json.loads((p/'spec.ready.json').read_text())
root=Path(s['root_code']['path'])
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==s['root_code']['head']
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip(), 'detached root code dirty'
for f,want in s['pins'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==want,f
print(json.dumps({'status':'pins-verified','files':len(s['pins']),'gpu_launched':False}))
