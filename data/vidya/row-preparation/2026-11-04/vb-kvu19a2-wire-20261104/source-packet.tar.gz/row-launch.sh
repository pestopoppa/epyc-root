#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-kvu19a2-wire-20261104
ID=handoff-vidya-kvu19a2-wire-20261104
case ${1:-} in
 --job)
  export KVU19A2_ROW_ID=${FILLER_ID:?}
  export KVU19A2_GRANT_RECEIPT=${FILLER_GRANTS_DIR:?}/$KVU19A2_ROW_ID.grant
  export KVU19A2_GRANT_SHA256=$(sha256sum "$KVU19A2_GRANT_RECEIPT" | cut -d' ' -f1)
  export KVU19A2_REPEAT_OUT=$D/run-output
  exec /bin/bash "$D/launch.sh" ;;
 '')
  if [ "${FILLER_DRYRUN:-0}" = 1 ]; then result=${FILLER_DRYRUN_RESULT_PATH:?}; else result=$D/run-output/result.json; fi
  exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id "$ID" --class gpu --role bench --min-window 2100 --stop "$D/STOP" --workdir "$D" --complete-cmd "/usr/bin/test -s $result" --cmd "/bin/bash $D/row-launch.sh --job" ;;
 *) exit 64;;
esac
