from pathlib import Path
import hashlib,json
P=Path(__file__).parent
p=P/'probe.py';s=p.read_text().replace('t0 = time.time()','t0 = time.monotonic()').replace('now = time.time()','now = time.monotonic()');p.write_text(s)
p=P/'observation.py';s=p.read_text().replace('import threading','import threading\nimport time').replace('self.samples = []','self.samples = []\n        self.sample_times = []').replace('self.samples.append(self.reader(self.pid))','self.sample_times.append(time.monotonic())\n            self.samples.append(self.reader(self.pid))').replace("'samples': self.samples,","'samples': self.samples, 'sample_monotonic_s':self.sample_times,");p.write_text(s)
p=P/'approved-inputs.json';d=json.loads(p.read_text());d['probe_sha256']=hashlib.sha256((P/'probe.py').read_bytes()).hexdigest();p.write_text(json.dumps(d,indent=2)+'\n')
p=P/'summarize.py';s=p.read_text();a=s.index('PROBE_SHA=');b=s.index('\n',a);s=s[:a]+'PROBE_SHA='+repr(d['probe_sha256'])+s[b:];p.write_text(s)
p=P/'job.py';s=p.read_text().replace('tmp=complete.with_suffix',"from reader import write_native\nwrite_native(OUT)\ntmp=complete.with_suffix");p.write_text(s)
