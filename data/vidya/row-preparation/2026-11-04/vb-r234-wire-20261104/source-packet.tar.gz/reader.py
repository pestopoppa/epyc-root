"""Reopen original requests; project native mappings through shared measurement ladder only.

No response-ID assertion is supported. Window acceptance remains UNKNOWN for attribution.
"""
import dataclasses,hashlib,json,math,sys
from datetime import datetime,timezone
from pathlib import Path
from summarize import summarize
from observation import acceptance_window
from native_capture import source_closure, verify_root_code
ROOT_CODE=verify_root_code()
sys.path.insert(0,str(Path(ROOT_CODE['path'])/'scripts/vidya'))
from claim_tuple import ClaimTuple,grade
import claim_tuple as _claim_module
if Path(_claim_module.__file__).resolve()!=Path(ROOT_CODE["path"])/"scripts/vidya/claim_tuple.py":raise ValueError("claim_tuple imported outside pinned root-code")

def digest(raw):return hashlib.sha256(raw).hexdigest()
def native(rows):
 result=summarize(rows)
 identity=rows[0].get('native_identity')
 if not isinstance(identity,dict) or identity.get('schema')!='epyc.r234.native_identity.v1':raise ValueError('missing prospective identity')
 if identity.get('root_code')!=verify_root_code():raise ValueError('captured root-code source differs')
 expected=json.loads(Path(__file__).with_name('SOURCE.json').read_text())
 closure=identity.get('source_closure',{})
 if set(closure)!=set(expected) or any(closure[k].get('sha256')!=v for k,v in expected.items()):raise ValueError('source closure is not approved candidate')
 grant=identity.get('grant',{})
 if not grant.get('raw') or not grant.get('environment'):raise ValueError('missing grant')
 if not math.isfinite(grant.get('captured_at',float('nan'))):raise ValueError('missing grant clock')
 arm_pids={}
 for r in rows:
  if not grant['captured_at']<=r['started_at']<=float(grant['environment']['FILLER_DEADLINE']):raise ValueError('request outside captured grant deadline')
  if r.get('native_identity')!=identity or r.get('disposition')!='complete':raise ValueError('mixed identity or disposition')
  arm_pids.setdefault(r['arm_index'],set()).add(r['server_pid'])
  cap=r.get('stream_capture',{})
  if cap.get('completed') is not True or cap.get('request',{}).get('messages')!=[{'role':'user','content':r.get('prompt')}]:raise ValueError('missing original request')
  times=[];done=False
  for e in cap.get('events',[]):
   line=e['raw'].strip();ts=e['elapsed_s']
   if not math.isfinite(ts) or ts<0:raise ValueError('invalid event time')
   if line=='data: [DONE]':done=True;continue
   if line.startswith('data: '):
    delta=json.loads(line[6:])['choices'][0].get('delta',{})
    if delta.get('content') or delta.get('reasoning_content'):times.append(ts)
  if not done or len(times)<2 or times!=sorted(times):raise ValueError('incomplete stream')
  rate=len(times)/(times[-1]-times[0])
  if not math.isclose(rate,r['client_stream_events_s'],rel_tol=0.0001):raise ValueError('stream rate does not rederive')
  a=acceptance_window(r['acceptance']['raw'])
  if any(a.get(k)!=r['acceptance'].get(k) for k in ('state','accepted','generated','ratio','slot','task')):raise ValueError('acceptance does not rederive')
  if r.get('response_id_attribution')!='UNKNOWN':raise ValueError('window attribution overclaim')
  ts=r['residency'].get('sample_monotonic_s',[])
  if len(ts)!=len(r['residency']['samples']) or len(ts)<2 or ts!=sorted(ts) or not all(r['started_monotonic_s']<=t<=r['ended_monotonic_s'] for t in ts):raise ValueError('residency window mismatch')
  dsos=r.get('mapped_closure',[])
  if not dsos or not any(d['path']==r['mapped_hip'][0] and d['sha256']==r['input_packet']['expected_hip_sha256'] for d in dsos):raise ValueError('mapped DSO digest missing')
 if any(len(v)!=1 for v in arm_pids.values()) or len({next(iter(v)) for v in arm_pids.values()})!=7:raise ValueError('fresh server arms missing')
 result['response_id_attribution']='UNKNOWN'
 return result

def mappings(rows,result,sha,locator):
 first=rows[0];out=[]
 for c in result['comparisons']:
  # These descriptive mappings are authored at original write, then exactly rederived on read.
  out.append(dict(measurement_id=f"r234:{result['run_id']}:{c['factor']}:{c['prompt_index']}:{c['metric']}",metric=c['metric'],value=c['intervention_median'],date=datetime.fromtimestamp(first['started_at'],timezone.utc).date().isoformat(),category='CANDIDATE',claim=f"R23-4 {c['factor']} prompt {c['prompt_index']} {c['metric']} median over three requests with adjacent fresh baselines; response-ID attribution UNKNOWN",metric_direction='higher_better',protocol_id='',reps=3,reps_basis='scored:requests within one fresh server arm; not independent launches',unit='ratio' if c['metric']=='acceptance_ratio' else 'events/s',attestation_locator=locator,attestation_sha256=sha,attestation_present=True,attestation_verified=True,source_kind='autokernel-r234-native-sweep',applicability=dict(model_file=first['native_identity']['model']['path'],model_sha256=first['input_packet']['model_sha256'],build_sha=first['input_packet']['source_commit'],backend='gpu',run_id=result['run_id'],scope_basis='native',knob_family=c['factor']),observation=dict(outcome_native=c['classification'],anchor_value=c['baseline_before_median'],outcome_reason='Descriptive adjacent-baseline comparison; window-only acceptance attribution UNKNOWN'),extra=dict(adjacent_baselines=[c['baseline_before_median'],c['baseline_after_median']],raw_repetitions=c['raw_repetitions'],response_id_attribution='UNKNOWN')))
 return out

def write_native(path):
 path=Path(path);raw=path.read_bytes();rows=[json.loads(s) for s in raw.splitlines()];result=native(rows)
 packet=dict(schema='epyc.r234.native_comparisons.v1',request_sha256=digest(raw),comparison=result,belief_measurements=mappings(rows,result,digest(raw),str(path)))
 path.with_name('native-comparisons.json').write_text(json.dumps(packet,sort_keys=True,allow_nan=False)+'\n')
 return packet

def read(path):
 path=Path(path);raw=path.read_bytes()
 if len(raw)>64<<20:raise ValueError('request capture too large')
 rows=[json.loads(s) for s in raw.splitlines()];result=native(rows)
 packet=json.loads(path.with_name('native-comparisons.json').read_text())
 expected=dict(schema='epyc.r234.native_comparisons.v1',request_sha256=digest(raw),comparison=result,belief_measurements=mappings(rows,result,digest(raw),str(path)))
 if packet!=expected:raise ValueError('native comparison or measurement mapping mismatch')
 tuples=[ClaimTuple(**m) for m in packet['belief_measurements']]
 return [dict(measurement=dataclasses.asdict(t),grade=grade(t)) for t in tuples]
if __name__=='__main__':
 try:print(json.dumps(read(sys.argv[1]),allow_nan=False))
 except Exception as exc:print(json.dumps({'state':'UNKNOWN','refused':str(exc)}));sys.exit(1)
