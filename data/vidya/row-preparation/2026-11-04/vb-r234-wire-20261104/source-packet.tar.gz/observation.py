"""Request-window observations; absent or ambiguous evidence is never a pass."""
import re
import threading
import time
from pathlib import Path

KFD_ROOT = Path('/sys/class/kfd/kfd/proc')
PATTERN = re.compile(r'slot\s+print_timing:\s*id\s+(\d+)\s*\|\s*task\s+(\d+)\s*\|\s*draft acceptance\s*=\s*([\d.]+)\s*\(\s*(\d+) accepted\s*/\s*(\d+) generated\s*\)')

def own_vram(pid, root=KFD_ROOT):
    try:
        if not root.is_dir(): return None
        proc = root / str(pid)
        if not proc.is_dir(): return 0
        files = list(proc.glob('vram_*'))
        if not files: return None
        return sum(int(p.read_text().strip()) for p in files)
    except (OSError, ValueError):
        return None

class RequestResidency:
    def __init__(self, pid, *, reader=own_vram, interval=0.25):
        self.pid, self.reader, self.interval = pid, reader, interval
        self.samples = []
        self.sample_times = []
        self.stop = threading.Event()
        self.thread = None
    def _sample(self):
        while not self.stop.is_set():
            self.sample_times.append(time.monotonic())
            self.samples.append(self.reader(self.pid))
            self.stop.wait(self.interval)
    def __enter__(self):
        self.thread = threading.Thread(target=self._sample, daemon=True)
        self.thread.start()
        return self
    def __exit__(self, *args):
        self.stop.set()
        self.thread.join(timeout=5)
    def result(self):
        readable = [x for x in self.samples if x is not None]
        return {'own_pid': self.pid, 'samples': self.samples, 'sample_monotonic_s':self.sample_times, 'readable':len(readable),
                'resident': len(readable) >= 2 and all(x >= (1 << 30) for x in readable),
                'criterion': 'two or more readable own-PID KFD samples >= 1 GiB during request'}

def acceptance_window(text):
    matches = list(PATTERN.finditer(text))
    if len(matches) != 1:
        return {'state':'unknown', 'reason':f'{len(matches)} acceptance lines in request window', 'raw':text}
    slot, task, ratio, accepted, generated = matches[0].groups()
    a, g = int(accepted), int(generated)
    if g <= 0 or a > g or abs(float(ratio) - a/g) > 0.00002:
        return {'state':'unknown', 'reason':'inconsistent acceptance counts', 'raw':text}
    return {'state':'window_correlated', 'slot':int(slot), 'task':int(task), 'accepted':a,
            'generated':g, 'ratio':float(ratio), 'raw':matches[0].group(0),
            'limitation':'unique synchronous single-slot request window; no response task ID binding'}


def await_acceptance_window(path, start, *, timeout_s=3.0, settle_s=0.5,
                            interval_s=0.1, clock=None, pause=None):
    """Bound log tailing after a response without starting the next request.

    One line must be observed and remain unique for `settle_s`; multiple lines,
    a truncated log, or timeout is UNKNOWN. This does not establish response-ID
    attribution; later-than-window log lines are not silently matched later.
    """
    import time
    clock = clock or time.monotonic
    pause = pause or time.sleep
    deadline = clock() + timeout_s
    unique_since = None
    path = Path(path)
    while True:
        end = path.stat().st_size
        if end < start:
            return {'state': 'unknown', 'reason': 'server log truncated'}, end
        with path.open('rb') as stream:
            stream.seek(start)
            raw = stream.read(end-start).decode('utf8', errors='replace')
        count = len(list(PATTERN.finditer(raw)))
        now = clock()
        if count > 1:
            return acceptance_window(raw), end
        if count == 1:
            unique_since = now if unique_since is None else unique_since
            if now - unique_since >= settle_s:
                result = acceptance_window(raw)
                result['capture'] = {'timeout_s': timeout_s, 'settle_s': settle_s}
                result['limitation'] = ('serial request window only; no response task ID; '
                                        'later asynchronous lines cannot be ruled out')
                return result, end
        if now >= deadline:
            return {'state': 'unknown', 'reason': 'acceptance absent or not stable before timeout',
                    'raw': raw, 'capture': {'timeout_s': timeout_s, 'settle_s': settle_s}}, end
        pause(min(interval_s, max(0.0, deadline-now)))
