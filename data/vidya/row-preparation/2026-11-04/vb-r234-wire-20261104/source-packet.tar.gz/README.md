# VB-AK-R23-4-SWEEP-WIRE prospective candidate

Prepared only; no compute run, grant, publication, ingestion or real planning canary.

This is a GPU DFlash serving sweep with CPU placement dependency. It cannot be
represented as a CPU-only row without changing the R23-4 question. Official
reservation: MI210 + CPUs 0-23,184-191; baseline vs context, kv and affinity,
seven ordered fresh processes, three prompts x three repeats. Existing v10
binary closure and pre-grant prepared model/drafter identity are preserved;
this does not establish historical binary identity.

`launch.sh` and `spec.json` are owner-publish candidates. `job.py --check` is
model-free preflight. Allocator smoke honors WS58_REGIONS as CPU claim override
and FILLER_DRYRUN_RESULT_PATH; requires that allocator variable, runs one actual
baseline prompt, writes SMOKE_COMPLETE only. Smoke cannot be read as full sweep.
No fixtures are publisher/keeper output. Official output uses runs/<uuid> and
requires 63 requests. Run `reader.py <official results.jsonl>` only after native
comparison has been authored by producer. It rederives raw stream rates,
acceptance counts, ordering, neighboring baselines, and timed own-PID residency,
then compares all original mappings and calls shared ClaimTuple/grade only.
No custom ladder, protocol, causal assertion or response-ID proof is introduced.
Window-only acceptance is explicitly UNKNOWN for response-ID attribution.

SOURCE.json pins candidate files. Changing pinned code requires regenerating
SOURCE.json and SHA256SUMS after review. Native capture binds exact source files,
launcher, executable, all mapped DSOs, prepared model/drafter identifiers, grant
receipt and CPU placement; raw SSE events and original requests are retained.
Source hashes are checked before a request run. Prepared model metadata is
rechecked; model weights are not hashed under grant. Grant raw receipt remains
an observed authorization record, not an independent authority verifier.

Validation: Python compile, shell syntax, 18 model-free unittest controls,
including tamper, missing stream, out-of-window residency and attribution refusal.
The unit positive case is explicitly synthetic; it proves no real ingestion or
planning-context canary. Do not call the source wired before the handoff's real
post-hook ingestion with refused=0 and model-target planning canary.

Root-code finalization dependency is now one sparse detached worktree at
root-code, HEAD 1ea56a495413be89ea9bcc89407f547a47f3e9f2. root-code-pin.json pins
every scripts/vidya Python source. Preflight checks detached HEAD, tracked clean
state and exact hashes; native identity captures that same pin. Reader verifies
the pin before import, rejects cached claim_tuple outside that worktree, and
rechecks captured pin on native projection. No live lane imports remain.
Spec owner is handoff-vidya-belief-substrate.
