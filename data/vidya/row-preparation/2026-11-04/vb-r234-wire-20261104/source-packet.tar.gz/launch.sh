#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-r234-wire-20261104
MARKER=COMPLETE
MIN_WINDOW=3600
if [ "${FILLER_DRYRUN:-0}" = 1 ]; then
  : "${FILLER_DRYRUN_RESULT_PATH:?allocator must provide distinct smoke output}"
  MARKER=SMOKE_COMPLETE
  MIN_WINDOW=900
fi
CLAIM_CPUS=0-23,184-191
if [ -n "${WS58_REGIONS:-}" ]; then
  CLAIM_CPUS=${WS58_REGIONS//mi210_0,/}
  CLAIM_CPUS=${CLAIM_CPUS//,mi210_0/}
  if [ "$CLAIM_CPUS" = mi210_0 ]; then CLAIM_CPUS=184-191; fi
fi
exec bash "$D/filler_run15.sh" --id vidya-r234-native-sweep-20261104 --class gpu --role bench --gpu-quiet shared --claim-cpus "$CLAIM_CPUS" --port 18746 --min-window "$MIN_WINDOW" --stop "$D/STOP" --complete-cmd "test -f '$D/$MARKER'" --workdir "$D" --cmd "python3 '$D/job.py'" --precond-cmd "python3 '$D/job.py' --check"
