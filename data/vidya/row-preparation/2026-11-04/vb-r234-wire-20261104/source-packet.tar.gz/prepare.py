from pathlib import Path
import hashlib,json
P=Path(__file__).parent
old='/mnt/raid0/llm/tmp/autokernel-rebuild/r23sweep-v10-revised'
for name in ('job.py','launch.sh','spec.json'):
 p=P/name;p.write_text(p.read_text().replace(old,str(P)).replace('autokernel-r23-4-v10-sweep-revised-20261102','vidya-r234-native-sweep-20261104'))
p=P/'probe.py';s=p.read_text();s=s.replace('def run(prompt, max_tokens=MAX_TOKENS):','LAST_CAPTURE = None\n\ndef run(prompt, max_tokens=MAX_TOKENS):\n    global LAST_CAPTURE')
s=s.replace('    t0 = time.time()','    events = []\n    started = time.monotonic()\n    LAST_CAPTURE = {"request": body, "url": URL, "events": events, "started_monotonic_s": started, "completed": False}\n    t0 = time.time()')
s=s.replace('            line = line.decode().strip()','            events.append({"elapsed_s": time.monotonic()-started, "raw": line.decode("utf8", errors="strict")})\n            line = line.decode().strip()')
s=s.replace('    span = last - t0 - (ttft or 0)','    LAST_CAPTURE.update(ended_monotonic_s=time.monotonic(), completed=True, content_event_count=n, ttft_s=ttft, span_s=last-t0-(ttft or 0))\n    span = last - t0 - (ttft or 0)')
p.write_text(s)
p=P/'job.py';s=p.read_text().replace('from observation import RequestResidency, await_acceptance_window','from observation import RequestResidency, await_acceptance_window\nfrom native_capture import artifact, source_closure, grant_capture, mapped_closure')
s=s.replace("run_dir.mkdir(parents=True, exist_ok=False)","run_dir.mkdir(parents=True, exist_ok=False)\nnative_identity={'schema':'epyc.r234.native_identity.v1','source_closure':source_closure(P),'grant':grant_capture(), 'executable':artifact(server),'model':inputs['inputs']['model'],'drafter':inputs['inputs']['draft']}\nrecord(native_identity,run_dir/'identity.jsonl')")
s=s.replace("'log':str(log),'run_id':run_id}","'log':str(log),'run_id':run_id,'native_identity':native_identity,'prompt':prompt,'disposition':'started'}")
s=s.replace("entry['ended_monotonic_s']=time.monotonic()","entry['ended_monotonic_s']=time.monotonic()\n                        entry['stream_capture']=probe.LAST_CAPTURE\n                        entry['mapped_closure']=mapped_closure(proc.pid)")
s=s.replace("entry.update(client_stream_events_s=speed,acceptance=acceptance,","entry.update(disposition='complete',response_id_attribution='UNKNOWN',client_stream_events_s=speed,acceptance=acceptance,")
s=s.replace("entry.update(failure=f'{type(exc).__name__}: {exc}',residency=residency.result())","entry.update(disposition='failed',failure=f'{type(exc).__name__}: {exc}',residency=residency.result(),stream_capture=probe.LAST_CAPTURE)")
s=s.replace('if stop(): sys.exit(75)',"if stop():\n                        record({'schema':'epyc.r234.cutoff.v1','run_id':run_id,'arm_index':index,'disposition':'cutoff'},run_dir/'failures.jsonl')\n                        sys.exit(75)")
# indentation-sensitive replacement above: preserve original indentation by replacing lines directly instead
s=s.replace("if stop():\n                        record({'schema':'epyc.r234.cutoff.v1','run_id':run_id,'arm_index':index,'disposition':'cutoff'},run_dir/'failures.jsonl')\n                        sys.exit(75)","if stop(): cutoff(index)")
s=s.replace("byname={a['name']:a for a in D['arms']}","def cutoff(index):\n    record({'schema':'epyc.r234.cutoff.v1','run_id':run_id,'arm_index':index,'disposition':'cutoff'},run_dir/'failures.jsonl')\n    raise SystemExit(75)\n\nbyname={a['name']:a for a in D['arms']}")
p.write_text(s)
p=P/'approved-inputs.json';d=json.loads(p.read_text());d['probe_sha256']=hashlib.sha256((P/'probe.py').read_bytes()).hexdigest();p.write_text(json.dumps(d,indent=2)+'\n')
p=P/'summarize.py';s=p.read_text().replace("PROBE_SHA='d9ea0c9fb10435937c774d4b182a6b5ac8481837e8b3d1aa23738eeb178dfd5f'","PROBE_SHA="+repr(d['probe_sha256']));p.write_text(s)
