import copy
import unittest
from summarize import summarize, ORDER, SOURCE, HIP, HIP_SHA, MODEL_SHA, DRAFT_SHA, PROBE_SHA, BROAD, PINNED, SERVER, MANIFEST, expected_argv

PACKET=dict(source_commit=SOURCE, model_sha256=MODEL_SHA, draft_sha256=DRAFT_SHA,
            probe_sha256=PROBE_SHA, expected_hip_sha256=HIP_SHA, expected_hip=HIP, server=SERVER, closure_manifest=MANIFEST)

def rows():
 return [dict(schema='epyc.r23-4.request.v1',arm=ORDER[i],arm_index=i,prompt_index=p,repeat=k,
              acceptance={'state':'window_correlated','ratio': .6 if i==1 else .5,
                          'accepted':6 if i==1 else 5,'generated':10},
              residency={'resident':True,'own_pid':100+i,'samples':[1<<30,1<<30], 'readable':2},
              server_pid=100+i,host_affinity=sorted(PINNED if i==5 else BROAD),argv=expected_argv(i),
              started_monotonic_s=float((i*9+p*3+k)*2),ended_monotonic_s=float((i*9+p*3+k)*2+1),
              client_stream_events_s=60 if i==1 else 50,mapped_hip=[HIP],
              input_packet=copy.deepcopy(PACKET),run_id='same')
         for i in range(7) for p in range(3) for k in range(3)]
class RuleTest(unittest.TestCase):
 def test_complete_and_exact_bracket(self):
  result=summarize(rows()); self.assertEqual(len(result['comparisons']),18)
  self.assertEqual(result['comparisons'][0]['classification'],'outside-observed-baseline')
  self.assertEqual(result['comparisons'][6]['classification'],'within-observed-baseline')
 def test_missing_duplicate_and_mixed_refused(self):
  x=rows()
  for altered in (x[:-1],x+[x[0]],x[:-1]+[dict(x[-1],run_id='other')]):
   with self.assertRaises(ValueError): summarize(altered)
 def test_actual_order_and_nonoverlap_required(self):
  x=rows(); x[0],x[1]=x[1],x[0]
  with self.assertRaisesRegex(ValueError,'order'): summarize(x)
  x=rows(); x[1]['started_monotonic_s']=x[0]['ended_monotonic_s']-.5
  with self.assertRaisesRegex(ValueError,'interval'): summarize(x)
  x=rows(); del x[0]['ended_monotonic_s']
  with self.assertRaisesRegex(ValueError,'interval'): summarize(x)
  x=rows(); x[0]['ended_monotonic_s']=float('nan')
  with self.assertRaisesRegex(ValueError,'interval'): summarize(x)
 def test_unknown_refused(self):
  x=rows(); x[0]['acceptance']={'state':'unknown'}
  with self.assertRaises(ValueError): summarize(x)
 def test_identity_variants_refused(self):
  for field,value in [('source_commit','wrong'),('model_sha256','wrong'),('expected_hip','wrong')]:
   x=rows(); x[0]['input_packet'][field]=value
   with self.assertRaises(ValueError): summarize(x)
  x=rows(); x[0]['mapped_hip']=['/wrong']
  with self.assertRaises(ValueError): summarize(x)
  x=rows(); x[0]['input_packet']['extra']='different'
  with self.assertRaises(ValueError): summarize(x)
 def test_wrong_executable_or_invocation_refused(self):
  for field in ('server','closure_manifest'):
   x=rows()
   for row in x: row['input_packet'][field]='/unexpected'
   with self.assertRaises(ValueError): summarize(x)
  x=rows(); x[1]['argv']=expected_argv(3)
  with self.assertRaises(ValueError): summarize(x)
 def test_gpu_proof_refused(self):
  for updates in ({'samples':[0,1<<30]}, {'samples':[1<<30]}, {'own_pid':999}, {'readable':1}):
   x=rows(); x[0]['residency'].update(updates)
   with self.assertRaises(ValueError): summarize(x)
 def test_affinity_and_counts_refused(self):
  x=rows(); x[0]['host_affinity']=sorted(PINNED)
  with self.assertRaises(ValueError): summarize(x)
  x=rows(); x[0]['acceptance']['accepted']=7
  with self.assertRaises(ValueError): summarize(x)
if __name__=='__main__': unittest.main()
