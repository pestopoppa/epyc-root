#!/usr/bin/env python3
"""Descriptive within-sweep comparison, not a statistical or causal verdict."""
import json, math, statistics, sys
from pathlib import Path

ORDER=['baseline','context','baseline','kv','baseline','affinity','baseline']
SOURCE='ffc1bac82eeca6f9099e1ccd9ba49703c460a115'
HIP='/mnt/raid0/llm/tmp/autokernel-rebuild/v10-verified/bin/libggml-hip.so.0.16.0'
HIP_SHA='f26a166b8ea3089d19a395ae00afa22e917df8eba71ca6ef4be5235d65ea8079'
MODEL_SHA='a680f44a06920e5d689774823782006aa3acc8db95750323373b24139b67e348'
DRAFT_SHA='7f1c9a31a6ed40044c69f6508b50fd63b87abd8e1fb7fe4290303df549153751'
PROBE_SHA='3feb7382f07acc1abb149c5d8dc8b94527f08768f385fccf15909496923a98b0'
BROAD=set(range(24))|set(range(184,192)); PINNED=set(range(184,192))
SERVER='/mnt/raid0/llm/tmp/autokernel-rebuild/v10-verified/bin/llama-server'
MODEL='/mnt/raid0/llm/models/Qwen3.8-27B-Q8_0.gguf'
DRAFT='/mnt/raid0/llm/models/Qwen3.8-27B-DFlash2-Q8_0.gguf'
MANIFEST='/mnt/raid0/llm/tmp/autokernel-rebuild/v10-verified/SHA256SUMS'

def expected_argv(i):
    argv=[SERVER,'-m',MODEL,'-md',DRAFT,'-c',str(4096 if i==1 else 32768),
          '--host','127.0.0.1','--port','18746','-np','1','-t','8','-tb','8',
          '-b','2048','-ub','2048','-ctk','f16','-ctv','f16','--device','ROCm0',
          '-ngl','99','-fa','on','--metrics','--slots','-ngld','99',
          '--spec-type','draft-dflash','--spec-draft-n-max','8']
    if i==3: argv += ['--no-kv-unified']
    if i==5: argv = ['taskset','-c','184-191'] + argv
    return argv

def summarize(rows):
    seen={}; first_packet=None; previous_end=None
    expected_keys=[(i,p,k) for i in range(7) for p in range(3) for k in range(3)]
    for index,r in enumerate(rows):
        if r.get('failure') or r.get('schema')!='epyc.r23-4.request.v1':
            raise ValueError('failed or wrong-schema request')
        i,p,k=r.get('arm_index'),r.get('prompt_index'),r.get('repeat')
        if type(i) is not int or type(p) is not int or type(k) is not int or not(0<=i<7 and 0<=p<3 and 0<=k<3) or r.get('arm')!=ORDER[i]:
            raise ValueError('invalid arm or request key')
        if (i,p,k) in seen: raise ValueError('duplicate request')
        if index >= len(expected_keys) or (i,p,k) != expected_keys[index]: raise ValueError('unexpected actual request order')
        start,end=r.get('started_monotonic_s'),r.get('ended_monotonic_s')
        if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in (start,end)) or start < 0 or end <= start or (previous_end is not None and start < previous_end):
            raise ValueError('missing, overlapping or invalid monotonic request interval')
        previous_end=end
        a=r.get('acceptance') or {}; residence=r.get('residency') or {}
        if a.get('state')!='window_correlated' or not residence.get('resident'):
            raise ValueError('unknown acceptance or residency')
        vals=(a.get('ratio'),r.get('client_stream_events_s'))
        if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in vals) or not 0<=vals[0]<=1 or vals[1]<=0:
            raise ValueError('invalid observation')
        packet=r.get('input_packet')
        if not isinstance(packet,dict) or (packet.get('source_commit'),packet.get('model_sha256'),packet.get('draft_sha256'),packet.get('probe_sha256'),packet.get('expected_hip_sha256'),packet.get('expected_hip')) != (SOURCE,MODEL_SHA,DRAFT_SHA,PROBE_SHA,HIP_SHA,HIP):
            raise ValueError('missing or unexpected input identity')
        if packet.get('server')!=SERVER or packet.get('closure_manifest')!=MANIFEST:
            raise ValueError('unexpected executable or manifest path')
        if r.get('argv')!=expected_argv(i):
            raise ValueError('unexpected server invocation for arm')
        if first_packet is None: first_packet=packet
        elif packet!=first_packet: raise ValueError('mixed input identity')
        if not r.get('run_id') or r.get('mapped_hip') != [HIP]: raise ValueError('unexpected mapped HIP')
        pid=r.get('server_pid'); samples=residence.get('samples')
        if type(pid) is not int or pid<=0 or residence.get('own_pid')!=pid or not isinstance(samples,list): raise ValueError('missing own-PID GPU proof')
        readable=[x for x in samples if x is not None]
        if any(type(x) is not int or x < 0 for x in readable) or len(readable)<2 or any(x < (1<<30) for x in readable) or residence.get('readable')!=len(readable): raise ValueError('invalid own-PID GPU proof')
        mask=r.get('host_affinity')
        if not isinstance(mask,list) or any(type(x) is not int for x in mask) or len(mask)!=len(set(mask)) or set(mask)!=(PINNED if i==5 else BROAD): raise ValueError('unexpected host affinity')
        accepted,generated=a.get('accepted'),a.get('generated')
        if type(accepted) is not int or type(generated) is not int or generated<=0 or not 0<=accepted<=generated or abs(vals[0]-accepted/generated)>0.00002: raise ValueError('inconsistent acceptance counts')
        seen[i,p,k]=r
    if len(seen)!=63 or len({r['run_id'] for r in seen.values()})!=1: raise ValueError('incomplete or mixed runs')
    output=[]
    for i in (1,3,5):
        for p in range(3):
            for label,getval in [('acceptance_ratio',lambda r:r['acceptance']['ratio']),('client_stream_events_s',lambda r:r['client_stream_events_s'])]:
                raw=[[getval(seen[j,p,k]) for k in range(3)] for j in (i-1,i,i+1)]
                before,mid,after=[statistics.median(a) for a in raw]
                where='outside-observed-baseline' if mid<min(before,after) or mid>max(before,after) else 'within-observed-baseline'
                output.append({'factor':ORDER[i],'prompt_index':p,'metric':label,'baseline_before_median':before,'intervention_median':mid,'baseline_after_median':after,'classification':where,'raw_repetitions':raw})
    return {'status':'complete-descriptive','units':63,'run_id':next(iter(seen.values()))['run_id'],'comparisons':output,'limitations':'Window association is not response-ID proof. No p-value, causal or generalization claim.'}

if __name__=='__main__':
    try:
        rows=[json.loads(s) for s in Path(sys.argv[1]).read_text().splitlines() if s.strip()]
        print(json.dumps(summarize(rows),indent=2,allow_nan=False))
    except (OSError,IndexError,ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
        print(json.dumps({'status':'INCOMPLETE_OR_INVALID','reason':str(e)})); sys.exit(1)
