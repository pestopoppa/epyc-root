import tempfile
import unittest
from pathlib import Path
from observation import await_acceptance_window

LINE='slot print_timing: id 0 | task 9 | draft acceptance = 0.50000 ( 5 accepted / 10 generated)'

class FakeClock:
    def __init__(self, path, arrivals): self.t=0.; self.path=path; self.arrivals=list(arrivals)
    def now(self): return self.t
    def pause(self, amount):
        self.t+=amount
        while self.arrivals and self.arrivals[0][0] <= self.t+1e-8:
            _, text=self.arrivals.pop(0)
            with self.path.open('a') as out: out.write(text+'\n')

class DelayedTest(unittest.TestCase):
    def run_case(self, arrivals):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log'; p.write_text('prior\n')
            c=FakeClock(p, arrivals)
            return await_acceptance_window(p,p.stat().st_size,timeout_s=2,settle_s=.5,interval_s=.1,clock=c.now,pause=c.pause)[0]
    def test_delayed_line(self):
        x=self.run_case([(0.3,LINE)])
        self.assertEqual((x['state'],x['accepted'],x['generated']),('window_correlated',5,10))
        self.assertIn('no response task ID',x['limitation'])
    def test_duplicate_rejected(self):
        self.assertEqual(self.run_case([(0.1,LINE),(0.3,LINE)])['state'],'unknown')
    def test_absent_rejected(self):
        self.assertEqual(self.run_case([])['state'],'unknown')
    def test_late_beyond_deadline_rejected(self):
        self.assertEqual(self.run_case([(2.1,LINE)])['state'],'unknown')
if __name__ == '__main__': unittest.main()
