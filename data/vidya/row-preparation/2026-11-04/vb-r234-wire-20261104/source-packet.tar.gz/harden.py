from pathlib import Path
P=Path(__file__).parent
p=P/'native_capture.py';s=p.read_text();a=s.index('def source_closure(root):');b=s.index('\ndef grant_capture',a);s=s[:a]+'''def source_closure(root):
 root=Path(root)
 expected=json.loads((root/'SOURCE.json').read_text())
 actual={name:artifact(root/name) for name in expected}
 if any(actual[name]['sha256']!=sha for name,sha in expected.items()):raise ValueError('source closure changed since readiness')
 return actual
''' +s[b:];p.write_text(s)
p=P/'reader.py';s=p.read_text().replace('from observation import acceptance_window','from observation import acceptance_window\nfrom native_capture import source_closure')
s=s.replace("if not identity.get('source_closure') or not identity.get('grant',{}).get('raw'):raise ValueError('missing source or grant')", """expected=json.loads(Path(__file__).with_name('SOURCE.json').read_text())
 closure=identity.get('source_closure',{})
 if set(closure)!=set(expected) or any(closure[k].get('sha256')!=v for k,v in expected.items()):raise ValueError('source closure is not approved candidate')
 grant=identity.get('grant',{})
 if not grant.get('raw') or not grant.get('environment'):raise ValueError('missing grant')
 if not math.isfinite(grant.get('captured_at',float('nan'))):raise ValueError('missing grant clock')""")
s=s.replace("if r.get('native_identity')!=identity", "if not grant['captured_at']<=r['started_at']<=float(grant['environment']['FILLER_DEADLINE']):raise ValueError('request outside captured grant deadline')\n  if r.get('native_identity')!=identity")
p.write_text(s)
p=P/'test_native.py';s=p.read_text().replace('from summarize import PROBE_SHA,HIP,HIP_SHA','from summarize import PROBE_SHA,HIP,HIP_SHA\nfrom native_capture import source_closure');s=s.replace("'source_closure':{'fixture':'fixture-only'},'grant':{'raw':'fixture-only'}", "'source_closure':source_closure(Path(__file__).parent),'grant':{'raw':'fixture-only','captured_at':1793750399.,'environment':{'FILLER_DEADLINE':'1793759999'}}")
p.write_text(s)
