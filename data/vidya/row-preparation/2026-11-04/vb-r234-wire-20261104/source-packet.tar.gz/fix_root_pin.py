from pathlib import Path
import hashlib,json
P=Path(__file__).parent
root=P/'root-code'
pin={'path':str(root),'head':'1ea56a495413be89ea9bcc89407f547a47f3e9f2','files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'scripts/vidya').rglob('*.py'))}}
(P/'root-code-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
f=P/'native_capture.py';s=f.read_text().replace('import hashlib,json,os,time','import hashlib,json,os,time,subprocess');s+='''

def verify_root_code():
 pin=json.loads(Path(__file__).with_name('root-code-pin.json').read_text())
 root=Path(pin['path'])
 head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
 if head!=pin['head']:raise ValueError('root-code HEAD differs')
 if subprocess.run(['git','-C',str(root),'symbolic-ref','-q','HEAD'],capture_output=True).returncode!=1:raise ValueError('root-code must remain detached')
 if subprocess.check_output(['git','-C',str(root),'status','--porcelain','--untracked-files=no'],text=True).strip():raise ValueError('root-code tracked state dirty')
 for rel,sha in pin['files'].items():
  if artifact(root/rel)['sha256']!=sha:raise ValueError('root-code imported source differs: '+rel)
 return pin
''';f.write_text(s)
f=P/'job.py';s=f.read_text().replace('grant_capture, mapped_closure','grant_capture, mapped_closure, verify_root_code').replace('def verify_inputs():','def verify_inputs():\n    verify_root_code()');s=s.replace("'source_closure':source_closure(P)","'root_code':verify_root_code(),'source_closure':source_closure(P)");f.write_text(s)
f=P/'reader.py';s=f.read_text().replace('from native_capture import source_closure','from native_capture import source_closure, verify_root_code');s=s.replace("sys.path.insert(0,'/mnt/raid0/llm/worktrees/mains/h-vidya-belief-substrate/scripts/vidya')","ROOT_CODE=verify_root_code()\nsys.path.insert(0,str(Path(ROOT_CODE['path'])/'scripts/vidya'))");s=s.replace("identity=rows[0].get('native_identity')","identity=rows[0].get('native_identity')");s=s.replace("expected=json.loads(Path(__file__).with_name('SOURCE.json').read_text())","if identity.get('root_code')!=verify_root_code():raise ValueError('captured root-code source differs')\n expected=json.loads(Path(__file__).with_name('SOURCE.json').read_text())");f.write_text(s)
f=P/'test_native.py';s=f.read_text().replace('from native_capture import source_closure','from native_capture import source_closure,verify_root_code').replace("'schema':'epyc.r234.native_identity.v1'","'schema':'epyc.r234.native_identity.v1','root_code':verify_root_code()");f.write_text(s)
f=P/'spec.json';d=json.loads(f.read_text());d['owner']='handoff-vidya-belief-substrate';d['keep']+=['root-code-pin.json'];f.write_text(json.dumps(d,indent=2)+'\n')
