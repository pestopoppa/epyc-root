"""Prospective identities. Never reconstruct an old measurement's warrant."""
import hashlib,json,os,time,subprocess
from pathlib import Path

def artifact(path):
 p=Path(path).resolve(strict=True)
 with p.open('rb') as f:
  before=os.fstat(f.fileno()); digest=hashlib.file_digest(f,'sha256').hexdigest();after=os.fstat(f.fileno())
 if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('artifact changed during hashing')
 return dict(path=str(p),sha256=digest,size=after.st_size,dev=after.st_dev,ino=after.st_ino)

def source_closure(root):
 root=Path(root)
 expected=json.loads((root/'SOURCE.json').read_text())
 actual={name:artifact(root/name) for name in expected}
 if any(actual[name]['sha256']!=sha for name,sha in expected.items()):raise ValueError('source closure changed since readiness')
 return actual

def grant_capture():
 ident=os.environ['FILLER_ID']
 if '/' in ident or ident in ('.','..'):raise ValueError('unsafe grant identifier')
 p=Path(os.environ.get('FILLER_GRANTS_DIR','/mnt/raid0/llm/tmp/compute-flags/grants'))/(ident+'.grant')
 raw=p.read_text()
 if len(raw)>65536:raise ValueError('grant too large')
 return dict(identity=artifact(p),raw=raw,environment={k:os.environ[k] for k in ('FILLER_ID','FILLER_END','FILLER_DEADLINE','FILLER_CPUS','FILLER_PORTS')},captured_at=time.time(),allowed_cpus=sorted(os.sched_getaffinity(0)))

def mapped_closure(pid):
 paths=set()
 for line in Path('/proc',str(pid),'maps').read_text().splitlines():
  parts=line.split(maxsplit=5)
  if len(parts)==6 and parts[5].startswith('/') and '.so' in parts[5]:paths.add(parts[5])
 return [artifact(p) for p in sorted(paths)]


def verify_root_code():
 pin=json.loads(Path(__file__).with_name('root-code-pin.json').read_text())
 root=Path(pin['path'])
 head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
 if head!=pin['head']:raise ValueError('root-code HEAD differs')
 if subprocess.run(['git','-C',str(root),'symbolic-ref','-q','HEAD'],capture_output=True).returncode!=1:raise ValueError('root-code must remain detached')
 if subprocess.check_output(['git','-C',str(root),'status','--porcelain','--untracked-files=no'],text=True).strip():raise ValueError('root-code tracked state dirty')
 for rel,sha in pin['files'].items():
  if artifact(root/rel)['sha256']!=sha:raise ValueError('root-code imported source differs: '+rel)
 return pin
