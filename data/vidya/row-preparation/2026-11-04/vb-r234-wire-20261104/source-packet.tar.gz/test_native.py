import copy,json,tempfile,unittest
from pathlib import Path
from test_summarize import rows
from reader import native,write_native,read
from summarize import PROBE_SHA,HIP,HIP_SHA
from native_capture import source_closure,verify_root_code

def captured():
 x=rows()
 identity={'schema':'epyc.r234.native_identity.v1','root_code':verify_root_code(),'source_closure':source_closure(Path(__file__).parent),'grant':{'raw':'fixture-only','captured_at':1793750399.,'environment':{'FILLER_DEADLINE':'1793759999'}},'model':{'path':'fixture.gguf'}}
 for r in x:
  start=r['started_monotonic_s'];rate=r['client_stream_events_s'];span=2/rate
  r.update(started_at=1793750400.,native_identity=copy.deepcopy(identity),disposition='complete',prompt='fixture prompt',response_id_attribution='UNKNOWN',mapped_closure=[dict(path=HIP,sha256=HIP_SHA)])
  a=r['acceptance'];a.update(slot=0,task=1,raw=f"slot print_timing: id 0 | task 1 | draft acceptance = {a['ratio']} ({a['accepted']} accepted / {a['generated']} generated)")
  r['residency']['sample_monotonic_s']=[start+.1,start+.2]
  r['stream_capture']={'completed':True,'request':{'messages':[{'role':'user','content':'fixture prompt'}]},'events':[{'elapsed_s':t,'raw':'data: '+json.dumps({'choices':[{'delta':{'content':'x'}}]})} for t in (0,span)]+[{'elapsed_s':span,'raw':'data: [DONE]'}]}
 return x
class NativeTests(unittest.TestCase):
 def test_positive_shared_ladder(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'results.jsonl';p.write_text(''.join(json.dumps(r)+'\n' for r in captured()));write_native(p);out=read(p)
   self.assertEqual(len(out),18);self.assertTrue(all(x['measurement']['protocol_id']=='' for x in out))
 def test_refuse_stream_window_and_attribution(self):
  for mutate in (lambda r:r.update(response_id_attribution='proven'),lambda r:r['stream_capture'].update(events=[]),lambda r:r['residency'].update(sample_monotonic_s=[-1,-1]),lambda r:r.update(mapped_closure=[])):
   x=captured();mutate(x[0])
   with self.assertRaises(ValueError):native(x)
 def test_native_tamper_refused(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'results.jsonl';p.write_text(''.join(json.dumps(r)+'\n' for r in captured()));packet=write_native(p);packet['belief_measurements'][0]['value']=99;p.with_name('native-comparisons.json').write_text(json.dumps(packet))
   with self.assertRaises(ValueError):read(p)
if __name__=='__main__':unittest.main()
