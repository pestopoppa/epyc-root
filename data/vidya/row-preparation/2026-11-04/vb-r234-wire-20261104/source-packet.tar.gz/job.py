#!/usr/bin/env python3
"""R23-4 diagnostic sweep. Requires separately verified input/binary packet."""
import hashlib, importlib.util, json, os, pathlib, socket, subprocess, sys, time, urllib.request, uuid
from observation import RequestResidency, await_acceptance_window
from native_capture import artifact, source_closure, grant_capture, mapped_closure, verify_root_code
P=pathlib.Path('/mnt/raid0/llm/tmp/vb-r234-wire-20261104')
D=json.loads((P/'design.json').read_text())
STOP=pathlib.Path(os.environ.get('FILLER_STOPFILE',str(P/'STOP')))
PORT=int(os.environ.get('FILLER_PORTS','18099').split(',')[0])
OUT=P/'results.jsonl'
PROBE=P/'probe.py'
spec=importlib.util.spec_from_file_location('r23probe', PROBE)
probe=importlib.util.module_from_spec(spec); spec.loader.exec_module(probe)
probe.URL=f'http://127.0.0.1:{PORT}/v1/chat/completions'

def record(obj, path=None):
    path = OUT if path is None else path
    with path.open('a') as f:
        f.write(json.dumps(obj,sort_keys=True)+'\n'); f.flush(); os.fsync(f.fileno())

def stop():
    return STOP.exists() or time.time() + 360 >= int(os.environ['FILLER_DEADLINE'])

def owns_listener(pid):
    try:
        rows = [line.split() for line in pathlib.Path('/proc/net/tcp').read_text().splitlines()[1:]]
        inodes = {row[9] for row in rows if len(row) >= 10 and row[3] == '0A' and row[1].upper() == f'0100007F:{PORT:04X}'}
        sockets = {os.readlink(p) for p in pathlib.Path('/proc', str(pid), 'fd').iterdir() if p.is_symlink()}
        return len(inodes) == 1 and f'socket:[{next(iter(inodes))}]' in sockets
    except (OSError, ValueError, StopIteration):
        return False

SMOKE=os.environ.get('FILLER_DRYRUN')=='1'
allowed=os.sched_getaffinity(0)
pinned=set(range(184,192))
if not SMOKE and not pinned < allowed:
    raise SystemExit('refused: baseline affinity must strictly contain 184-191')
if not (P/'approved-inputs.json').is_file():
    raise SystemExit('refused: approved-inputs.json binding independently attested binary and prepared inputs missing')
inputs=json.loads((P/'approved-inputs.json').read_text())
server=inputs['server']
def verify_inputs():
    verify_root_code()
    for item in inputs['inputs'].values():
        st=os.stat(item['path'])
        if (st.st_size,st.st_dev,st.st_ino,st.st_mtime_ns,st.st_ctime_ns)!=(item['size'],item['dev'],item['ino'],item['mtime_ns'],item['ctime_ns']):
            raise RuntimeError('input metadata changed since pre-grant verification')
    root=pathlib.Path(server).parent.parent
    for line in pathlib.Path(inputs['closure_manifest']).read_text().splitlines():
        expected, rel=line.split(None,1)
        with (root/rel.strip()).open('rb') as stream:
            actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if actual != expected: raise RuntimeError('closure digest mismatch: '+rel)
    with PROBE.open('rb') as stream:
        actual=hashlib.file_digest(stream,'sha256').hexdigest()
    if actual != inputs['probe_sha256']: raise RuntimeError('probe digest mismatch')
    if pathlib.Path(server).parent.joinpath('libggml-hip.so').resolve() != pathlib.Path(inputs['expected_hip']).resolve():
        raise RuntimeError('private HIP link mismatch')

def mapped_hip(pid):
    paths=set()
    for line in pathlib.Path('/proc',str(pid),'maps').read_text().splitlines():
        if 'libggml-hip.so' in line:
            paths.add(line.split()[-1])
    expected=str(pathlib.Path(inputs['expected_hip']).resolve())
    if paths != {expected}: raise RuntimeError('HIP mapping is missing or unexpected: '+repr(paths))
    return sorted(paths)

verify_inputs()
if '--check' in sys.argv: sys.exit(0)
with socket.socket() as sock:
    sock.bind(('127.0.0.1',PORT))
run_id=uuid.uuid4().hex
run_dir=P/('smoke-runs' if SMOKE else 'runs')/run_id
run_dir.mkdir(parents=True, exist_ok=False)
native_identity={'schema':'epyc.r234.native_identity.v1','root_code':verify_root_code(),'source_closure':source_closure(P),'grant':grant_capture(), 'executable':artifact(server),'model':inputs['inputs']['model'],'drafter':inputs['inputs']['draft']}
record(native_identity,run_dir/'identity.jsonl')
OUT=pathlib.Path(os.environ['FILLER_DRYRUN_RESULT_PATH']) if SMOKE else run_dir/'results.jsonl'
OUT.parent.mkdir(parents=True,exist_ok=True)
complete=P/('SMOKE_COMPLETE' if SMOKE else 'COMPLETE')
complete.unlink(missing_ok=True)
def cutoff(index):
    record({'schema':'epyc.r234.cutoff.v1','run_id':run_id,'arm_index':index,'disposition':'cutoff'},run_dir/'failures.jsonl')
    raise SystemExit(75)

byname={a['name']:a for a in D['arms']}
for index,name in enumerate(D['order'][:1] if SMOKE else D['order']):
    if stop(): cutoff(index)
    arm=byname[name]
    argv=[server,'-m',D['model'],'-md',D['draft'],'-c',str(arm['context']),'--host','127.0.0.1','--port',str(PORT)]+D['common_server_args']
    if not arm['kv_unified']: argv += ['--no-kv-unified']
    if name=='affinity': argv=['taskset','-c','184-191']+argv
    log=run_dir/f'server-{index}-{name}.log'
    env=dict(os.environ,LD_LIBRARY_PATH=str(pathlib.Path(server).parent)+':/opt/rocm/lib')
    with log.open('w+') as stream:
        proc=subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT,env=env)
        try:
            until=time.monotonic()+360
            while True:
                if proc.poll() is not None: raise RuntimeError('server exited before health')
                if stop(): cutoff(index)
                try:
                    with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/health',timeout=2) as response:
                        if response.status==200: break
                except Exception: pass
                if time.monotonic()>until: raise TimeoutError('server health timeout')
                time.sleep(2)
            if not owns_listener(proc.pid): raise RuntimeError('captured server does not own listener')
            if stop(): cutoff(index)
            probe.run('warmup',10 if SMOKE else 40)
            for prompt_no,prompt in enumerate(probe.PROMPTS[:1] if SMOKE else probe.PROMPTS):
                for repeat in range(1 if SMOKE else probe.RUNS):
                    if stop(): cutoff(index)
                    if not owns_listener(proc.pid): raise RuntimeError('server lost listener ownership')
                    start=log.stat().st_size
                    t=time.time()
                    started_mono=time.monotonic()
                    entry={'schema':'epyc.r23-4.request.v1','arm':name,'arm_index':index,
                           'prompt_index':prompt_no,'repeat':repeat,'started_at':t,'started_monotonic_s':started_mono,
                           'argv':argv,'server_pid':proc.pid,'input_packet':inputs,'log':str(log),'run_id':run_id,'native_identity':native_identity,'prompt':prompt,'disposition':'started'}
                    residency=RequestResidency(proc.pid)
                    try:
                        with residency:
                            speed=probe.run(prompt,40 if SMOKE else probe.MAX_TOKENS)
                        entry['ended_monotonic_s']=time.monotonic()
                        entry['stream_capture']=probe.LAST_CAPTURE
                        entry['mapped_closure']=mapped_closure(proc.pid)
                        acceptance, end = await_acceptance_window(log, start)
                        gpu=residency.result()
                        hip=mapped_hip(proc.pid)
                        if not owns_listener(proc.pid): raise RuntimeError('listener ownership lost during request')
                        entry.update(disposition='complete',response_id_attribution='UNKNOWN',client_stream_events_s=speed,acceptance=acceptance,
                                     residency=gpu,mapped_hip=hip,host_affinity=sorted(os.sched_getaffinity(proc.pid)),
                                     log_byte_window=[start,end])
                        if not gpu['resident']:
                            raise RuntimeError('own-PID GPU residency not established during request')
                        if acceptance['state'] != 'window_correlated':
                            raise RuntimeError('acceptance unavailable or ambiguous in request window')
                    except Exception as exc:
                        entry.update(disposition='failed',failure=f'{type(exc).__name__}: {exc}',residency=residency.result(),stream_capture=probe.LAST_CAPTURE)
                        record(entry,run_dir/'failures.jsonl')
                        raise
                    record(entry)

        finally:
            if proc.poll() is None:
                proc.terminate()
                try: proc.wait(timeout=60)
                except subprocess.TimeoutExpired: proc.kill(); proc.wait()

from reader import write_native
if not SMOKE: write_native(OUT)
tmp=complete.with_suffix('.tmp')
tmp.write_text(json.dumps({'run_id':run_id,'requests':1 if SMOKE else len(D['order'])*len(probe.PROMPTS)*probe.RUNS,'smoke':SMOKE})+'\n')
os.replace(tmp,complete)
