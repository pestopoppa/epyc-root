from pathlib import Path
import json
P=Path(__file__).parent
p=P/'job.py';s=p.read_text();s=s.replace("allowed=os.sched_getaffinity(0)","SMOKE=os.environ.get('FILLER_DRYRUN')=='1'\nallowed=os.sched_getaffinity(0)");s=s.replace('if not pinned < allowed:','if not SMOKE and not pinned < allowed:')
s=s.replace("run_dir=P/'runs'/run_id","run_dir=P/('smoke-runs' if SMOKE else 'runs')/run_id")
s=s.replace("OUT=run_dir/'results.jsonl'","OUT=pathlib.Path(os.environ['FILLER_DRYRUN_RESULT_PATH']) if SMOKE else run_dir/'results.jsonl'\nOUT.parent.mkdir(parents=True,exist_ok=True)")
s=s.replace("complete=P/'COMPLETE'","complete=P/('SMOKE_COMPLETE' if SMOKE else 'COMPLETE')")
s=s.replace("for index,name in enumerate(D['order']):","for index,name in enumerate(D['order'][:1] if SMOKE else D['order']):")
s=s.replace("probe.run('warmup',40)","probe.run('warmup',10 if SMOKE else 40)")
s=s.replace('enumerate(probe.PROMPTS):','enumerate(probe.PROMPTS[:1] if SMOKE else probe.PROMPTS):').replace('range(probe.RUNS):','range(1 if SMOKE else probe.RUNS):').replace('speed=probe.run(prompt)','speed=probe.run(prompt,40 if SMOKE else probe.MAX_TOKENS)')
s=s.replace('write_native(OUT)',"if not SMOKE: write_native(OUT)")
s=s.replace("'requests':len(D['order'])*len(probe.PROMPTS)*probe.RUNS","'requests':1 if SMOKE else len(D['order'])*len(probe.PROMPTS)*probe.RUNS,'smoke':SMOKE")
p.write_text(s)
p=P/'launch.sh';s=p.read_text().replace('--claim-cpus 0-23,184-191','--claim-cpus "${WS58_REGIONS:-0-23,184-191}"').replace('--complete-cmd "test -f', '--complete-cmd "test -f')
# completion predicate selects smoke marker; smoke rows cannot qualify official COMPLETE
s=s.replace('exec bash', 'MARKER=COMPLETE\nif [ "${FILLER_DRYRUN:-0}" = 1 ]; then\n  : "${FILLER_DRYRUN_RESULT_PATH:?allocator must provide distinct smoke output}"\n  MARKER=SMOKE_COMPLETE\nfi\nexec bash').replace("$D/COMPLETE'", "$D/$MARKER'")
p.write_text(s)
p=P/'spec.json';d=json.loads(p.read_text());d['handoff_task']='handoffs/active/vidya-belief-substrate-program.md:VB-AK-R23-4-SWEEP-WIRE';d['result_path']=str(P/'runs/*/results.jsonl');d['decision_rule']+=' Native post-hook comparison rederives original SSE, raw acceptance and timed residency; response-ID attribution UNKNOWN. Smoke is one baseline request only, separate allocator result and SMOKE_COMPLETE, never full-sweep evidence.';d['keep']+=['smoke-runs/**','SMOKE_COMPLETE','SHA256SUMS'];p.write_text(json.dumps(d,indent=2)+'\n')
