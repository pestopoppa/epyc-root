import unittest
from observation import RequestResidency, acceptance_window

LINE='0.49 I slot print_timing: id  0 | task 488 | draft acceptance = 0.53663 (  315 accepted /   587 generated), mean len = 4.75'
class EvidenceTest(unittest.TestCase):
    def test_unique_consistent_window(self):
        x=acceptance_window(LINE)
        self.assertEqual((x['state'],x['task'],x['accepted'],x['generated']),('window_correlated',488,315,587))
    def test_missing_ambiguous_and_bad_counts_unknown(self):
        for line in ('',LINE+'\n'+LINE,LINE.replace('315 accepted','999 accepted')):
            self.assertEqual(acceptance_window(line)['state'],'unknown')
    def test_residency_requires_two_readable_samples(self):
        p=RequestResidency(9)
        p.samples=[None,1<<30]
        self.assertFalse(p.result()['resident'])
        p.samples=[1<<30,1<<30]
        self.assertTrue(p.result()['resident'])
        p.samples=[1<<30,0]
        self.assertFalse(p.result()['resident'])
if __name__ == '__main__': unittest.main()
