"""In-window own-process GPU allocation and mapped HIP identity for R18-D."""
import hashlib
import os
import time
from pathlib import Path

FLOOR = 1 << 30
EXPECTED = Path('/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private/bin/libggml-hip.so.0.16.0')
EXPECTED_BINARY = Path('/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private/bin/llama-bench')
EXPECTED_SHA256 = 'f26a166b8ea3089d19a395ae00afa22e917df8eba71ca6ef4be5235d65ea8079'


def map_identity(maps, expected_dev, expected_inode):
    """Check every mapped HIP inode; absent, mismatched or deleted is UNKNOWN."""
    hits = []
    for line in maps.splitlines():
        parts = line.split(maxsplit=5)
        if len(parts) != 6 or 'libggml-hip' not in parts[5]:
            continue
        try:
            major, minor = (int(x, 16) for x in parts[3].split(':'))
            hits.append({'path': parts[5], 'dev': os.makedev(major, minor), 'inode': int(parts[4])})
        except (ValueError, TypeError):
            return {'status': 'unknown', 'reason': 'invalid maps entry', 'mappings': hits}
    if not hits:
        return {'status': 'unknown', 'reason': 'HIP library not mapped during observation', 'mappings': []}
    if any((p['dev'], p['inode']) != (expected_dev, expected_inode) or p['path'].endswith(' (deleted)') for p in hits):
        return {'status': 'mismatch', 'reason': 'unexpected mapped HIP inode or deleted mapping', 'mappings': hits}
    return {'status': 'matched', 'mappings': hits}


class ProcessWitness:
    def __init__(self, pid, residency, expected=EXPECTED, proc_root=Path('/proc'), expected_binary=EXPECTED_BINARY):
        self.pid = pid
        self.residency = residency
        self.proc_root = proc_root
        st = expected.stat()
        self.expected_dev, self.expected_inode = st.st_dev, st.st_ino
        self.expected_path = str(expected)
        binary_st = expected_binary.stat()
        self.binary_dev, self.binary_inode = binary_st.st_dev, binary_st.st_ino
        self.dso_cache = {}
        self.reads = 0
        self.vram = []
        self.maps = []
        self.joint_samples = []
        self.start_ticks = self._start_ticks()
        self.identity_conflict = False

    def _start_ticks(self):
        try:
            raw = (self.proc_root / str(self.pid) / 'stat').read_text()
            return int(raw[raw.rfind(')') + 2:].split()[19])
        except (OSError, ValueError, IndexError):
            return None

    def sample(self):
        timestamp = time.monotonic()
        ticks = self._start_ticks()
        if self.start_ticks is None or ticks is None or ticks != self.start_ticks:
            if ticks is not None and self.start_ticks is not None and ticks != self.start_ticks:
                self.identity_conflict = True
            self.joint_samples.append({'monotonic_s': timestamp, 'process_start_ticks': ticks, 'executable': None, 'vram_bytes': None, 'mapping': {'status': 'unknown', 'reason': 'PID identity unavailable or changed'}})
            self.reads += 1
            return
        try:
            exe_path = self.proc_root / str(self.pid) / 'exe'
            executable = os.readlink(exe_path)
            exe_st = exe_path.stat()
            binary_match = (exe_st.st_dev, exe_st.st_ino) == (self.binary_dev, self.binary_inode) and not executable.endswith(' (deleted)')
        except OSError:
            executable = None
            binary_match = False
        v = self.residency.kfd_pid_vram(self.pid)
        if v is not None:
            self.vram.append(v)
        mapping = {'status': 'unknown', 'reason': 'maps unreadable', 'mappings': []}
        try:
            text = (self.proc_root / str(self.pid) / 'maps').read_text()
            mapping = map_identity(text, self.expected_dev, self.expected_inode)
            self.maps.append(mapping)
        except OSError:
            pass
        dsos = []
        try:
            for line in text.splitlines():
                parts = line.split(maxsplit=5)
                if len(parts) != 6 or '/libggml' not in parts[5]: continue
                name = parts[5]
                key = (name, parts[3], parts[4])
                if key not in self.dso_cache:
                    target = Path(name)
                    st = target.stat()
                    major, minor = (int(v,16) for v in parts[3].split(':'))
                    with target.open('rb') as f: digest = hashlib.file_digest(f, 'sha256').hexdigest()
                    self.dso_cache[key] = {'path':name, 'sha256':digest, 'inode_match':(st.st_dev,st.st_ino)==(os.makedev(major,minor),int(parts[4]))}
                if self.dso_cache[key] not in dsos: dsos.append(self.dso_cache[key])
        except (OSError, ValueError, UnboundLocalError):
            dsos = []
        self.joint_samples.append({'mapped_dso_identities': dsos, 'monotonic_s': timestamp, 'process_start_ticks': ticks, 'executable': executable, 'binary_match': binary_match, 'vram_bytes': v, 'mapping': mapping})
        self.reads += 1

    def proof(self):
        matched = [v for v in self.maps if v['status'] == 'matched']
        bad = [v for v in self.maps if v['status'] == 'mismatch']
        joint = [x for x in self.joint_samples if x['vram_bytes'] is not None and x['vram_bytes'] >= FLOOR and x['mapping']['status'] == 'matched' and x.get('binary_match') is True]
        return {'pid': self.pid, 'process_start_ticks': self.start_ticks, 'identity_conflict': self.identity_conflict, 'samples': self.reads, 'joint_samples': self.joint_samples, 'own_vram_readings_bytes': self.vram,
                'own_vram_over_floor': sum(v >= FLOOR for v in self.vram),
                'hip_expected_path': self.expected_path, 'hip_expected_sha256': EXPECTED_SHA256,
                'hip_expected_dev': self.expected_dev, 'hip_expected_inode': self.expected_inode,
                'hip_maps_observations': self.maps,
                'verified': len(joint) >= 2 and not bad and not self.identity_conflict}
