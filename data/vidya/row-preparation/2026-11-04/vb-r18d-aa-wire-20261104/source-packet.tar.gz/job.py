#!/usr/bin/env python3
"""R18-D: run the pinned A/A driver under the engine's acquired GPU flock."""
import contextlib, hashlib, importlib.util, json, os, subprocess, sys, threading, time
from process_witness import ProcessWitness, EXPECTED, EXPECTED_SHA256
from capture import Capture
from pathlib import Path
D = Path('/mnt/raid0/llm/tmp/vb-r18d-aa-wire-20261104')
MODEL = Path('/mnt/raid0/llm/models/Qwen3.8-27B-Q8_0.gguf')
sys.path.insert(0, str(D/'research/scripts/kernel_rnd'))
from autokernel.loop import bench, claim, gates
spec = importlib.util.spec_from_file_location('campaign', D/'research/scripts/benchmark/autokernel_aa_campaign.py')
campaign = importlib.util.module_from_spec(spec); spec.loader.exec_module(campaign)
OUT = Path(os.environ.get('FILLER_DRYRUN_DIR', str(D/'out'))) / 'native' if os.environ.get('FILLER_DRYRUN') == '1' else D/'out'
OUT.mkdir(parents=True, exist_ok=True)
RESULT = Path(os.environ.get('FILLER_DRYRUN_RESULT_PATH', str(OUT/'results.jsonl')))
class SmokeComplete(Exception): pass
CAP = None
CONTEXT = {}


def stopped():
    return Path(os.environ['FILLER_STOPFILE']).exists() or time.time() >= int(os.environ['FILLER_DEADLINE'])

def emit(obj):
    with RESULT.open('a') as f:
        f.write(json.dumps(obj, sort_keys=True, allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())

@contextlib.contextmanager
def acquired_by_engine():
    def prove():
        # flock(1) acquires on the shell's inherited fd, but /proc/locks
        # attributes the lock to the already-exited flock process. Verify the
        # active ancestor's fdinfo instead: it binds the open description to
        # the device-lock inode and an exclusive FLOCK held on that fd.
        expected = claim.DEVICE_LOCK.stat()
        for pid in claim._ancestor_pids(os.getpid()):
            fd = Path(f'/proc/{pid}/fd/9')
            info = Path(f'/proc/{pid}/fdinfo/9')
            try:
                actual = fd.stat()
                content = info.read_text()
                ticks = claim._process_start_ticks(pid)
            except OSError:
                continue
            if ((actual.st_dev, actual.st_ino) == (expected.st_dev, expected.st_ino)
                    and ticks is not None
                    and any(line.startswith('lock:') and 'FLOCK' in line
                            and 'WRITE' in line for line in content.splitlines())):
                return {'pid': pid, 'start_ticks': ticks, 'inode': actual.st_ino}
        raise RuntimeError('no ancestor holds the device lock on fd 9')
    start = prove()
    
    if CAP is not None: CAP.claim({'device_id': 'mi210_0', 'owner': start})
    yield {'device_id': 'mi210_0', 'owner': start}
    end = prove()
    if (start['pid'], start['start_ticks']) != (end['pid'], end['start_ticks']):
        raise RuntimeError('engine GPU lock holder changed')

def observed_run(binary, model, *, pp, tg, ubatch=None, reps=9, timeout_s=3600,
                 sleep=time.sleep, capture=None, hardening_seed=None):
    """Same argv/receipt as bench.run_once, with live child-specific witness."""
    if capture is not None:
        raise RuntimeError('nested benchmark capture is not supported')
    seed = bench._candidate_seed() if hardening_seed is None else hardening_seed
    argv = bench.llama_bench_argv(binary, model, pp=pp, tg=tg, reps=reps,
                                  ubatch=ubatch, hardening_seed=seed)
    env = bench.residency.loader_env(binary)
    for attempt in range(bench.KILL_RETRIES + 1):
        started_utc, started_mono = time.time(), time.monotonic()
        child = None
        witness = None
        sampler = None
        stdout = stderr = None
        rc = None
        error = None
        try:
            with bench.residency.Sampler() as sampler:
                child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         text=True, env=env)
                witness = ProcessWitness(child.pid, bench.residency)
                done = threading.Event()
                def collect():
                    while not done.is_set():
                        witness.sample()
                        done.wait(0.25)
                thread = threading.Thread(target=collect, daemon=True)
                thread.start()
                try:
                    stdout, stderr = child.communicate(timeout=timeout_s)
                except subprocess.TimeoutExpired:
                    child.kill(); stdout, stderr = child.communicate()
                    raise
                finally:
                    done.set(); thread.join(timeout=5)
                rc = child.returncode
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'detail': str(exc)[:512]}
            raise
        finally:
            process_proof = witness.proof() if witness is not None else None
            sampler_proof = sampler.proof if sampler is not None else None
            proof = {**(sampler_proof or {}), 'own_process': process_proof}
            event = {'condition': CONTEXT.get('condition'), 'phase': CONTEXT.get('phase'),
                     'arm': CONTEXT.get('arm'), 'pair_index': CONTEXT.get('pair_index'),
                     'order_basis': 'pinned bench.compare loop: anchor then candidate, warmups first',
                     'argv': argv, 'attempt': attempt, 'pid': child.pid if child else None,
                     'started_utc_epoch_s': started_utc, 'ended_utc_epoch_s': time.time(),
                     'started_monotonic_s': started_mono, 'ended_monotonic_s': time.monotonic(),
                     'returncode': rc if rc is not None else (child.returncode if child else None),
                     'stdout': stdout, 'stderr': stderr, 'error': error, 'residency': proof}
            if CAP is not None:
                CAP.invocation(event)
            with (OUT/'invocations.jsonl').open('a') as output:
                output.write(json.dumps(event, sort_keys=True, allow_nan=False)+'\n')
                output.flush(); os.fsync(output.fileno())
        if rc in bench.EXTERNAL_KILL_CODES and attempt < bench.KILL_RETRIES:
            sleep(bench.KILL_BACKOFF_S[min(attempt, len(bench.KILL_BACKOFF_S)-1)])
            continue
        if rc:
            raise bench.BenchFailed(f'llama-bench rc={rc}: {stderr[-400:]}')
        if not process_proof['verified']:
            raise bench.BenchFailed('own-PID residency or mapped HIP identity not proved')
        row = bench.hardened_row(stdout, pp=pp, tg=tg, reps=reps)
        return float(row.avg_ts), proof
    raise bench.BenchFailed('external kill retries exhausted')

original_run = observed_run
count = 0
pair = []
def run_with_units(*args, **kwargs):
    global count, pair
    if stopped(): raise SystemExit(75)
    n = CONTEXT.get('invocation_index')
    if n is not None:
        warmup_invocations = CONTEXT['warmup_pairs'] * 2
        CONTEXT['phase'] = 'warmup' if n < warmup_invocations else 'scored'
        CONTEXT['pair_index'] = (n // 2 + 1) if n < warmup_invocations else ((n - warmup_invocations) // 2 + 1)
        CONTEXT['arm'] = 'anchor' if n % 2 == 0 else 'candidate'
        CONTEXT['invocation_index'] = n + 1
    value, proof = original_run(*args, **kwargs)
    count += 1
    # SETTLED's first two invocations are discarded warmups; the next two form
    # an actual measured pair. Later values are retained by campaign itself.
    if count in (3, 4):
        if not proof.get('resident'): raise RuntimeError('measured invocation was not sampled GPU resident')
        pair.append({'value': value, 'residency': proof})
        if len(pair) == 2:
            emit({'type':'measured_pair','condition':'SETTLED','surface':'pp512','pair':1,'arms':pair})
            if os.environ.get('FILLER_DRYRUN') == '1': raise SmokeComplete('one real native SETTLED pair; no floor')
    return value, proof

original_condition = campaign.one_condition
def captured_condition(name, *args, **kwargs):
    CONTEXT.clear()
    CONTEXT.update(condition=name, warmup_pairs=kwargs['warmup'], invocation_index=0)
    try:
        result = original_condition(name, *args, **kwargs)
        if CAP is not None:
            CAP.condition({'condition': name, 'native_result': result})
        return result
    finally:
        CONTEXT.clear()

orig_compiles = gates.compiles
def isolated_compile(source_root, build_dir, **kwargs):
    if stopped(): raise SystemExit(75)
    kwargs['cpu_list'] = os.environ['FILLER_CPUS']
    kwargs['jobs'] = max(1, int(os.environ['FILLER_THREADS']))
    verdict = orig_compiles(D/'source', D/'build-loadgen', **kwargs)
    if not verdict.passed: raise RuntimeError('load build failed: '+str(verdict))
    return verdict

def _run():
    if '--check' in sys.argv:
        with EXPECTED.open('rb') as f:
            if hashlib.file_digest(f, 'sha256').hexdigest() != EXPECTED_SHA256:
                raise SystemExit('private HIP library digest mismatch')
        for p in (MODEL, D/'source/CMakeLists.txt', Path('/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private/bin/llama-bench')):
            if not p.is_file(): raise SystemExit('missing '+str(p))
        head = subprocess.check_output(['git','-C',str(D/'source'),'rev-parse','HEAD'],text=True).strip()
        if head != 'ffc1bac82eeca6f9099e1ccd9ba49703c460a115': raise SystemExit('load source mismatch')
        if subprocess.check_output(['git','-C',str(D/'source'),'status','--porcelain'],text=True).strip(): raise SystemExit('load source dirty')
        identity = json.loads((D/'input-identity.json').read_text())
        stat = MODEL.stat()
        actual = {'dev': stat.st_dev, 'ino': stat.st_ino, 'size': stat.st_size,
                  'mtime_ns': stat.st_mtime_ns, 'ctime_ns': stat.st_ctime_ns}
        if identity['path'] != str(MODEL) or identity['stat'] != actual:
            raise SystemExit('model metadata differs from pre-grant digest observation')
        root = Path('/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private')
        for line in (root/'SHA256SUMS').read_text().splitlines():
            digest, relative = line.split(None, 1)
            with (root/relative.strip()).open('rb') as f:
                if hashlib.file_digest(f, 'sha256').hexdigest() != digest:
                    raise SystemExit('private v10 closure mismatch: '+relative)
        if (root/'bin/libggml-hip.so').resolve() != EXPECTED.resolve():
            raise SystemExit('private HIP unversioned link mismatch')
        return 0
    RESULT.write_text('')
    (OUT/'invocations.jsonl').write_text('')
    bench.CPU_LIST = os.environ['FILLER_CPUS']
    bench.run_once = run_with_units
    claim.hold = acquired_by_engine
    gates.compiles = isolated_compile
    campaign.one_condition = captured_condition
    if os.environ.get('FILLER_DRYRUN') == '1':
        # Diagnostic smoke only: real native pp512 process pair. It is outside
        # SETTLED/PREHEATED/POST_BUILD, has no floor, and cannot enter calibration.
        # Full-run conditioning and all 20-pair sample protocol remain unchanged.
        smoke_arms = []
        with acquired_by_engine():
            for arm in ('anchor', 'candidate'):
                CONTEXT.update(condition='SMOKE_UNSETTLED', phase='diagnostic', arm=arm, pair_index=1)
                value, proof = observed_run(Path('/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private/bin/llama-bench'), MODEL, pp=512, tg=0, reps=9)
                smoke_arms.append({'arm':arm, 'value':value, 'residency':proof})
                emit({'type':'readiness_invocation','condition':'SMOKE_UNSETTLED','surface':'pp512','arm':arm,'value':value,'unit':'t/s','floor_pct':None})
        emit({'type':'readiness_pair','condition':'SMOKE_UNSETTLED','surface':'pp512','arms':smoke_arms,'floor_pct':None})
        raise SmokeComplete('real diagnostic pp512 pair; no settled samples or floor')
    rc = campaign.main(['--anchor-build','/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private', '--worktree', str(D/'source'), '--model', str(MODEL), '--surface','pp512', '--pairs','20', '--out', str(OUT)])
    if rc: return rc
    report=json.loads((OUT/'aa-campaign.json').read_text())
    if len(report.get('conditions',[])) != 3 or not report.get('bootstrap_floor_pct'): raise RuntimeError('incomplete campaign')
    emit({'type':'complete', 'campaign': report, 'research_commit':'99301fa149af86a6f9743d2b0405c9234ba39586','load_source_commit':'ffc1bac82eeca6f9099e1ccd9ba49703c460a115','anchor_commit':'ffc1bac82eeca6f9099e1ccd9ba49703c460a115','bench_sha256':'9b8109dd02ff71fd03d6f63a810165284ebf13fc840bb1903b7387c259d347a5','model_sha256':json.loads((D/'input-identity.json').read_text())['sha256'],'model_file':MODEL.name,'quant':'Q8_0'})
    (OUT/'COMPLETE').write_text('complete\n')
    return 0
def identity_context():
    # Content hashes were prepared before publication; native start validates inode/stat.
    prepared = json.loads((D/'producer-identities.json').read_text())
    for row in prepared:
        st = Path(row['path']).stat()
        actual = {'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
        if actual != row['stat']: raise RuntimeError('producer bytes changed since preparation: '+row['path'])
    model_identity = json.loads((D/'input-identity.json').read_text())
    st = MODEL.stat()
    if model_identity['stat'] != {'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}:
        raise RuntimeError('model changed since preparation')
    model_identity = {'path':str(MODEL), 'sha256':model_identity['sha256'], 'dev':st.st_dev, 'ino':st.st_ino}
    return {'files': [model_identity] + prepared,
            'source': json.loads((D/'source-origin.json').read_text()),
            'grant': {k: os.environ.get(k) for k in ('FILLER_ID', 'FILLER_END', 'FILLER_DEADLINE', 'FILLER_CPUS', 'FILLER_THREADS')}}

def main():
    global CAP
    if '--check' in sys.argv:
        return _run()
    CAP = Capture(OUT, original_context={
        'row_id': (os.environ.get('FILLER_ID', '') + ':smoke') if os.environ.get('FILLER_DRYRUN') == '1' else os.environ.get('FILLER_ID'), 'run_mode': 'smoke_unsettled' if os.environ.get('FILLER_DRYRUN') == '1' else 'official', 'grant_end_epoch_s': os.environ.get('FILLER_END'),
        'cpu_list': os.environ.get('FILLER_CPUS'), 'model': str(MODEL),
        'model_pregrant_identity': json.loads((D/'input-identity.json').read_text()),
        'executable': '/mnt/raid0/llm/tmp/autokernel-rebuild/r18d-v10-private/bin/llama-bench',
        'prospective_capture': 'VB-AK-R18D-AA-WIRE/v1',
        'identities': identity_context(),
        'quant': 'Q8_0', 'backend': 'gpu', 'native_kernel_backend': 'llama_gpu', 'workload': {'pp': 512, 'tg': 0},
        'expected_anchor_commit': 'ffc1bac82eeca6f9099e1ccd9ba49703c460a115',
        'expected_hip_sha256': EXPECTED_SHA256, 'surface': 'pp512',
        'pairs_per_condition': 20, 'protocol_id': None, 'attestation': None,
        'conditions': ['SETTLED', 'PREHEATED', 'POST_BUILD']})
    try:
        rc = _run()
        CAP.finish('complete' if rc == 0 else 'failed', native={'returncode': rc, 'bootstrap_floor_pct': json.loads((OUT/'aa-campaign.json').read_text())['bootstrap_floor_pct'] if rc == 0 else None})
        return rc
    except SmokeComplete as exc:
        CAP.finish('partial', native={'reason': str(exc), 'bootstrap_floor_pct': None})
        return 0
    except SystemExit as exc:
        CAP.finish('partial' if exc.code == 75 else 'failed', native={'exit_code': exc.code})
        raise
    except BaseException as exc:
        CAP.finish('failed', native={'type': type(exc).__name__, 'detail': str(exc)[:512]})
        raise
    finally:
        CAP.close_unfinished()

if __name__ == '__main__': raise SystemExit(main())
