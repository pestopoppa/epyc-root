import os
from pathlib import Path
import tempfile
import unittest
from process_witness import map_identity, ProcessWitness, FLOOR

class FakeResidency:
    def __init__(self, values): self.values = iter(values)
    def kfd_pid_vram(self, pid): return next(self.values)

class ProcessWitnessTests(unittest.TestCase):
    def test_identity_matching_missing_mismatch_deleted(self):
        dev = os.makedev(8, 1)
        line = '1000-2000 r-xp 0 08:01 42 /tmp/libggml-hip.so.0\n'
        self.assertEqual(map_identity(line, dev, 42)['status'], 'matched')
        self.assertEqual(map_identity('', dev, 42)['status'], 'unknown')
        self.assertEqual(map_identity(line, dev, 43)['status'], 'mismatch')
        self.assertEqual(map_identity(line.strip()+' (deleted)\n', dev, 42)['status'], 'mismatch')
        self.assertEqual(map_identity(line+'2000-3000 r-xp 0 08:01 43 /tmp/libggml-hip.so\n', dev, 42)['status'], 'mismatch')

    def test_requires_two_own_vram_and_mapped_expected_inode(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); expected=root/'libggml-hip.so.0.16.0'; expected.touch()
            pid=123; proc=root/str(pid); proc.mkdir()
            binary=root/'bench'; binary.touch(); (proc/'exe').symlink_to(binary)
            (proc/'stat').write_text('123 (bench) ' + ' '.join(['S'] + ['0']*18 + ['42']))
            st=expected.stat(); dev=f'{os.major(st.st_dev):x}:{os.minor(st.st_dev):x}'
            (proc/'maps').write_text(f'1000-2000 r-xp 0 {dev} {st.st_ino} {expected}\n')
            w=ProcessWitness(pid, FakeResidency([FLOOR, FLOOR, None]), expected, root, binary)
            w.sample(); self.assertFalse(w.proof()['verified'])
            w.sample(); self.assertTrue(w.proof()['verified'])
            (proc/'maps').write_text(f'1000-2000 r-xp 0 {dev} {st.st_ino+1} /tmp/libggml-hip.so\n')
            w.sample(); self.assertFalse(w.proof()['verified'])

    def test_executable_and_pid_identity_required(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); hip = root / 'hip'; hip.touch()
            good = root / 'bench'; good.touch(); other = root / 'other'; other.touch()
            proc = root / '123'; proc.mkdir()
            def stat(ticks): (proc / 'stat').write_text('123 (bench) ' + ' '.join(['S'] + ['0'] * 18 + [str(ticks)]))
            stat(42); (proc / 'exe').symlink_to(other)
            st = hip.stat(); dev = f'{os.major(st.st_dev):x}:{os.minor(st.st_dev):x}'
            (proc / 'maps').write_text(f'1000-2000 r-xp 0 {dev} {st.st_ino} /tmp/libggml-hip.so\n')
            w = ProcessWitness(123, FakeResidency([FLOOR]*5), hip, root, good)
            w.sample(); w.sample(); self.assertFalse(w.proof()['verified'])
            (proc / 'exe').unlink(); (proc / 'exe').symlink_to(good)
            w.sample(); w.sample(); self.assertTrue(w.proof()['verified'])
            stat(43); w.sample(); self.assertFalse(w.proof()['verified'])

    def test_unreadable_maps_never_verified(self):
        with tempfile.TemporaryDirectory() as temp:
            expected=Path(temp)/'hip'; expected.touch()
            w=ProcessWitness(123, FakeResidency([FLOOR, FLOOR]), expected, Path(temp), expected)
            w.sample(); w.sample()
            self.assertFalse(w.proof()['verified'])

if __name__ == '__main__': unittest.main()
