import hashlib
import json
import tempfile
import unittest
from capture import Capture, _canonical

class CaptureTest(unittest.TestCase):
    def test_chain_and_unknown_remain_native(self):
        with tempfile.TemporaryDirectory() as d:
            c = Capture(d, original_context={'model_sha256': None, 'protocol_id': ''})
            c.invocation({'condition': 'SETTLED', 'arm': 'a', 'gpu_mapping': None})
            c.finish('partial', native={'reason': 'stop', 'floor': None})
            rows = [json.loads(x) for x in c.path.read_text().splitlines()]
            self.assertEqual([r['kind'] for r in rows], ['run_start','invocation','run_end'])
            self.assertIsNone(rows[0]['native']['model_sha256'])
            self.assertIsNone(rows[1]['native']['gpu_mapping'])
            self.assertEqual(rows[2]['native']['disposition'], 'partial')
            previous = None
            for i, row in enumerate(rows):
                self.assertEqual(row['seq'], i)
                self.assertEqual(row['previous_sha256'], previous)
                previous = row.pop('content_sha256')
                self.assertEqual(previous, hashlib.sha256(_canonical(row)).hexdigest())
            with self.assertRaises(ValueError): c.invocation({})
    def test_no_fabricated_end_on_interruption(self):
        with tempfile.TemporaryDirectory() as d:
            c = Capture(d, original_context={})
            c.close_unfinished()
            self.assertEqual(len(c.path.read_text().splitlines()), 1)
    def test_bad_disposition_or_nonfinite_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            c = Capture(d, original_context={})
            with self.assertRaises(ValueError): c.finish('success', native={})
            with self.assertRaises(ValueError): c.invocation({'value': float('nan')})
            c.close_unfinished()

if __name__ == '__main__': unittest.main()
