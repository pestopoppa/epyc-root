"""Draft prospective R18-D native event capture; this is NOT an adapter or grader.

Only events passed by the running producer are recorded. No reader reconstructs
warrant from old results. The caller supplies observed provenance and preserves
unknowns as JSON null. A downstream strict projector and planning canary are open.
"""
import datetime as dt
import hashlib
import json
import os
import time
import uuid
from pathlib import Path

SCHEMA = 'epyc.autokernel.r18d.native_capture.v1'
KINDS = frozenset({'run_start', 'claim', 'invocation', 'condition', 'run_end'})


def _canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


class Capture:
    """Create a new exclusive stream; never reopen or retrofit an existing run."""
    def __init__(self, output_dir, *, original_context):
        if not isinstance(original_context, dict):
            raise ValueError('original context must be a mapping; missing fields must remain null')
        self.run_id = uuid.uuid4().hex
        self.path = Path(output_dir) / ('r18d-capture-' + self.run_id + '.jsonl')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self.path.open('xb')
        self._seq = 0
        self._previous = None
        self._closed = False
        self._append('run_start', original_context)

    def _append(self, kind, native):
        if self._closed:
            raise ValueError('capture closed')
        if kind not in KINDS or not isinstance(native, dict):
            raise ValueError('unsupported kind or native payload')
        body = {'schema': SCHEMA, 'run_id': self.run_id, 'seq': self._seq,
                'kind': kind, 'recorded_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                'recorded_monotonic_s': time.monotonic(), 'previous_sha256': self._previous,
                'native': native}
        body['content_sha256'] = hashlib.sha256(_canonical(body)).hexdigest()
        self._file.write(_canonical(body) + b'\n')
        self._file.flush()
        os.fsync(self._file.fileno())
        self._previous = body['content_sha256']
        self._seq += 1

    def claim(self, native):
        self._append('claim', native)

    def invocation(self, native):
        self._append('invocation', native)

    def condition(self, native):
        self._append('condition', native)

    def finish(self, disposition, *, native):
        if disposition not in {'complete', 'partial', 'failed', 'refused', 'unknown'}:
            raise ValueError('invalid native disposition')
        self._append('run_end', {'disposition': disposition, 'outcome': native})
        self._file.close()
        self._closed = True

    def close_unfinished(self):
        """Abrupt/incomplete stream has no invented end state."""
        if not self._closed:
            self._file.close()
            self._closed = True
