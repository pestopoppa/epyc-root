"""Model-free smoke routing: real callable used, no official condition/floor."""
import contextlib,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import job
class SmokeTest(unittest.TestCase):
    def test_smoke_keeps_native_argv_and_excludes_official_campaign(self):
        calls=[]
        def invocation(binary,model,**kwargs):
            calls.append((str(model),kwargs,dict(job.CONTEXT)))
            return 123.0, {'own_process':{'verified':True}}
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'FILLER_DRYRUN':'1','FILLER_CPUS':'1','FILLER_THREADS':'1'}),patch.object(job,'OUT',Path(d)),patch.object(job,'RESULT',Path(d)/'result.jsonl'),patch.object(job,'observed_run',invocation),patch.object(job,'acquired_by_engine',return_value=contextlib.nullcontext()),patch.object(job.campaign,'main') as official:
            with self.assertRaises(job.SmokeComplete):job._run()
            official.assert_not_called()
            rows=[json.loads(x) for x in (Path(d)/'result.jsonl').read_text().splitlines()]
            self.assertEqual([r['type'] for r in rows],['readiness_invocation','readiness_invocation','readiness_pair'])
            self.assertTrue(all(r['condition']=='SMOKE_UNSETTLED' and r['floor_pct'] is None for r in rows))
        self.assertEqual(len(calls),2)
        self.assertTrue(all(x[0].endswith('Qwen3.8-27B-Q8_0.gguf') and x[1]=={'pp':512,'tg':0,'reps':9} for x in calls))
        self.assertEqual([x[2]['arm'] for x in calls],['anchor','candidate'])
if __name__=='__main__':unittest.main()
