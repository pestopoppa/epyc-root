"""Model-free checks of the producer's pair joins and incomplete-run capture."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import job


class Recorder:
    def __init__(self, *args, **kwargs):
        self.finished = None
        self.closed = False
        instances.append(self)
    def finish(self, disposition, *, native):
        self.finished = (disposition, native)
    def close_unfinished(self):
        self.closed = True

instances = []


class CaptureContextTest(unittest.TestCase):
    def setUp(self):
        job.CONTEXT.clear()
        job.count = 0
        job.pair = []
        instances.clear()

    def test_warmups_and_scored_pairs_keep_actual_order(self):
        observed = []
        def sample(*args, **kwargs):
            observed.append(dict(job.CONTEXT))
            return 1.0, {'resident': True}
        with tempfile.TemporaryDirectory() as tmp, patch.object(job, 'original_run', sample), \
             patch.object(job, 'stopped', return_value=False), patch.object(job, 'RESULT', Path(tmp) / 'results.jsonl'):
            job.CONTEXT.update(condition='SETTLED', warmup_pairs=1, invocation_index=0)
            for _ in range(6):
                job.run_with_units()
        self.assertEqual([(x['phase'], x['pair_index'], x['arm']) for x in observed], [
            ('warmup', 1, 'anchor'), ('warmup', 1, 'candidate'),
            ('scored', 1, 'anchor'), ('scored', 1, 'candidate'),
            ('scored', 2, 'anchor'), ('scored', 2, 'candidate')])

    def test_stop_produces_partial_not_complete_event(self):
        with patch.object(job, 'Capture', Recorder), patch.object(job, '_run', side_effect=SystemExit(75)), \
             patch.object(job.sys, 'argv', ['job.py']):
            with self.assertRaises(SystemExit):
                job.main()
        self.assertEqual(instances[0].finished, ('partial', {'exit_code': 75}))
        self.assertTrue(instances[0].closed)

    def test_unexpected_failure_records_failed_not_complete(self):
        with patch.object(job, 'Capture', Recorder), patch.object(job, '_run', side_effect=RuntimeError('failure')), \
             patch.object(job.sys, 'argv', ['job.py']):
            with self.assertRaises(RuntimeError):
                job.main()
        self.assertEqual(instances[0].finished[0], 'failed')
        self.assertEqual(instances[0].finished[1]['type'], 'RuntimeError')
        self.assertTrue(instances[0].closed)


if __name__ == '__main__':
    unittest.main()
