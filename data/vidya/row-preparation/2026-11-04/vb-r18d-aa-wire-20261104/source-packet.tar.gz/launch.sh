#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/vb-r18d-aa-wire-20261104
ENGINE=/mnt/raid0/llm/tmp/vb-r18d-aa-wire-20261104/filler_run15.sh
exec bash "$ENGINE" --id vidya-r18d-aa-wire-20261104 --class gpu --role bench --gpu-quiet shared --min-window 3600 --stop "$D/STOP" --complete-cmd "test -f '$D/out/COMPLETE'" --workdir "$D" --cmd "python3 '$D/job.py'" --precond-cmd "python3 '$D/job.py' --check"

# Device-lock witness uses ancestor fdinfo; revision 20261102b.
