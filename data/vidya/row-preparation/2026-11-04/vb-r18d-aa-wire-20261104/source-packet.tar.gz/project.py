"""Prospective R18-D projection candidate. Shared measurement carrier/grade only.

No historical inputs: the write-time marker, stream chain, claims and exact event
joins are mandatory. A complete campaign can still be refused as a floor.
"""
import hashlib,json,sys
from pathlib import Path
from statistics import median
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'research/scripts/kernel_rnd'))
from autokernel.loop import bench
sys.path.insert(0,'/mnt/raid0/llm/worktrees/mains/h-vidya-belief-substrate/scripts/vidya')
from claim_tuple import ClaimTuple,ProjectionError,grade
from capture import SCHEMA,_canonical

def require(ok,reason):
    if not ok: raise ProjectionError(reason)

def project(path):
    path=Path(path); data=path.read_bytes(); rows=[json.loads(x) for x in data.splitlines()]
    require(len(rows)>2,'unfinished stream')
    previous=None
    for i,row in enumerate(rows):
        body=dict(row); digest=body.pop('content_sha256')
        require(body['schema']==SCHEMA and body['seq']==i and body['previous_sha256']==previous,'stream schema/order/chain mismatch')
        require(body['run_id']==rows[0]['run_id'] and digest==hashlib.sha256(_canonical(body)).hexdigest(),'stream content mismatch')
        previous=digest
    require(rows[0]['kind']=='run_start' and rows[-1]['kind']=='run_end','missing start/end')
    context=rows[0]['native']; end=rows[-1]['native']
    require(context.get('prospective_capture')=='VB-AK-R18D-AA-WIRE/v1','pre-hook source refused')
    require(end['disposition']=='complete','partial/failed/refused source is not a floor')
    ids=context['identities']; files=ids['files']
    require(all(x.get('sha256') and x.get('ino') for x in files),'missing content identities')
    model=[x for x in files if x['path']==context['model']]
    require(len(model)==1 and model[0]['sha256']==context['model_pregrant_identity']['sha256'],'model binding mismatch')
    require(context['workload']=={'pp':512,'tg':0} and context['surface']=='pp512','workload mismatch')
    require(all(ids['grant'].get(k) for k in ('FILLER_ID','FILLER_END','FILLER_CPUS','FILLER_THREADS')),'missing acquired grant context')
    claims=[r['native'] for r in rows if r['kind']=='claim']
    require(len(claims)==1 and claims[0]['owner'].get('start_ticks'),'missing actual claim witness')
    conditions=[r['native'] for r in rows if r['kind']=='condition']
    require([x['condition'] for x in conditions]==['SETTLED','PREHEATED','POST_BUILD'],'conditions missing/reordered')
    invocations=[r['native'] for r in rows if r['kind']=='invocation']
    values={}; expected_total=0
    for condition,warmup in [('SETTLED',1),('PREHEATED',6),('POST_BUILD',1)]:
        events=[x for x in invocations if x['condition']==condition];expected_total+=(20+warmup)*2
        require(len(events)==(20+warmup)*2,'missing/retried units cannot silently form a floor')
        arms={'anchor':[],'candidate':[]}
        for i,event in enumerate(events):
            phase='warmup' if i<warmup*2 else 'scored'; pair=i//2+1 if phase=='warmup' else (i-warmup*2)//2+1; arm='anchor' if i%2==0 else 'candidate'
            require((event['phase'],event['pair_index'],event['arm'])==(phase,pair,arm),'unit order differs')
            require(event['returncode']==0 and event['error'] is None,'failed invocation')
            require(event['started_monotonic_s']<event['ended_monotonic_s'],'bad invocation window')
            proof=event['residency'];own=proof['own_process']
            require(own['verified'] and own['pid']==event['pid'] and proof['clock_stable'] is True,'missing own-PID HIP residency or unstable clocks')
            joint=[x for x in own['joint_samples'] if x.get('binary_match') and x.get('mapping',{}).get('status')=='matched' and (x.get('vram_bytes') or 0)>=1<<30 and event['started_monotonic_s']<=x['monotonic_s']<=event['ended_monotonic_s']]
            require(len(joint)>=2,'insufficient in-window observations')
            require(all(x.get('mapped_dso_identities') for x in joint),'mapped DSO digests missing')
            for x in joint:
                require(all(d['inode_match'] and any(f['path']==d['path'] and f['sha256']==d['sha256'] for f in files) for d in x['mapped_dso_identities']),'mapped DSO identity mismatch')
            argv=event['argv'];require([x['path'] for x in files if x['path'].endswith('/llama-bench')][0] in argv,'executable binding mismatch')
            value=float(bench.hardened_row(event['stdout'],pp=512,tg=0,reps=9).avg_ts)
            if phase=='scored': arms[arm].append(value)
        native=next(x['native_result'] for x in conditions if x['condition']==condition)
        require(native['anchor_samples']==arms['anchor'] and native['candidate_samples']==arms['candidate'],'native samples do not rederive from invocations')
        values[condition]=arms
    require(len(invocations)==expected_total,'unknown condition units')
    settled=values['SETTLED']; floors=bench.bootstrap_floor(settled['anchor'],settled['candidate'])
    # The producer records the floor; the reader checks rather than invents it.
    declared=end['outcome']['bootstrap_floor_pct']
    require(declared=={str(k):v for k,v in floors.items()},'settled floor mismatch')
    digest=hashlib.sha256(data).hexdigest()
    return ClaimTuple(measurement_id='r18d-aa:'+rows[0]['run_id'],metric='pp512.aa_noise_floor_pct',value=floors[20],unit='percent',date=rows[-1]['recorded_at_utc'],category='BASELINE',claim=f"SETTLED pp512 process-pair A/A bootstrap floor at 20 pairs: {floors[20]}%; calibration observation",metric_direction='lower_better',protocol_id=context.get('protocol_id') or '',reps=20,reps_basis='scored:20 ordered process pairs; warmups excluded',attestation_path=str(path),attestation_locator=str(path),attestation_sha256=digest,attestation_present=True,attestation_verified=True,source_kind='autokernel-r18d-aa-measurement',applicability={'model_file':Path(context['model']).name,'model_sha256':model[0]['sha256'],'quant':context['quant'],'backend':context['backend'],'surface':'pp512','scope_basis':'native'},observation={'outcome':'floor','n_pairs':20,'noise_floor_rel':floors[20]/100,'retrofit':False},extra={'conditions':values,'bootstrap_floor_pct':declared,'identities':ids})

if __name__=='__main__':
    tuple_=project(sys.argv[1]); print(json.dumps({'measurement_id':tuple_.measurement_id,'grade':grade(tuple_),'value':tuple_.value}))
