"""Synthetic producer-boundary controls; never a real GPU or planner canary."""
import copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from capture import Capture
import project

class ProjectTests(unittest.TestCase):
    def fixture(self,root,*,unstable=False,marker=True,partial=False,missing_dso=False):
        context={'prospective_capture':'VB-AK-R18D-AA-WIRE/v1' if marker else None,'identities':{'files':[{'path':'/model','sha256':'a'*64,'ino':1},{'path':'/bin/llama-bench','sha256':'b'*64,'ino':2},{'path':'/bin/libggml-hip.so','sha256':'c'*64,'ino':3}],'grant':{'FILLER_ID':'synthetic','FILLER_END':'1','FILLER_CPUS':'1','FILLER_THREADS':'1'}},'model':'/model','model_pregrant_identity':{'sha256':'a'*64},'workload':{'pp':512,'tg':0},'surface':'pp512','quant':'Q4_K_M','backend':'gpu'}
        c=Capture(root,original_context=context);c.claim({'owner':{'start_ticks':1}})
        for condition,warmup in [('SETTLED',1),('PREHEATED',6),('POST_BUILD',1)]:
            for i in range((20+warmup)*2):
                phase='warmup' if i<warmup*2 else 'scored'
                sample={'binary_match':True,'mapping':{'status':'matched'},'vram_bytes':2<<30,'monotonic_s':1.5,'mapped_dso_identities':[] if missing_dso else [{'path':'/bin/libggml-hip.so','sha256':'c'*64,'inode_match':True}]}
                c.invocation({'condition':condition,'phase':phase,'pair_index':i//2+1 if phase=='warmup' else (i-warmup*2)//2+1,'arm':'anchor' if i%2==0 else 'candidate','returncode':0,'error':None,'started_monotonic_s':1,'ended_monotonic_s':2,'pid':1,'residency':{'clock_stable':not unstable,'own_process':{'verified':True,'pid':1,'joint_samples':[sample,sample]}},'argv':['taskset','-c','1','numactl','--interleave=all','/bin/llama-bench'],'stdout':'synthetic'})
            c.condition({'condition':condition,'native_result':{'anchor_samples':[100.]*20,'candidate_samples':[100.]*20}})
        c.finish('partial' if partial else 'complete',native={'bootstrap_floor_pct':{str(k):0. for k in (1,3,5,9,20)}})
        return c.path
    def test_positive_shared_ladder(self):
        with tempfile.TemporaryDirectory() as d, patch.object(project.bench,'hardened_row',return_value=SimpleNamespace(avg_ts=100)):
            t=project.project(self.fixture(d)); self.assertEqual(t.observation['n_pairs'],20);self.assertEqual(t.source_class,'measurement'); self.assertEqual(t.applicability['backend'],'gpu'); self.assertTrue(project.grade(t))
    def test_refusals(self):
        for mutation in ({'unstable':True},{'marker':False},{'partial':True},{'missing_dso':True}):
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as d,patch.object(project.bench,'hardened_row',return_value=SimpleNamespace(avg_ts=100)):
                with self.assertRaises(project.ProjectionError):project.project(self.fixture(d,**mutation))
    def test_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.fixture(d);p.write_text(p.read_text().replace('synthetic','tampered',1))
            with self.assertRaises(project.ProjectionError):project.project(p)
if __name__=='__main__': unittest.main()
