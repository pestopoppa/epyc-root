## Selected target (original launch, model, requests and build)
A read-only source-capture control. No repository operation.
