## Context bundle — VARIABLE mode: most of it is on disk, not in this prompt
Bundle directory: `/mnt/raid0/llm/tmp/vidya-belief-substrate/actor-seat-native-20261118/official/attempt-9x3b5skk/actor-context/20261118T160331-critic-fadf39d5`
The full planning context is 125 chars. The sections marked INLINE below are reproduced in full at the end of this index; the other 125 chars are files in that directory. Read only what you need with your file tools: `read` (1-indexed `offset`/`limit`), `grep` with a `path`, `glob`. The files are exactly what an inline prompt would have shown -- nothing added, nothing dropped -- and they stay on disk for this whole call: after a context compaction, re-read `/mnt/raid0/llm/tmp/vidya-belief-substrate/actor-seat-native-20261118/official/attempt-9x3b5skk/actor-context/20261118T160331-critic-fadf39d5/INDEX.md` instead of working from memory. `sections/` holds each section verbatim; `json/<section>/` holds the same JSON split per key (a directory's `_index.json` lists its children in order).

| # | section | file | chars | lines | in prompt |
|---|---|---|---|---|---|
| 1 | target | `sections/01-target.md` | 125 | 2 | file |

Headings in the file-only markdown sections (file → line):
- `sections/01-target.md`: L1 ## Selected target (original launch, model, requests and build)

=== INLINE sections (verbatim) ===
