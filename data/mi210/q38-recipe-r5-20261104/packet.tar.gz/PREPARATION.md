# Q38 recipe comparison r4 preparation

Row `inf22-m4-q38-recipe-r5-20261104` is a fresh successor to failed r4 (r4 stopped before inference because the non-dryrun job tried to create `captures/run-r1` before `captures` existed). It reuses the existing r2 reviewed descriptive 12-cell frame: C5 c72ec82f and candidate bc441f1a, canonical_t48/configured_t96, three repetitions, context 8192 and 128 output tokens. Bare r3 data is separate. Plan SHA-256: 418fc2d79ed38a07da103ad63516d646644e98391a667d7a1925d09840eeefed.

The publisher's isolated dry-run path runs actual native responses on both enrolled images, 8–16 tokens each at context 1024, using precisely four allocated CPUs and a matching thread clamp. It uses the real ownership watcher/cgroup/PID registry, checks numeric response metrics and owned-child cleanup, then emits a native progress record. It does not emit the former Python-pass placeholder. Cold-load first-progress budget is 600 s. This qualification is excluded from the 12-cell denominator.

The full grant invokes the sealed 12-cell comparison directly. It retains the reviewed RAM envelope (512 GiB maximum allocation plus 64 GiB available-memory reserve), full-host CPU 0-95 lease, source/image identity, STOP/deadline, ownership and recorded co-tenancy. No best-recipe, quality, fold, promotion or current-champion verdict is authorized.

Independent r2 custody receipts for the three target shards and the MTP draft are copied under inputs/. Entry verifies those receipt hashes and current file identity metadata; it does not hash weights in the grant. Pregrant checks validated source/image seals, plan, custody and reader enrollment. Publication must itself pass the actual native smoke before the row is readied.


The r5 job creates the missing parent directory, then retains exclusive `mkdir` on `run-r1` so stale output refuses. The reviewed frame is unchanged; plan row ID and packet-local paths were recut for r5. Existing custody receipt bytes and model inputs are preserved exactly.
