#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/p12-slots-followup-20261104
if [[ "${1:-}" = --job ]]; then
  if [[ "${FILLER_SMOKE:-0}" = 1 || "${FILLER_DRYRUN:-0}" = 1 ]]; then
    exec python3 "$D/native_smoke.py"
  fi
  export P12_RESULT_PATH="$D/RESULT.json"
  exec python3 "$D/p12_run.py" --output-root "$D/run/$(date -u +%Y%m%dT%H%M%S)-$$"
fi
if [[ "${1:-}" = --complete ]]; then
  if [[ "${FILLER_SMOKE:-0}" = 1 || "${FILLER_DRYRUN:-0}" = 1 ]]; then
    exec python3 "$D/native_smoke.py" --check
  fi
  exec python3 "$D/complete.py" --result "$D/RESULT.json"
fi
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh \
  --id p12-slots-followup-20261104 --class cpu --role bench \
  --claim-cpus 0-95 --gpu-quiet exclusive --min-window 7200 \
  --stop "$D/STOP" --port 19080 --workdir "$D" \
  --cmd "/bin/bash $D/launch.sh --job" \
  --complete-cmd "/bin/bash $D/launch.sh --complete"
