#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def complete(path):
    try:
        r=json.loads(Path(path).read_text())
        intended={f'qwen36_q8_0-C1-np{n}-a7full' for n in (1,2,4)}
        cells=r['cells']
        return (r['schema']=='p12.e5stageb.result.v1' and r['status']=='COMPLETE' and len(cells)==3
                and {x['cell'] for x in cells}==intended and all(
                    x.get('status')=='OK' and x.get('harness_rc')==0 and not x.get('aborted')
                    and x.get('placement_proof')=='PASS' and x.get('busy_proof')=='PASS'
                    and x.get('cache_reset_proof')=='PASS' for x in cells))
    except (OSError,ValueError,KeyError,TypeError): return False
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--result',default=str(Path(__file__).parent/'out'/'RESULT.json')); a=ap.parse_args()
    raise SystemExit(0 if complete(a.result) else 1)
