#!/bin/bash
# Q38P-3 stage 1 (owner mi210-serving-program.md Q38P-3): C (ROCm 6.2 C5 store) vs B (ROCm 10.1 build-nolto-u600) vs Bp (B +
# HSA_NO_SCRATCH_RECLAIM=1), 27B Q8 + DFlash2 np1 ctx 65536 + llama-bench prefill. Exclusive idle MI210 + GPU host threads 184-191.
# Depends on q38p-window-probe-20261104: refuses unless its RESULT.json verdict is PASS (job.py re-checks at run time).
set -euo pipefail
D=/mnt/raid0/llm/tmp/q38p3-stage1-20261104
DEP=/mnt/raid0/llm/tmp/q38p-window-probe-20261104/out/RESULT.json
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
if [ "${FILLER_DRYRUN:-0}" != 1 ] && [ "${FILLER_SMOKE:-0}" != 1 ]; then
  /usr/bin/python3 -I -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1])).get("verdict")=="PASS" else 1)' "$DEP" 2>/dev/null \
    || { echo "REFUSED: $DEP verdict is not PASS" >&2; exit 2; }
fi
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id q38p3-stage1-r2-20261104 \
  --class gpu --gpu-quiet exclusive --claim-cpus 184-191 --role bench --min-window 3600 \
  --gpu-threads 184-191 \
  --cmd "/usr/bin/python3 -I $D/job.py" \
  --complete-cmd "/usr/bin/python3 -I -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1])).get(\"valid_blocks\",0)>=3 else 1)' $D/out/STAGE1-COMPLETE.json" \
  --stop "$D/STOP" --workdir "$D"
