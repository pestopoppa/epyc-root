#!/usr/bin/env python3
"""Real four-CPU server smoke; one completion, no cache reset or benchmark claim."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from p12_run import guard, manifest, RES, STORE, Q


def output():
    return Path(os.environ['FILLER_DRYRUN_RESULT_PATH'])


def check():
    try:
        r = json.loads(output().read_text())
        return (r['status'] == 'PASS' and r['requests'] == 1 and len(r['cpus']) == 4
                and r['generated_tokens'] > 0 and r['owned_server_dead'] is True
                and r['started_at'] >= float(os.environ.get('FILLER_SMOKE_T0', '0')))
    except (KeyError, ValueError, OSError):
        return False


def run():
    dest = output()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        raise RuntimeError('Refusing stale smoke result')
    cpus = sorted(os.sched_getaffinity(0))
    if len(cpus) != 4:
        raise RuntimeError(f'Native smoke requires exactly four inherited CPUs, got {cpus}')
    server = guard()
    m = json.load(open(manifest(f'{Q}-C1-np1-a7full')))
    sys.path.insert(0, RES + '/scripts/lib')
    from canonical_recipe import build_canonical_env
    env = build_canonical_env(extra_vars={'KMP_BLOCKTIME':'10', 'OMP_NUM_THREADS':'4'}, library_path=STORE + '/bin')
    # Engine reserves 19080. Refuse an occupied endpoint before starting our server.
    with socket.socket() as s:
        s.bind(('127.0.0.1', 19080))
    cmd = [server, '-m', m['model_path'], '--host', '127.0.0.1', '--port', '19080',
           '-t', '4', '-tb', '4', '-np', '1', '-c', '512', '--device', 'none',
           '-ngl', '0', '--slots', '--no-warmup', '--no-mmap']
    r = {'status':'FAIL', 'started_at':time.time(), 'cpus':cpus, 'requests':0,
         'cmd':cmd, 'kernel_store':STORE, 'scope':'native smoke only; no placement/cold-cache/throughput claim'}
    p = None
    deadline = min(time.time() + 1500, float(os.environ.get('FILLER_DEADLINE', time.time() + 1500)))
    stop = os.environ.get('FILLER_STOPFILE', '')
    def interrupted(signum, frame):
        raise RuntimeError(f'interrupted by signal {signum}')
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, interrupted)
    try:
        with (dest.parent / 'native-server.log').open('w') as log:
            p = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
            r['server_pid'] = p.pid
            while True:
                if p.poll() is not None:
                    raise RuntimeError(f'owned server exited {p.returncode}')
                if time.time() >= deadline or (stop and os.path.exists(stop)):
                    raise RuntimeError('smoke deadline/stopfile')
                try:
                    with urllib.request.urlopen('http://127.0.0.1:19080/health', timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, TimeoutError):
                    pass
                time.sleep(1)
            # Bind evidence to this captured server, including its actual loaded ggml libraries.
            maps = Path(f'/proc/{p.pid}/maps').read_text()
            loaded = sorted({l.split()[-1] for l in maps.splitlines() if 'libggml' in l})
            if not loaded or any(not os.path.realpath(x).startswith(STORE + '/') for x in loaded):
                raise RuntimeError(f'foreign/missing ggml library: {loaded}')
            r['loaded_ggml'] = loaded
            req = urllib.request.Request('http://127.0.0.1:19080/completion',
                data=json.dumps({'prompt':'Hello', 'n_predict':8, 'temperature':0, 'seed':42}).encode(),
                headers={'Content-Type':'application/json'})
            r['requests'] = 1
            with urllib.request.urlopen(req, timeout=max(1, deadline-time.time())) as response:
                body = json.load(response)
            r['response'] = body
            r['generated_tokens'] = body.get('tokens_predicted', 0)
            if not isinstance(r['generated_tokens'], int) or r['generated_tokens'] <= 0:
                raise RuntimeError('No native generated tokens')
            r['status'] = 'PASS'
    except Exception as exc:
        r['error'] = str(exc)
        r['status'] = 'FAIL'
    finally:
        # Popen owns this exact PID; wait reaps it, so PID reuse cannot target another process.
        if p is not None:
            if p.poll() is None:
                p.terminate()
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    p.kill()
                    p.wait(timeout=5)
            r['owned_server_dead'] = p.poll() is not None
        else:
            r['owned_server_dead'] = True
        r['ended_at'] = time.time()
        tmp = dest.with_suffix('.tmp')
        tmp.write_text(json.dumps(r, indent=2) + '\n')
        tmp.replace(dest)
    return 0 if check() else 1


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true')
    a = ap.parse_args()
    raise SystemExit((0 if check() else 1) if a.check else run())
