# P12 slots follow-up r2 — descriptive scout, 2026-11-04

**SCOUT ONLY / NON-GATING.** The full harness explicitly receives `--allow-host-health-warning`; the pinned harness records `decision_grade=false`. Even if all cells pass, results are indicative only and must never be described as decision-grade or as a formal speed claim. This override exists because the host-health precondition stopped the previous attempt before server launch.

This fresh packet uses row id `p12-slots-followup-r2-20261104` and its own scratch root. It has no prior attempt output. The runner stops at the first incomplete/failed cell, preserving the partial result and avoiding misleading later-cell evidence.

The real native smoke remains separate qualification: exactly four inherited CPUs, exact candidate Qwen server, one `/completion` request capped at eight generated tokens, loaded ggml path check, and owned-server cleanup. It makes no placement, cold-cache, throughput, or occupancy claim.

The descriptive full run is exactly C1 np1/2/4. Each cell requires a performed successful `drop_caches` witness with `cold_cache_guaranteed=true`, two passing in-window placement samples, and a successful same-port `/slots` GET fully contained in a successful request interval with `is_processing=true`. Missing evidence is incomplete, not idle. The harness's CPU and NUMA affinity proof and these independent witnesses remain strict under the warning override.

No inference, row publication, weight hashing, production change, or gate change is part of packet preparation. A normal row grant is still required to execute.

## Provenance

The pinned research harness remains `/mnt/raid0/llm/worktrees/research-pin-p12-rerun-20261103` at the guarded commit in `p12_run.py`; candidate binary/model custody is carried in `MODEL-PREGRANT.json` without re-hashing weights. Original packet source: `/mnt/raid0/llm/tmp/p12-slots-followup-20261104`.

# P12 slots/placement successor (prepared 2026-11-04)

## Scope

Prepare a descriptive CPU inference successor for P12-NEXT-4, using the existing P-BENCH-3 harness and corrected-placement sampler. No inference was launched and nothing was published or changed in handoffs/production.

Question: while the C1 np1/2/4 cells from the pinned Qwen3.6 Q8_0 bank are running, does live `GET /slots` report at least one `is_processing=true` slot, and does the in-window NUMA sampler pass? Keep `/slots` occupancy and decode throughput as distinct evidence. This packet does not upgrade Stage-B to decision-grade.

## Existing evidence / reason for successor

- Existing corrected rerun: `/mnt/raid0/llm/tmp/p12-e5-stageb-20261103/out-rerun-20261103/RESULT.json`. It records C1 np1/2/4 aggregate decode 84.235 / 89.930 / 84.585 tok/s and placement PASS for each. Those rows answer the placement question already, but contain no captured `/slots` observation.
- Existing same-session follow-up: `/mnt/raid0/llm/tmp/p12-e5-stageb-20261103/out-h2h-20261104/RESULT.json` records C1 np8 79.231, C1 np16 83.921 and C1b np8 74.722 tok/s; all placement PASS. The latest P12-NEXT-4 annotation records C1/C1b np16 87.5/60.5. These higher-np cells do not prove the np1/2/4 slot occupancy question.
- The corrected source runner is `/mnt/raid0/llm/tmp/p12-e5-stageb-20261103/p12_run.py`; its current `GRID` only selects C1 np16 and C1b np16. The reusable harness is `scripts/benchmark/server_numa_np_sweep.py` in pinned research worktree `/mnt/raid0/llm/worktrees/research-pin-p12-rerun-20261103`; manifests are in `data/batched_decode/e5_manifests_a7_placement1/qwen36_q8_0/`.
- C1 np1/2/4 exact manifests exist and declare one full-machine `interleave=all` server, ports 19080, CPU list 0-95. C1b manifests also exist for np1/2/4, each correctly interleaved over its own two nodes. Include C1b np1/2/4 only if the owner still needs the half-machine comparison; P12-NEXT-4's minimum is C1 np1/2/4 plus the C1b cell already assigned by the handoff.

## Run frame for owner session

Use the corrected p12 runner semantics: pinned research harness, champion-candidate CPU store `cpu-20261103-181483cfc-lbt`, manifest-driven recipes, per-cell cache reset, load-gated in-window NUMA placement sampler (two samples 45 seconds apart), exact model `Qwen3.6-35B-A3B-MTP-Q8_0.gguf`, and P-BENCH-3 pinned request bank. Run C1 np1, np2, np4 as distinct fresh cells. Reuse the established C1b same-window cell(s) only if comparison is still needed. Preserve the host-health/era limitations in the output; no decision-grade or provisioning claim follows from this packet.

For each live cell, an independent read-only observer should poll `http://127.0.0.1:19080/slots` at 1-second intervals while the harness is driving requests, append timestamp + HTTP status + raw JSON to `<cell>/slots.jsonl`, and stop when the cell's server exits. A qualifying busy proof is at least one successful sample during the harness request window where the JSON array contains one or more objects with `is_processing: true`; retain all samples, including idle and failed reads. Do not label a sample taken only during model load/idle as busy. The /slots endpoint contract is an array; orchestrator parser at `epyc-orchestrator/src/backends/context_limits.py` maps each element's `is_processing` field.

Expected output per cell: harness-native run directory and `cells.jsonl`, `placement.pid*.s*.log`, observer `slots.jsonl`, plus a compact result row with aggregate decode tok/s, placement proof, busy sample count, total successful /slots samples, and timestamps proving overlap with requests. A missing busy sample is incomplete evidence, not proof of idle slots.

## Gates / blockers

- Required current CPU lease and quiet-window grant are not established by this preparation; the execution owner must obtain the normal row-engine grant before inference.
- A live `/slots` watcher must be started in the same cell window and tied to the exact manifest port. Existing packets have no `/slots` captures.
- The prior results are indicative: host health was waived and cache-reset policy used scoped `numa_evict` while whole-host lock was absent. They establish neither decision-grade measurements nor a formal Stage-B claim.
- Current evidence already has C1 np1/2/4 placement PASS in `out-rerun-20261103`; re-running those cells is only necessary to bind placement and `/slots` busy evidence into one new window or satisfy the owning row's requirement.

## Implemented successor (2026-11-04)

`p12_run.py` now selects exactly C1 np1/2/4, writes only this scratch packet (or a fresh `--output-root`), and attaches a `/slots` observer to each captured descendant whose executable matches the guarded candidate server and whose `--port` matches the manifest. The load-gated NUMA placement sampler is retained. Observer GET start/end use `time.perf_counter`, the native harness request clock; only a full GET interval inside a successful same-cell, same-port request counts. Every expected port needs a busy overlap. Raw bodies, failed reads, and idle reads persist. Missing, malformed, idle-only, warmup-only, or non-overlapping records fail closed.

The wrapper's duplicated cache-reset commands were removed. The pinned harness alone performs resets. Execution requires an ancestor-held whole-host grant and each returned cell must carry a successful performed `drop_caches` witness with `cold_cache_guaranteed=true`. No host-health waiver is enabled. Owned PIDs are captured from the harness descendant tree with process starttime identity, terminated individually if needed, checked after TERM/KILL, and the observer is stopped in `finally`. This does not touch unrelated processes.

Runnable `launch.sh` requires `P12_GRANT_FILE`, `FILLER_DEADLINE`, `FILLER_STOPFILE`, and fresh absolute `P12_OUTPUT_ROOT`. It acquires CPU 0-95 plus exclusive gpu-quiet through existing region-lock with grant validation and a one-second acquisition timeout. It does not book a grant or wait indefinitely. The owning session must supply the normal row-engine booking; this packet has acquired no lease and run no inference. After the run, `python3 complete.py --result "$P12_OUTPUT_ROOT/RESULT.json"` succeeds only for exactly the three intended cells with busy overlap, placement and cold-cache proofs.

Validation: `python3 -m unittest -v test_slots` passed three model-free tests (strict array/boolean contract, fail-closed interval/port/cell/cache-independent overlap cases, and real local HTTP observer). `taskset -c 0-3 python3 p12_run.py --dry-run --output-root .../smoke-final` passed the native pinned harness without `--execute`: `SMOKE_DRYRUN`, cell `DRYRUN_OK`, harness rc 0. This is a four-CPU-affinity **model-free native harness dry-run**, not a model-compute/publisher smoke, a lease proof, or new inference evidence. Actual request-overlapping occupancy and placement remain unmeasured until the granted successor runs. No repository, production, handoff, or publication files were changed.


## Canonical row preparation correction (2026-11-04)

The earlier region-lock-only launcher and model-free dry-run are superseded as row-readiness preparation by `launch.sh` + `spec.json`. The canonical launcher invokes installed `filler_run15.sh`, requests CPU 0-95 and exclusive GPU quiet, and names port 19080. `regions` is CPU 0-95; the allocator derives quiet-host shape and the GPU reservation from launcher `--gpu-quiet exclusive`. The full run is exactly C1 np1/2/4 and writes fresh `run/<UTC>-<PID>/` evidence plus an atomically refreshed top-level `RESULT.json`. Completion remains strict: successful cold-cache reset witness, two passing in-window placement samples per server, request-overlapping busy slots on every manifest port, exact cells and successful harness exit.

For the keeper's native smoke (`FILLER_DRYRUN=1` and/or `FILLER_SMOKE=1`), `native_smoke.py` requires exactly four inherited CPUs; it launches the SHA-guarded candidate server against the exact Qwen3.6 Q8_0 model, CPU-only, one slot/context 512, and issues exactly one `/completion` request capped at eight generated tokens. Health GETs wait for this owned server to load. It verifies loaded ggml paths belong to the candidate store and terminates/reaps only its captured server PID. The response, command, CPU affinity, model path and cleanup proof are retained under the per-attempt `FILLER_DRYRUN_DIR`, and the predicate requires actual generated tokens plus successful cleanup. No cache reset, placement or benchmark claim is made from this smoke. A dry-run flag on `p12_run.py` still means model-free harness validation and is not the row smoke.

This preparation did not run a model, execute the launcher, book resources, publish a row, or change production/gates. The owner may review/publish `spec.json` through the normal row pipeline. Validation performed here is model-free: shell syntax, Python compilation, the three existing strict observer tests, and static row/launcher contract checks. Native smoke execution remains for the owning publisher, whose publish call will actually load the model.

## Canonical row submission

`spec.json` and `launch.sh` now use the row engine and independent native four-CPU, one-request smoke; earlier manual grant-launch instructions above describe the superseded preparation. The model hash is inherited from the KVU-12.5 custody record; matching device, inode, size and mtime/ctime are checked without hashing weights in the grant. The research source is pinned to bb669e628 and tracked-clean; the candidate executable is content-checked against its build manifest. This packet is not qualified until the publisher smoke passes.
