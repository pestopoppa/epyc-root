#!/usr/bin/env python3
"""Read-only slots evidence: perf_counter matches native harness request records."""
import json, math, time, urllib.request, urllib.error
from datetime import datetime, timezone

def parse_busy(body):
    data=json.loads(body)
    if not isinstance(data,list) or not all(isinstance(x,dict) for x in data):
        raise ValueError('/slots body must be a JSON array of objects')
    return any(x.get('is_processing') is True for x in data), sum(x.get('is_processing') is True for x in data)

def rows(path):
    try:
        with open(path) as f:
            for line in f:
                try: yield json.loads(line)
                except (ValueError, TypeError): continue
    except OSError: return

def overlap_summary(slots_path, requests_path, cell, ports):
    req=[]
    for x in rows(requests_path):
        try:
            a,b=float(x['start_s']),float(x['end_s']); port=x['instance_port']
            if x.get('cell_id')==cell and x.get('success') is True and port in ports and math.isfinite(a) and math.isfinite(b) and b>a:
                req.append((a,b,port))
        except (ValueError,KeyError,TypeError): continue
    successful=0; busy=[]; seen=set()
    for x in rows(slots_path):
        try:
            a,b=float(x['start_s']),float(x['end_s']); port=x['instance_port']
            valid=x.get('http_status')==200 and x.get('owned_pid') and port in ports and math.isfinite(a) and math.isfinite(b) and b>=a
            if not valid: continue
            is_busy,_=parse_busy(x['raw_body']); successful+=1
            if is_busy and any(r0<=a<=b<=r1 and port==rp for r0,r1,rp in req): busy.append(x); seen.add(port)
        except (ValueError,KeyError,TypeError): continue
    return {'request_intervals':len(req),'successful_slots_samples':successful,
            'busy_samples_overlapping_requests':len(busy),'ports_with_busy_overlap':sorted(seen),
            'busy_proof':'PASS' if set(ports)==seen and req else 'FAIL_MISSING_OVERLAP',
            'first_busy_overlap_utc':busy[0]['utc'] if busy else None,
            'clock':'time.perf_counter; full GET interval contained in successful same-cell same-port request'}

def poll(port,path,stop,owned_pid,interval=1.0):
    url=f'http://127.0.0.1:{port}/slots'
    with open(path,'a',buffering=1) as out:
        while not stop.is_set():
            start=time.perf_counter(); utc=datetime.now(timezone.utc).isoformat(); status=None; raw=''; error=''
            try:
                with urllib.request.urlopen(url,timeout=2) as r: status=r.status; raw=r.read().decode('utf-8','replace')
            except urllib.error.HTTPError as e: status=e.code; raw=e.read().decode('utf-8','replace'); error=str(e)
            except Exception as e: error=f'{type(e).__name__}: {e}'
            end=time.perf_counter(); busy=None; processing=None
            if status==200:
                try: busy,processing=parse_busy(raw)
                except Exception as e: error=f'parse: {e}'
            out.write(json.dumps(dict(utc=utc,start_s=start,end_s=end,instance_port=port,owned_pid=owned_pid,url=url,http_status=status,busy=busy,processing_slots=processing,raw_body=raw,error=error))+'\n')
            stop.wait(interval)
