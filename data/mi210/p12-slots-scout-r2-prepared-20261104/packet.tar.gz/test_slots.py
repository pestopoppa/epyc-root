import json, tempfile, unittest, threading, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from slots_observer import overlap_summary, parse_busy, poll

class Tests(unittest.TestCase):
    def test_contract(self):
        self.assertEqual(parse_busy('[{"is_processing":true},{"is_processing":1}]'),(True,1))
        for body in ('{}','null','[1]','bad'):
            with self.assertRaises(ValueError): parse_busy(body)
    def test_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            s,r=Path(d)/'slots',Path(d)/'requests'
            request=dict(cell_id='cell',success=True,start_s=10,end_s=20,instance_port=19080)
            sample=dict(utc='now',start_s=12,end_s=13,instance_port=19080,owned_pid=1,http_status=200,raw_body='[{"is_processing":true}]')
            def check(expected, **updates):
                x=sample|updates; s.write_text(json.dumps(x)+'\n'); r.write_text(json.dumps(request)+'\n')
                self.assertEqual(overlap_summary(s,r,'cell',[19080])['busy_proof'],expected)
            check('PASS')
            for updates in ({'start_s':9},{'end_s':21},{'instance_port':19081},{'owned_pid':None},{'http_status':503},{'raw_body':'{}'},{'raw_body':'[{"is_processing":false}]'},{'start_s':float('nan')}): check('FAIL_MISSING_OVERLAP',**updates)
            check('PASS'); self.assertEqual(overlap_summary(s,r,'wrong',[19080])['busy_proof'],'FAIL_MISSING_OVERLAP')
            self.assertEqual(overlap_summary(s,r,'cell',[19080,19081])['busy_proof'],'FAIL_MISSING_OVERLAP')
            request['success']=False; check('FAIL_MISSING_OVERLAP')
    def test_real_http_observer(self):
        stop=threading.Event()
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200); self.end_headers(); self.wfile.write(b'[{"is_processing":true}]'); stop.set()
            def log_message(self,*args): pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler); thread=threading.Thread(target=server.serve_forever); thread.start()
        try:
            with tempfile.TemporaryDirectory() as d:
                s,r=Path(d)/'slots',Path(d)/'requests'; start=time.perf_counter()
                poll(server.server_port,s,stop,123,0.01); end=time.perf_counter()
                r.write_text(json.dumps(dict(cell_id='cell',success=True,start_s=start,end_s=end,instance_port=server.server_port))+'\n')
                self.assertEqual(overlap_summary(s,r,'cell',[server.server_port])['busy_proof'],'PASS')
        finally: server.shutdown(); server.server_close(); thread.join()

if __name__=='__main__': unittest.main()
