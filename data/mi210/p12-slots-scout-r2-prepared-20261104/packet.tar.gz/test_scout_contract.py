"""Model-free checks for the r2 scout contract."""
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent

class ScoutContractTests(unittest.TestCase):
    def test_fresh_identity_and_scout_decision_rule(self):
        spec = json.loads((ROOT / 'spec.json').read_text())
        self.assertEqual(spec['id'], 'p12-slots-followup-r2-20261104')
        self.assertEqual(spec['scratch_root'], str(ROOT))
        self.assertIn('SCOUT ONLY / NON-GATING', spec['decision_rule'])
        self.assertIn('never decision-grade', spec['decision_rule'])
        self.assertEqual(spec['result_path'], str(ROOT / 'RESULT.json'))

    def test_runner_has_warning_override_and_stops_on_first_bad_cell(self):
        source = (ROOT / 'p12_run.py').read_text()
        self.assertIn('"--allow-host-health-warning"', source)
        self.assertIn('if not dry and r.get("status") != "OK": break', source)
        self.assertIn('decision_grade_claim": False', source)

    def test_completion_cannot_certify_decision_grade(self):
        source = (ROOT / 'complete.py').read_text()
        self.assertIn("r.get('scope')=='SCOUT_ONLY_NON_GATING'", source)
        self.assertIn("r.get('decision_grade_claim') is False", source)
        self.assertIn("x.get('decision_grade_harness') is False", source)

    def test_native_smoke_keeps_four_cpu_one_request_contract(self):
        source = (ROOT / 'native_smoke.py').read_text()
        self.assertIn('len(cpus) != 4', source)
        self.assertIn("r['requests'] = 1", source)
        self.assertIn("'n_predict':8", source)
        self.assertIn('owned_server_dead', source)

if __name__ == '__main__':
    unittest.main()
