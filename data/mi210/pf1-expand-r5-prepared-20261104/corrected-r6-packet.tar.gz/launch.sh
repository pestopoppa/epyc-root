#!/bin/bash
# PF1-EXPAND (owner mi210-serving-program.md).
# Whole host 0-95 + idle MI210 (gpu-quiet exclusive, role bench) = quiet-host shape; job cap 2400 s cumulative.
set -euo pipefail
D=/mnt/raid0/llm/tmp/pf1-expand-r6-20261104
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id pf1-expand-r6-20261104 \
  --class cpu+gpu --gpu-quiet exclusive --claim-cpus 0-95 --role bench --min-window 1800 \
  --cmd "/usr/bin/python3 -I $D/job.py" \
  --complete-cmd "test -s $D/out/PILOT-COMPLETE.json" \
  --stop "$D/STOP" --workdir "$D"
