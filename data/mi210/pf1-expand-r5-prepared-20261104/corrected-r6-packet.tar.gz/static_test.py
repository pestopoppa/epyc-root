#!/usr/bin/env python3
"""Model-free r6 fixtures; importing job does not invoke main/plumbing."""
import ast, importlib.util, json, pathlib, subprocess
D=pathlib.Path(__file__).resolve().parent
ast.parse((D/'job.py').read_text())
subprocess.run(['bash','-n',str(D/'launch.sh')],check=True)
s=importlib.util.spec_from_file_location('r6_job',D/'job.py'); j=importlib.util.module_from_spec(s); s.loader.exec_module(j)
assert j.L_SET==(256,384,512,768) and j.BLOCKS==3 and j.REPS==5
assert j.GPU_SKEW_RULE=='record' and j.CTRL_TOL==.10 and j.CTRL_DIVERGE==.25
for arm in ['A0']+j.GPU_ARMS:
 a,e=j.canonical_argv(arm,j.L_SET,'/tmp/model-free-unused')
 assert [int(a[i+1]) for i,x in enumerate(a) if x=='-p']==list(j.L_SET)
 assert a[a.index('-r')+1]=='5'
 assert ('--allow-skew' in a)==(arm!='A0')
 assert ('GGML_OP_OFFLOAD_MIN_BATCH' in e)==(arm=='A1-disabled')
 if arm=='A2': assert a[a.index('-ncmoe')+1]=='48'
ratios={f'{a}@{L}':[v]*3 for a in ('A1','A2') for L,v in zip(j.L_SET,(.8,1.,1.2,1.3))}
assert all(x['lower_bracket_L']==[256,512] and x['bracket_width_L']==256 and x['at_band_intermediate_L']==[384] for x in j.crossover(ratios,True).values())
for a in ('A1','A2'): ratios[f'{a}@384']=[1.08]*3
assert all(x['lower_bracket_L']==[256,384] for x in j.crossover(ratios,True).values())
assert all(x['lower_bracket_L'] is None for x in j.crossover(ratios,False).values())
for edge in (.93,1.07):
 for a in ('A1','A2'): ratios[f'{a}@256']=[edge]*3
 assert all(x['states']['256']=='at_crossover' and x['lower_bracket_L'] is None for x in j.crossover(ratios,True).values())
assert j.look([],1) is None and j.look([],2) is None
for f in ('IDENTITY.json','spec.json'): json.loads((D/f).read_text())
# Validate native plumbing argv with inherited affinity fixtures, never invoke it.
original_affinity = j.os.sched_getaffinity
try:
 for inherited in ({10,11,12,13}, {20,22,24,26,28,30,32,34}):
  j.os.sched_getaffinity = lambda pid, cpus=inherited: cpus
  a, e = j.plumbing_argv()
  chosen = set(map(int, a[a.index('-c')+1].split(',')))
  assert len(chosen)==4 and chosen <= inherited
  assert a[a.index('-t')+1]=='4' and a[a.index('--load-threads')+1]=='4'
 j.os.sched_getaffinity = lambda pid: {1,2,3}
 try: j.plumbing_argv()
 except RuntimeError: pass
 else: raise AssertionError('under-four affinity must refuse')
finally: j.os.sched_getaffinity=original_affinity
text=(D/'job.py').read_text()
assert 'killpg' not in text
parent = D.parent/'pf1-expand-r5-20261104'/'job.py'
prior=ast.parse(parent.read_text()); current=ast.parse(text)
# All scientific, identity, capture and cleanup functions retain identical ASTs.
old={n.name:ast.dump(n,include_attributes=False) for n in prior.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new={n.name:ast.dump(n,include_attributes=False) for n in current.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert all(new[k]==v for k,v in old.items() if k!='plumbing')
result={'result':'PASS','checks':['bash syntax','AST parse','model-free import','4-arm grid/reps/env/placement argv','noise boundary and bracket/guard fixtures','empty-frame futility checks','JSON parse','exact four inherited CPU/thread plumbing argv','under-four affinity refusal','scientific/identity/guard/captured-PID cleanup AST unchanged from r5'],'model_executed':False,'published':False,'cleanup_runtime_fixtures':'not rerun; unchanged AST from r5; no polling or waiting'}
(D/'STATIC-CHECKS.json').write_text(json.dumps(result,indent=1)+'\n')
print(json.dumps(result))
