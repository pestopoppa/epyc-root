#!/usr/bin/env python3
"""Model-free r5 fixtures; importing job does not invoke main/plumbing."""
import ast, importlib.util, json, pathlib, subprocess
D=pathlib.Path(__file__).resolve().parent
ast.parse((D/'job.py').read_text())
subprocess.run(['bash','-n',str(D/'launch.sh')],check=True)
s=importlib.util.spec_from_file_location('r5_job',D/'job.py'); j=importlib.util.module_from_spec(s); s.loader.exec_module(j)
assert j.L_SET==(256,384,512,768) and j.BLOCKS==3 and j.REPS==5
assert j.GPU_SKEW_RULE=='record' and j.CTRL_TOL==.10 and j.CTRL_DIVERGE==.25
for arm in ['A0']+j.GPU_ARMS:
 a,e=j.canonical_argv(arm,j.L_SET,'/tmp/model-free-unused')
 assert [int(a[i+1]) for i,x in enumerate(a) if x=='-p']==list(j.L_SET)
 assert a[a.index('-r')+1]=='5'
 assert ('--allow-skew' in a)==(arm!='A0')
 assert ('GGML_OP_OFFLOAD_MIN_BATCH' in e)==(arm=='A1-disabled')
 if arm=='A2': assert a[a.index('-ncmoe')+1]=='48'
ratios={f'{a}@{L}':[v]*3 for a in ('A1','A2') for L,v in zip(j.L_SET,(.8,1.,1.2,1.3))}
assert all(x['lower_bracket_L']==[256,512] and x['bracket_width_L']==256 and x['at_band_intermediate_L']==[384] for x in j.crossover(ratios,True).values())
for a in ('A1','A2'): ratios[f'{a}@384']=[1.08]*3
assert all(x['lower_bracket_L']==[256,384] for x in j.crossover(ratios,True).values())
assert all(x['lower_bracket_L'] is None for x in j.crossover(ratios,False).values())
for edge in (.93,1.07):
 for a in ('A1','A2'): ratios[f'{a}@256']=[edge]*3
 assert all(x['states']['256']=='at_crossover' and x['lower_bracket_L'] is None for x in j.crossover(ratios,True).values())
assert j.look([],1) is None and j.look([],2) is None
for f in ('IDENTITY.json','spec.json'): json.loads((D/f).read_text())
# Controlled launch fixtures: no model, only subprocesses created by this test.
import os, signal, sys, tempfile, threading, time
class NullSampler:
 def __init__(self, pid):
  self.stop=threading.Event(); self.ident=None; self.vram=[]; self.busy=[]; self.kfd={}; self.maps={}
 def start(self): pass
 def join(self, timeout): pass
j.Sampler=NullSampler
original_stop=j.STOPF
with tempfile.TemporaryDirectory(prefix='pf1-owned-cleanup-') as td:
 td=pathlib.Path(td)
 # Child ignores TERM to exercise escalation; grandchild proves recursive discovery.
 payload="import subprocess,signal,time,os; signal.signal(signal.SIGTERM,signal.SIG_IGN); p=subprocess.Popen(['sleep','60']); open(%r,'w').write(str(os.getpid())+' '+str(p.pid)); time.sleep(60)" % str(td/'pids')
 def ready_action(action):
  deadline=time.monotonic()+5
  while not (td/'pids').exists():
   if time.monotonic()>deadline: raise RuntimeError('owned fixture did not start')
   time.sleep(.01)
  time.sleep(.2); action()
 for mode in ('stop','interrupt','terminate','exception'):
  (td/'pids').unlink(missing_ok=True)
  j.STOPF=str(td/'STOP'); pathlib.Path(j.STOPF).unlink(missing_ok=True)
  if mode=='stop': action=lambda: pathlib.Path(j.STOPF).touch()
  elif mode in ('interrupt','terminate'): action=lambda: os.kill(os.getpid(),signal.SIGINT if mode=='interrupt' else signal.SIGTERM)
  else: action=lambda: pathlib.Path(j.STOPF).touch()
  worker=threading.Thread(target=ready_action,args=(action,)); worker.start()
  original_cleanup=j.OwnedTree.cleanup
  # Short grace only in tests; production remains TERM20/KILL10.
  j.OwnedTree.cleanup=lambda self: original_cleanup(self,.2,2)
  original_exists=j.os.path.exists
  if mode=='exception':
   def fail_exists(path):
    if path==j.STOPF and original_exists(path): raise RuntimeError('injected launch failure')
    return original_exists(path)
   j.os.path.exists=fail_exists
  try:
   result=j.run_launch('A0',(256,),[sys.executable,'-c',payload],dict(os.environ),str(td/mode),time.time()+10)
   assert mode=='stop' and result[0]['error']=='stop'
  except j.LaunchInterrupted: assert mode in ('interrupt','terminate')
  except RuntimeError as e: assert mode=='exception' and str(e)=='injected launch failure'
  finally:
   worker.join(5); assert not worker.is_alive()
   j.OwnedTree.cleanup=original_cleanup; j.os.path.exists=original_exists
  for pid in map(int,(td/'pids').read_text().split()):
   ident=j.proc_identity(pid)
   assert ident is None or ident[2] in ('Z','X'), (mode,pid,ident)
 j.STOPF=original_stop
# A reused PID birth mismatch must never be captured or signaled.
tree=j.OwnedTree.__new__(j.OwnedTree); tree.owned={}
tree.capture_pid(os.getpid(),-1)
assert tree.owned=={}
assert 'killpg' not in (D/'job.py').read_text()
result={'result':'PASS','checks':['bash syntax','AST parse','model-free import','4-arm grid/reps/env/placement argv','noise boundary and bracket/guard fixtures','empty-frame futility checks','JSON parse','owned child/grandchild STOP cleanup and TERM-to-KILL escalation','SIGINT/SIGTERM cleanup','exception cleanup','PID birth mismatch refusal'],'model_executed':False,'published':False}
(D/'STATIC-CHECKS.json').write_text(json.dumps(result,indent=1)+'\n')
print(json.dumps(result))
