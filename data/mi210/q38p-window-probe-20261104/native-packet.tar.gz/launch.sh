#!/bin/bash
# Q38P window probe (owner mi210-serving-program.md Q38P-4; feeds Q38P-3 stage 1).
# Exclusive idle MI210 (gpu-quiet exclusive, role bench) + GPU host threads 184-191; job ~20 min.
# 2026-11-04 r2: vadd holds 4 GiB resident >= 22 s (rowflow dry-run residency rule: rocm-smi VRAM >= 64 MiB, ~5 s poll).
set -euo pipefail
D=/mnt/raid0/llm/tmp/q38p-window-probe-20261104
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id q38p-window-probe-20261104 \
  --class gpu --gpu-quiet exclusive --claim-cpus 184-191 --role bench --min-window 1500 \
  --gpu-threads 184-191 \
  --cmd "/usr/bin/python3 -I $D/job.py" \
  --complete-cmd "test -s $D/out/RESULT.json" \
  --stop "$D/STOP" --workdir "$D"
