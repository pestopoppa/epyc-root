#!/usr/bin/env python3
"""Q38P window probe (mi210-serving-program.md Q38P-4, feeds Q38P-3 stage 1). Exclusive MI210, ~20 min.
Stages (each sampled DURING: device VRAM, KFD pids, our own pid/container's KFD VRAM):
  S1a vadd-6.2  (ROCm 6.2 /opt/rocm userspace)          -> 'PASS gfx90a'
  S1b vadd-10.1 (isolated TheRock 10.1.0 tarball)       -> 'PASS gfx90a'   (10.1 userspace dispatch on in-kernel amdgpu)
  S2  vLLM container torch dispatch (bundled ROCm 10.0) -> device MI210, sum == 2097152
  S3  vLLM 0.33.0 offline greedy generate, Qwen3-4B-Instruct-2507 bf16, 3 prompts x 64 tokens
  S4  llama.cpp champion c72ec82f5 (C5 store, ROCm 6.2) llama-completion, same model (bf16 GGUF converted from the same HF dir)
RESULT.json verdict: PASS if S1a, S1b, S2, S3 load and dispatch with our own KFD residency proven (S4 must run too);
greedy parity S3 vs S4 is REPORTED (parity_ok), never gates PASS (bf16 vs bf16 across engines may legitimately diverge).
Smoke mode (FILLER_DRYRUN/FILLER_SMOKE=1, the keeper holds mi210_0 + 184-191): runs S1b for real as the first measured record
(dispatch_ms, n_dispatch, vram_peak_gib), then the no-GPU checks (inputs, image digest, docker mount) as a second record."""
import json, os, re, subprocess, sys, time, hashlib
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D)
import gpuproof as gp

OUT = os.path.join(D, 'out'); RES = os.path.join(OUT, 'results.jsonl'); RESULT = os.path.join(OUT, 'RESULT.json')
IDENT = json.load(open(os.path.join(D, 'IDENTITY.json')))
R101 = IDENT['rocm101']['prefix']; C5 = IDENT['llama_c5']['bin']; IMG = IDENT['vllm']['image']
HFM = IDENT['model']['hf_dir']; GGUF = IDENT['model']['gguf']
STOPF = os.environ.get('FILLER_STOPFILE', os.path.join(D, 'STOP'))
DEADLINE = int(os.environ.get('FILLER_DEADLINE', str(int(time.time()) + 2400)))
PLUMB = os.environ.get('FILLER_DRYRUN') == '1' or os.environ.get('FILLER_SMOKE') == '1'
GPU_ENV_DROP = ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES')
MIN_OWN_VRAM = {'S1a': 3 * 1024**3, 'S1b': 3 * 1024**3, 'S2': 1, 'S3': 2 * 1024**3, 'S4': 2 * 1024**3}


def now(): return time.strftime('%FT%TZ', time.gmtime())
def append(u):
    with open(RES, 'a') as f: f.write(json.dumps(u) + '\n'); f.flush(); os.fsync(f.fileno())
def atomic(p, o):
    t = p + '.tmp'; json.dump(o, open(t, 'w'), indent=1); os.replace(t, p)
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 24), b''): h.update(b)
    return h.hexdigest()


def base_env(ld):
    e = {k: v for k, v in os.environ.items() if k not in GPU_ENV_DROP}
    e['LD_LIBRARY_PATH'] = ld; return e


def docker_base(name):
    return ['docker', 'run', '--rm', '--name', name, '--network', 'none', '--device', '/dev/kfd', '--device', '/dev/dri',
            '--group-add', '992', '-u', f'{os.getuid()}:{os.getgid()}', '-e', 'HOME=/tmp', '--ipc=host',
            '--security-opt', 'seccomp=unconfined', '-v', f'{D}:/pkt:ro', '-v', f'{OUT}:/out', '--entrypoint', 'python3']


def step(sid, argv, env=None, budget=600, container=None, check=None, tag=None, split_err=False):
    if os.path.exists(STOPF): return None
    log = os.path.join(OUT, f'{tag or sid}.log'); t0 = time.time()
    rc, err, proof = gp.run_sampled(argv, log, env=env, timeout_at=min(DEADLINE - 60, time.time() + budget), stopfile=STOPF,
                                    container_name=container, errlog=(log[:-4] + '.stderr.log') if split_err else None)
    text = open(log, errors='replace').read()
    own_vram = max(proof['kfd_pids_ours'].values(), default=0)
    ok_dispatch = rc == 0 and err is None and (check(text) if check else True)
    u = {'unit_id': sid, 'mode': 'window', 'at': now(), 'argv': argv, 'ld_library_path': (env or {}).get('LD_LIBRARY_PATH'),
         'rc': rc, 'error': err, 'wall_s': round(time.time() - t0, 2), 'log': log, 'log_tail': text[-1500:], 'proof': proof,
         'own_kfd_pid_seen': bool(proof['kfd_pids_ours']), 'own_vram_max_b': own_vram}
    u['checks'] = {'rc0_and_output': ok_dispatch, 'own_kfd_residency': u['own_kfd_pid_seen'] and own_vram >= MIN_OWN_VRAM[sid],
                   'no_foreign_kfd': not proof['kfd_foreign']}
    u['valid'] = all(u['checks'].values())
    u['dispatch_ms'] = round((time.time() - t0) * 1000, 1)          # measured: whole step incl. runtime init
    u['vram_peak_gib'] = round(own_vram / 1024**3, 4)                 # measured: own KFD VRAM peak
    u['vram_device_delta_gib'] = round((proof['vram_delta_b'] or 0) / 1024**3, 4)
    u['kfd_own_pid_count'] = len(proof['kfd_pids_ours']); u['kfd_foreign_pid_count'] = len(proof['kfd_foreign'])
    if sid.startswith('S1'):
        m = re.search(r'n_dispatch=(\d+) n_touch=(\d+) held_s=([\d.]+)', text)
        u['n_dispatch'] = int(m.group(1)) if m else 0; u['n_touch'] = int(m.group(2)) if m else 0; u['held_s'] = float(m.group(3)) if m else 0.0
        u['checks']['dispatch_count_and_hold'] = u['n_dispatch'] >= 20000 and u['held_s'] >= 20.0
        u['valid'] = all(u['checks'].values())
    append(u); print(f"{sid} rc={rc} err={err} valid={u['valid']} own_vram={own_vram} foreign={proof['kfd_foreign']}", flush=True)
    return u


def completion_text(log):
    t = open(log, errors='replace').read()
    return t


def plumbing():
    # Smoke contract (rowflow): the FIRST record must be a real measurement. The smoke holds mi210_0 + 184-191, so run S1b
    # (vadd-10.1: TheRock 10.1 userspace dispatch on the in-kernel amdgpu) for real and write it first.
    s1b = step('S1b', [os.path.join(D, 'vadd-10.1')], env=base_env(R101 + '/lib'), budget=120, check=lambda t: 'PASS gfx90a' in t)
    bad = []
    for k, p in (('vadd-6.2', os.path.join(D, 'vadd-6.2')), ('vadd-10.1', os.path.join(D, 'vadd-10.1')),
                 ('c5 llama-completion', C5 + '/llama-completion'), ('rocm101 libamdhip64', R101 + '/lib/libamdhip64.so'),
                 ('gguf', GGUF), ('hf config', HFM + '/config.json')):
        if not os.path.exists(p): bad.append(f'missing {k}: {p}')
    r = subprocess.run(['docker', 'image', 'inspect', '-f', '{{index .RepoDigests 0}}', IMG], capture_output=True, text=True)
    if IDENT['vllm']['repo_digest'] not in r.stdout: bad.append(f'image digest mismatch: {r.stdout.strip()} {r.stderr.strip()[-200:]}')
    r = subprocess.run(['docker', 'run', '--rm', '--network', 'none', '-u', f'{os.getuid()}:{os.getgid()}', '-v', f'{D}:/pkt:ro',
                        '-v', f'{OUT}:/out', '--entrypoint', 'python3', IMG, '-c',
                        "import vllm,os;open('/out/.mountcheck','w').write(vllm.__version__);print(os.path.exists('/pkt/vllm_gen.py'))"],
                       capture_output=True, text=True, timeout=600)
    mc = os.path.join(OUT, '.mountcheck')
    if r.returncode != 0 or 'True' not in r.stdout or not os.path.exists(mc): bad.append(f'docker mount check failed rc={r.returncode} {r.stderr[-300:]}')
    vv = open(mc).read() if os.path.exists(mc) else None
    gguf_ok = os.path.getsize(GGUF) == IDENT['model']['gguf_bytes']
    if not gguf_ok: bad.append('gguf size mismatch')
    u = {'unit_id': f'plumbing-{now()}', 'mode': 'plumbing', 'at': now(), 'problems': bad, 'vllm_version_in_image': vv, 'smoke_s1b_valid': bool(s1b and s1b['valid']),
         'note': 'plumbing only, no GPU touched; never analysed'}
    append(u); print(json.dumps({'plumbing_ok': not bad, 'problems': bad, 's1b_valid': u['smoke_s1b_valid']}), flush=True)
    return 0 if not bad and u['smoke_s1b_valid'] else 3


def window():
    units = {}
    prompts = json.load(open(os.path.join(D, 'prompts.json')))
    pass_line = lambda t: 'PASS gfx90a' in t
    units['S1a'] = step('S1a', [os.path.join(D, 'vadd-6.2')], env=base_env('/opt/rocm/lib'), budget=120, check=pass_line)
    units['S1b'] = step('S1b', [os.path.join(D, 'vadd-10.1')], env=base_env(R101 + '/lib'), budget=120, check=pass_line)
    n = f'q38p-probe-s2-{os.getpid()}'
    units['S2'] = step('S2', docker_base(n) + [IMG, '-c',
                       "import torch;x=torch.ones(1<<20,device='cuda');print('DEV',torch.cuda.get_device_name(0),'SUM',(x*2).sum().item());import time;time.sleep(3)"],
                       budget=600, container=n, check=lambda t: 'MI210' in t and 'SUM 2097152.0' in t)
    n = f'q38p-probe-s3-{os.getpid()}'
    units['S3'] = step('S3', docker_base(n)[:-2] + ['-v', f'{HFM}:/model:ro', '--entrypoint', 'python3', IMG,
                       '/pkt/vllm_gen.py', '/out/vllm_gen.json'], budget=900, container=n, check=lambda t: 'VLLM-GEN-OK' in t)
    # S4: llama.cpp champion, one llama-completion per prompt (greedy, raw completion, no chat template)
    s4 = []
    for i, pr in enumerate(prompts):
        u = step('S4', [C5 + '/llama-completion', '-m', GGUF, '-ngl', '99', '-c', '4096', '-n', '64', '--temp', '0', '--top-k', '1',
                        '--seed', '0', '-no-cnv', '--no-display-prompt', '--simple-io', '-fa', 'on', '-p', pr],
                 env=base_env(C5 + ':/opt/rocm/lib'), budget=300, check=lambda t: True, tag=f'S4-p{i}', split_err=True)
        if u is None: break
        u['unit_id'] = f'S4-p{i}'; s4.append(u)
    units['S4'] = s4
    # parity
    par = []
    try:
        vg = json.load(open(os.path.join(OUT, 'vllm_gen.json')))
        for i, o in enumerate(vg['outputs']):
            if i >= len(s4): break
            lt = open(s4[i]['log'], errors='replace').read()
            vt = o['text']; lc = lt
            k = 0
            while k < min(len(vt), len(lc)) and vt[k] == lc[k]: k += 1
            par.append({'prompt': i, 'vllm_text': vt, 'llama_head': lc[:600], 'common_prefix_chars': k,
                        'first_100_chars_equal': k >= min(100, len(vt))})
    except (OSError, ValueError, KeyError) as e:
        par.append({'error': repr(e)})
    loads = [units.get(k) for k in ('S1a', 'S1b', 'S2', 'S3')]
    load_ok = all(u and u['valid'] for u in loads) and bool(s4) and all(u['checks']['rc0_and_output'] for u in s4)
    failed = [k for k in ('S1a', 'S1b', 'S2', 'S3') if not (units.get(k) and units[k]['valid'])] + ([] if s4 and all(u['checks']['rc0_and_output'] for u in s4) else ['S4'])
    res = {'verdict': 'PASS' if load_ok else 'FAIL', 'failed_stages': failed, 'at': now(),
           'stage_valid': {k: (units[k]['valid'] if isinstance(units.get(k), dict) else None) for k in ('S1a', 'S1b', 'S2', 'S3')},
           's4_rc0': [u['checks']['rc0_and_output'] for u in s4], 's4_own_residency': [u['checks']['own_kfd_residency'] for u in s4],
           'rocm101_dispatch_on_inkernel_amdgpu': bool(units.get('S1b') and units['S1b']['valid']),
           'vllm_container_dispatch': bool(units.get('S2') and units['S2']['valid']),
           'parity': par, 'parity_ok': bool(par) and all(p.get('first_100_chars_equal') for p in par),
           'identity_sha256': sha(os.path.join(D, 'IDENTITY.json'))}
    if os.path.exists(STOPF): res['verdict'] = 'STOPPED'
    atomic(RESULT, res); print(json.dumps({k: res[k] for k in ('verdict', 'stage_valid', 'parity_ok')}), flush=True)
    return 0 if res['verdict'] != 'STOPPED' else 75


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    sys.exit(plumbing() if PLUMB else window())
