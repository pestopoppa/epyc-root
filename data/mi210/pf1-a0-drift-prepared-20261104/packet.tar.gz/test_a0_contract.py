"""Model-free regression tests for the independent CPU A0 packet contract.

These tests intentionally use synthetic result records; they never invoke a model,
launcher, benchmark binary, or GPU utility.
"""
import importlib.util
import unittest
import tempfile
from unittest import mock
from pathlib import Path


JOB_PATH = Path(__file__).with_name("job.py")
SPEC = importlib.util.spec_from_file_location("mi210_a0_job", JOB_PATH)
job = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(job)


def fake_a0(block, length, **overrides):
    """A valid synthetic A0 unit with all required captured fields."""
    unit = {
        "mode": "pilot",
        "arm": "A0",
        "block": block,
        "L": length,
        "unit_id": f"b{block}-L{length}-A0",
        "launch_id": f"b{block}-A0",
        "rc": 0,
        "error": None,
        "valid": True,
        "capture_complete": True,
        "tps": 12.5,
        "samples_ts": [12.4, 12.5, 12.6],
        "build_commit": job.HEAD,
        "build_number": job.IDENT["kernel"]["build_number"],
        "argv": ["fake-bench"],
        "env": {"LD_LIBRARY_PATH": "/fake/cpu"},
        "vram": {"before_b": 2_000_000_000, "max_b": 2_800_000_000,
                 "delta_b": 800_000_000, "samples": 4},
        "kfd_pids": {},
        "claim": {"filler_id": "fake"},
        "raw_log": "/fake/raw.log",
        "mapped_ggml": {"123": {"real": ["/fake/cpu/libggml-cpu.so"]}},
        "wall_s": 10,
        "placement": {"sample_recorded": True, "max_share_pct": 35.0},
        "placement_rc": 0,
        "canonical_identity": {
            "kind": "kernel_store",
            "library_path": job.IDENT["kernel"]["stores"]["cpu"]["resolves_to"],
            "ggml_linkage": "PASS",
            "manifest_commit": job.HEAD,
        },
    }
    unit.update(overrides)
    return unit


def full_a0():
    return [fake_a0(block, length)
            for block in range(job.BLOCKS)
            for length in job.L_SET]


class A0ContractTests(unittest.TestCase):
    def test_completion_requires_all_fifteen_unique_planned_units(self):
        # The repair exposes a pure completion predicate for the CPU-only packet.
        self.assertTrue(job.a0_complete(full_a0()))
        self.assertFalse(job.a0_complete(full_a0()[:-1]))
        duplicated = full_a0()
        duplicated[-1] = dict(duplicated[0])
        self.assertFalse(job.a0_complete(duplicated))

    def test_a0_residency_is_process_scoped_not_global_vram_delta(self):
        record = fake_a0(0, job.L_SET[0])
        # Other GPU jobs can raise card-global VRAM; no A0-owned KFD PID means
        # that global increase must not be attributed to this A0 unit.
        checks = job.checks(record)
        self.assertTrue(checks["no_gpu_residency"])
        owned = dict(record, kfd_pids={"4242": 64 << 20},
                     vram={**record["vram"], "delta_b": 0})
        self.assertFalse(job.checks(owned)["no_gpu_residency"])

    def test_placement_requires_actual_share_and_coverage(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            (p / 'placement.log.rc').write_text('0\n')
            (p / 'placement.log').write_text('max=node0@25.0%\n')
            (p / 'placement.log.reason').write_text('coverage_pct=99\n')
            self.assertTrue(job.placement_valid(d))
            (p / 'placement.log.reason').write_text('coverage_pct=89\n')
            self.assertFalse(job.placement_valid(d))
            (p / 'placement.log.reason').write_text('coverage_pct=99\n')
            (p / 'placement.log').write_text('max=node0@41.0%\n')
            self.assertFalse(job.placement_valid(d))
            (p / 'placement.log').unlink()
            self.assertFalse(job.placement_valid(d))

    def test_interrupted_launch_drains_owned_children(self):
        instances = []
        class FakeSampler:
            def __init__(self, pid):
                self.stop = mock.Mock(); self.drained = False; instances.append(self)
            def start(self): pass
            def terminate_owned(self): self.drained = True
            def join(self, timeout): pass
        child = mock.Mock(pid=123)
        child.poll.side_effect = SystemExit(143)
        with tempfile.TemporaryDirectory() as d, mock.patch.object(job.subprocess, 'Popen', return_value=child), mock.patch.object(job, 'Sampler', FakeSampler):
            with self.assertRaises(SystemExit):
                job.run_launch((16,), ['fake'], {'LD_LIBRARY_PATH': '/fake'}, d, 1e20)
        self.assertTrue(instances[0].drained)
        instances[0].stop.set.assert_called_once()

    def test_partial_or_missing_capture_cannot_complete_a0_packet(self):
        partial = full_a0()
        partial[7] = dict(partial[7], capture_complete=False)
        self.assertFalse(job.a0_complete(partial))
        missing = full_a0()
        missing[3] = dict(missing[3], tps=None, valid=False)
        self.assertFalse(job.a0_complete(missing))
        missing.pop()
        self.assertFalse(job.a0_complete(missing))


if __name__ == "__main__":
    unittest.main()
