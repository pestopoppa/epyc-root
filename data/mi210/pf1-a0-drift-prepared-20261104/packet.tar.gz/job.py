#!/usr/bin/env python3
"""CPU-only A0 descriptive diagnostic derived from PF1-EXPAND.
Pinned source/store identity; model stat checks only. No crossover conclusion.
"""
import hashlib
import json
import math
import os
import signal
import statistics
import subprocess
import sys
import threading
import time
import re
from pathlib import Path

D = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(D, 'out')
RES = os.path.join(OUT, 'results.jsonl')
SUM = os.path.join(OUT, 'summary.json')
DONE = os.path.join(OUT, 'PILOT-COMPLETE.json')
IDENT = json.load(open(os.path.join(D, 'IDENTITY.json')))
CODE_ROOT = '/mnt/raid0/llm/worktrees/research-pin-pf1-expand-20261104'
CODE_SHA = '1dae4bac89a4a4d23051cf8cc8b97366f36173c8'
WRAP = CODE_ROOT + '/scripts/benchmark/bench_canonical.sh'
LINK = CODE_ROOT + '/scripts/utils/verify_ggml_linkage.sh'
SRC = '/mnt/raid0/llm/llama.cpp'
STORE = {'cpu': '/mnt/raid0/llm/kernels/builds/cpu-20261103-181483cfc-lbt/bin'}
HEAD = IDENT['kernel']['commit']
MODEL = IDENT['model']['load_path']
L_SET = (256, 384, 448, 512, 768)
BLOCKS = 3
REPS = 5
CAP_S = IDENT['cap']['pilot_wall_s']
KFD = '/sys/class/kfd/kfd/proc'
PLUMB = os.environ.get('FILLER_DRYRUN') == '1' or os.environ.get('FILLER_SMOKE') == '1'
STOPF = os.environ.get('FILLER_STOPFILE', os.path.join(D, 'STOP'))
DEADLINE = int(os.environ.get('FILLER_DEADLINE', str(int(time.time()) + 3600)))


def now(): return time.strftime('%FT%TZ', time.gmtime())


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''): h.update(chunk)
    return h.hexdigest()


def atomic(path, obj):
    with open(path + '.tmp', 'w') as f: json.dump(obj, f, indent=1, sort_keys=True)
    os.replace(path + '.tmp', path)


def append(unit):
    os.makedirs(OUT, exist_ok=True)
    with open(RES, 'a') as f:
        f.write(json.dumps(unit, sort_keys=True) + '\n'); f.flush(); os.fsync(f.fileno())


def identity_check():
    bad = []
    for args, expected in ((['rev-parse', 'HEAD'], CODE_SHA), (['status', '--porcelain', '--untracked-files=no'], '')):
        r = subprocess.run(['git', '-C', CODE_ROOT] + args, capture_output=True, text=True)
        if r.returncode or r.stdout.strip() != expected: bad.append('pinned source identity/cleanliness failed')
    st = STORE['cpu']; identity = IDENT['kernel']['stores']['cpu']
    if os.path.realpath(st) != identity['resolves_to']: bad.append('CPU store moved')
    for name, value in identity['files'].items():
        if sha(os.path.join(st, name)) != value['sha256']: bad.append('CPU digest changed: ' + name)
    r = subprocess.run(['bash', LINK, st + '/llama-bench', st], env=arm_env('A0')[0], capture_output=True, text=True)
    if r.returncode: bad.append('CPU linkage failed')
    for shard in IDENT['model']['shards']:
        stat = os.stat(shard['path'])
        if (stat.st_size, stat.st_mtime_ns, stat.st_ino) != (shard['size'], shard['mtime_ns'], shard['ino']): bad.append('model stat changed: ' + shard['path'])
    return bad


def proc_identity(pid):
    try:
        fields = open(f'/proc/{pid}/stat').read().rsplit(')', 1)[1].split()
        return int(fields[1]), int(fields[19]), fields[0]
    except (OSError, ValueError, IndexError): return None


class Sampler(threading.Thread):
    """Only captured descendants, matched by birth ticks; never global GPU use."""
    def __init__(self, pid):
        super().__init__(daemon=True)
        self.stop = threading.Event(); self.lock = threading.Lock()
        identity = proc_identity(pid)
        self.owned = {pid: identity[1]} if identity else {}
        self.maps = {}; self.kfd = {}; self.samples = 0; self.errors = []

    def capture(self):
        with self.lock:
            pending = list(self.owned)
            for pid in pending:
                ident = proc_identity(pid)
                if not ident or ident[1] != self.owned[pid]: continue
                try: children = open(f'/proc/{pid}/task/{pid}/children').read().split()
                except OSError: continue
                for child in children:
                    child = int(child); ci = proc_identity(child)
                    if ci and ci[0] == pid and child not in self.owned:
                        self.owned[child] = ci[1]; pending.append(child)
            return dict(self.owned)

    def sample(self):
        self.samples += 1
        for pid, birth in self.capture().items():
            ident = proc_identity(pid)
            if not ident or ident[1] != birth: continue
            if os.path.isdir(f'{KFD}/{pid}'): self.kfd[str(pid)] = birth
            try:
                libs = {line.split()[-1] for line in open(f'/proc/{pid}/maps') if 'libggml' in line}
                libs.update(self.maps.get(str(pid), {}).get('libs', []))
                if libs: self.maps[str(pid)] = {'birth_ticks': birth, 'libs': sorted(libs), 'real': sorted({os.path.realpath(x) for x in libs})}
            except OSError as exc:
                if proc_identity(pid): self.errors.append(str(exc))

    def run(self):
        while not self.stop.is_set():
            self.sample(); self.stop.wait(0.1)

    def terminate_owned(self):
        for sig, seconds in ((signal.SIGTERM, 20), (signal.SIGKILL, 10)):
            owned = self.capture()
            for pid, birth in reversed(list(owned.items())):
                ident = proc_identity(pid)
                if ident and ident[1] == birth and ident[2] != 'Z':
                    try: os.kill(pid, sig)
                    except ProcessLookupError: pass
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                alive = [pid for pid, birth in owned.items() if (ident := proc_identity(pid)) and ident[1] == birth and ident[2] != 'Z']
                if not alive: return
                time.sleep(0.1)
        raise RuntimeError(f'owned PIDs survived SIGKILL: {alive}')


def claim_record():
    return {'filler_id': os.environ.get('FILLER_ID'), 'filler_cpus': os.environ.get('FILLER_CPUS'),
            'engine_claim': 'filler_run15 --class cpu --role bench; CPU-only A0 diagnostic, inherited CPU claim'}


def arm_flags(arm, ub=None):
    if arm != 'A0': raise ValueError('only CPU A0 permitted')
    return ['-dev', 'none', '-ngl', '0', '--no-op-offload', '1']


def arm_env(arm):
    arm_flags(arm)
    env = {k: v for k, v in os.environ.items() if not k.startswith('GGML_')}
    env.update(LD_LIBRARY_PATH=STORE['cpu'] + ':/usr/lib/llvm-20/lib', CANONICAL_SKIP_REGION_LOCK='1')
    return env, STORE['cpu']


def parse(text, L):
    for match in re.finditer(r'\[\s*\{', text):
        try: rows, _ = json.JSONDecoder().raw_decode(text[match.start():])
        except ValueError: continue
        found = [r for r in rows if r.get('n_prompt') == L and r.get('n_gen') == 0]
        if len(found) == 1: return found[0]
    return None


def checks(u):
    real = [r for m in u.get('mapped_ggml', {}).values() for r in m['real']]
    samples = u.get('samples_ts') or []
    return {'rc0': u.get('rc') == 0 and not u.get('error'),
            'parsed': len(samples) == u.get('expected_reps', REPS) and all(isinstance(x, (int, float)) and math.isfinite(x) and x > 0 for x in samples),
            'build': u.get('build_number') == IDENT['kernel']['build_number'] and len(str(u.get('build_commit') or '')) >= 9 and HEAD.startswith(str(u.get('build_commit') or '!')),
            'residency_sampled': u.get('residency_samples', 0) >= 2 and not u.get('residency_errors'),
            'no_gpu_residency': not u.get('kfd_pids') and not any('libggml-hip' in r or 'libggml-cuda' in r for r in real),
            'mapped_store': bool(real) and all(r.startswith(IDENT['kernel']['stores']['cpu']['resolves_to'] + '/') for r in real)}


def placement_valid(logdir):
    try:
        text = Path(logdir, 'placement.log').read_text()
        reason = Path(logdir, 'placement.log.reason').read_text()
        share = re.search(r'max=node\d+@([\d.]+)%', text)
        coverage = re.search(r'coverage_pct=(\d+)', reason)
        return (int(Path(logdir, 'placement.log.rc').read_text()) == 0
                and bool(share) and float(share.group(1)) <= 40.0
                and bool(coverage) and int(coverage.group(1)) >= 90)
    except (OSError, ValueError):
        return False


def run_launch(Ls, argv, env, cdir, timeout_at, canonical=False):
    os.makedirs(cdir, exist_ok=True); raw = os.path.join(cdir, 'raw.log'); start = time.time(); error = None
    with open(raw, 'wb') as f:
        p = subprocess.Popen(argv, stdout=f, stderr=subprocess.STDOUT, env=env, cwd=D, start_new_session=True)
        sampler = Sampler(p.pid); sampler.start()
        try:
            while p.poll() is None:
                if os.path.exists(STOPF) or time.time() >= timeout_at:
                    error = 'stop' if os.path.exists(STOPF) else 'deadline'
                    sampler.terminate_owned(); break
                time.sleep(0.1)
            rc = p.wait()
        finally:
            try:
                sampler.terminate_owned()
            finally:
                sampler.stop.set(); sampler.join(5)
    text = open(raw, errors='replace').read(); wall = time.time() - start
    records = []
    for L in Ls:
        row = parse(text, L) or {}; ts = row.get('samples_ts') or []
        u = dict(row, arm='A0', L=L, rc=rc, error=error, argv=argv, env={'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH']},
                 raw_log=raw, expected_reps=REPS if canonical else 1, residency_samples=sampler.samples, residency_errors=sampler.errors,
                 kfd_pids=sampler.kfd, mapped_ggml=sampler.maps, claim=claim_record(),
                 tps=statistics.median(ts) if ts else None, launch_wall_s=wall, wall_s=wall / len(Ls), at=now())
        u['checks'] = checks(u)
        if canonical:
            ld = argv[argv.index('--log-dir') + 1]
            try:
                ci = json.load(open(os.path.join(ld, 'identity.json')))
                u['canonical_identity'] = ci
                u['checks']['store_identity'] = ci.get('kind') == 'kernel_store' and ci.get('library_path') == IDENT['kernel']['stores']['cpu']['resolves_to'] and ci.get('ggml_linkage') == 'PASS' and HEAD.startswith(str(ci.get('manifest_commit') or '!'))
                u['checks']['placement_proof'] = placement_valid(ld)
            except (OSError, ValueError): u['checks']['canonical_proof'] = False
        u['valid'] = all(u['checks'].values())
        u['capture_complete'] = bool(ts and u.get('build_commit') and u.get('build_number') and sampler.maps and sampler.samples >= 2)
        records.append(u)
    return records


def load_units():
    try: return [json.loads(line) for line in open(RES) if line.strip()]
    except OSError: return []


def a0_complete(units):
    planned = {(b, L) for b in range(BLOCKS) for L in L_SET}
    cells = [u for u in units if u.get('mode') == 'pilot']
    return len(cells) == len(planned) and {(u.get('block'), u.get('L')) for u in cells} == planned and all(u.get('arm') == 'A0' and u.get('valid') and u.get('capture_complete') for u in cells)


def summarize(units, reason=None):
    cells = [u for u in units if u.get('mode') == 'pilot']
    return {'complete': a0_complete(units), 'units_total': len(cells), 'units_valid': sum(bool(u.get('valid') and u.get('capture_complete')) for u in cells),
            'by_prompt': {str(L): [u['tps'] for u in cells if u.get('valid') and u['L'] == L] for L in L_SET},
            'stop_reason': reason, 'label': 'Descriptive CPU-only A0 diagnostic; no GPU comparison or crossover claim.'}


def plumbing():
    bad = identity_check()
    if bad: print(json.dumps({'identity_problems': bad}), flush=True); return 2
    cpus = sorted(os.sched_getaffinity(0))
    if len(cpus) != 4: raise RuntimeError(f'exactly four inherited CPUs required: {cpus}')
    path = os.environ.get('FILLER_DRYRUN_RESULT_PATH')
    dryenv = os.environ.get('FILLER_DRYRUN_DIR')
    dryroot = os.path.realpath(dryenv) if dryenv else ''
    if not path or not dryroot or os.path.commonpath((os.path.realpath(path), dryroot)) != dryroot:
        raise RuntimeError('result path must be inside isolated dry-run directory')
    env, st = arm_env('A0')
    argv = ['taskset', '-c', ','.join(map(str, cpus)), st + '/llama-bench', '-m', MODEL, '-p', '16', '-n', '0', '-r', '1', '-t', '4', '-fa', '1', '-mmp', '1', '-o', 'json'] + arm_flags('A0')
    u = run_launch((16,), argv, env, os.path.join(os.path.dirname(path), 'plumbing-cell'), min(DEADLINE, time.time() + 1200))[0]
    u.update(mode='plumbing', inherited_cpus=cpus)
    ok = u['valid'] and u['capture_complete'] and u.get('n_threads') == 4
    if ok: atomic(path, {'response': u['tps'], 'tps': u['tps'], 'backend': 'cpu', 'cpus': cpus, 'raw_log': u['raw_log']})
    print(json.dumps({'plumbing_ok': ok, 'checks': u['checks'], 'tps': u['tps']}), flush=True)
    return 0 if ok else 3


def pilot():
    bad = identity_check()
    if bad: print(json.dumps({'identity_problems': bad}), flush=True); return 2
    if os.path.exists(DONE): os.unlink(DONE)
    existing = [u for u in load_units() if u.get('mode') == 'pilot']
    # Resume whole valid launches across windows without duplicating any cell.
    keys = [(u.get('block'), u.get('L')) for u in existing]
    if len(keys) != len(set(keys)) or any(not u.get('valid') or not u.get('capture_complete') or u.get('arm') != 'A0' for u in existing):
        raise RuntimeError('existing pilot cells are duplicated or invalid; use a fresh diagnostic packet')
    for block in range(BLOCKS):
        prior = [u for u in existing if u.get('block') == block]
        if prior:
            if {u.get('L') for u in prior} != set(L_SET):
                raise RuntimeError('partial saved launch; use a fresh diagnostic packet')
            continue
        units = load_units(); used = sum(u.get('wall_s', 0) for u in units if u.get('mode') == 'pilot')
        if os.path.exists(STOPF) or time.time() >= DEADLINE or used >= CAP_S: break
        Ls = L_SET if block % 2 == 0 else tuple(reversed(L_SET))
        ld = os.path.join(OUT, 'cells', f'b{block}-A0', 'canonical')
        env, st = arm_env('A0')
        argv = ['bash', WRAP, '-m', MODEL, '-p', str(Ls[0]), '-n', '0', '-r', str(REPS), '--binary', st + '/llama-bench', '--source-root', SRC, '--library-path', st, '--log-dir', ld, '--', '-o', 'json'] + arm_flags('A0') + [x for L in Ls[1:] for x in ('-p', str(L))]
        records = run_launch(Ls, argv, env, os.path.dirname(ld), min(DEADLINE, time.time() + CAP_S - used), canonical=True)
        for u in records:
            u.update(mode='pilot', block=block, unit_id=f"b{block}-L{u['L']}-A0", launch_id=f'b{block}-A0'); append(u)
        atomic(SUM, summarize(load_units()))
        if not all(u['valid'] and u['capture_complete'] for u in records): break
    summary = summarize(load_units()); atomic(SUM, summary)
    if summary['complete']: atomic(DONE, summary)
    print(json.dumps(summary), flush=True)
    return 0 if summary['complete'] else 3


if __name__ == '__main__':
    def interrupt(signum, frame):
        raise SystemExit(128 + signum)
    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    os.makedirs(OUT, exist_ok=True)
    sys.exit(plumbing() if PLUMB else pilot())
