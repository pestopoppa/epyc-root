#!/usr/bin/env python3
"""Require the complete validated A0 frame, never just a marker."""
import json, sys
from pathlib import Path
import job
try:
    root=Path(__file__).resolve().parent
    marker=json.loads((root/'out/PILOT-COMPLETE.json').read_text())
    units=[json.loads(x) for x in (root/'out/results.jsonl').read_text().splitlines() if x.strip()]
    valid=job.a0_complete(units)
    if isinstance(valid,tuple): valid=valid[0]
    if not valid: raise ValueError('incomplete A0 frame')
except (OSError,ValueError,KeyError,TypeError):
    sys.exit(1)
