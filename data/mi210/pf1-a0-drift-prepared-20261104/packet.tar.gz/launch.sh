#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/mi210-independent-cpu-20261104
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id mi210-independent-cpu-20261104 --class cpu --claim-cpus 0-95 --role bench --min-window 3600 --cmd "/usr/bin/env PF1_ONLY_A0=1 /usr/bin/python3 -I $D/job.py" --complete-cmd "/usr/bin/python3 $D/complete.py" --stop "$D/STOP" --workdir "$D"
