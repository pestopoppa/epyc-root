# MI210 independent CPU diagnostic (prepared)

Derived from `/mnt/raid0/llm/tmp/pf1-expand-20261104/` real packet, reusing its pinned C6/lbt stores, model shard identity, research `bench_canonical.sh` source pin, NUMA placement sampler, linkage checks, and native result writer.

Scope: A0 CPU-only repeat at prompt lengths 256, 384, 448, 512, 768; three independent launches per length. This probes the A0 hot-bias that invalidated the 512-token control in PF1-EXPAND. It cannot establish a GPU crossover or a PF1 verdict.

Launcher claims CPU 0-95 only. No model run, publication, or handoff edit was performed during preparation. The canonical row is published; its actual four-CPU A0 native smoke passed. The full diagnostic has not yet run.

The r2 pilot observed an A0 decline of roughly 9–17% between two launches, against roughly 5–9% paired noise. Three fresh CPU launches can describe repeatability and placement; they cannot identify the cause or decide a GPU crossover. Full completion requires all 15 valid source-bound cell records. The smoke is a four-CPU real A0 native entry only; it is excluded from the full-run denominator.
