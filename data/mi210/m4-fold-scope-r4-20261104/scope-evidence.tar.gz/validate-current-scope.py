#!/usr/bin/env python3
"""Model-free current-source scope and candidate-spec validation; no admission authority."""
import hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
import yaml
OUT=Path(__file__).resolve().parent
ORCH=Path('/workspace/repos/epyc-orchestrator')
ROOT=Path('/mnt/raid0/llm/worktrees/mains/h-fable5-window2-findings-05c-mi210-lever')
SOURCE=Path('/mnt/raid0/llm/tmp/m4-fold-spec-20261104/ready-final/FOLD-SPEC.json')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def loadmod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
priors=yaml.safe_load((OUT/'stack_priors.yaml').read_text())
checker=ORCH/'scripts/validate/kernel_freeze_scope.py'
derived=json.loads(subprocess.check_output([sys.executable,str(checker),'--priors',str(OUT/'stack_priors.yaml'),'--json'],text=True))
scopes={b:derived[b] for b in ('cpu','gpu')}
resolver=ROOT/'scripts/champion/m4/resolve_scope.py'
r=loadmod('resolver',resolver).resolve(ORCH,scopes,priors,yaml.safe_load((ORCH/'orchestration/model_registry.yaml').read_text()),derived)
assert r['status']=='SOURCE_BOUND_ONLY' and not r['errors'],r['errors']
(OUT/'resolve.json').write_text(json.dumps(r,indent=2,sort_keys=True,default=str)+'\n')
spec=json.loads(SOURCE.read_text()); coverage=[]
for entry in spec['roles']:
 rows=[row for row in r['roles'] if row['primary']==entry['role']]
 assert rows,entry['role']
 assert set(entry['served_roles'])=={row['role'] for row in rows},entry['role']
 assert all(row['backend']==entry['backend'] and row['model_path']==entry['model'] for row in rows)
 coverage.append({'primary':entry['role'],'backend':entry['backend'],'logical_roles':sorted(entry['served_roles']),'model':entry['model']})
assert {x['role'] for x in spec['roles']}=={x['primary'] for x in r['roles']}
(OUT/'FOLD-SPEC.json').write_bytes(SOURCE.read_bytes())
original=yaml.safe_load((ORCH/'orchestration/derived/stack_priors.yaml').read_text())
report={'status':'CURRENT_SOURCE_SCOPE_VALIDATED_CANDIDATE_SPEC_ONLY','admission_authorized':False,'orchestrator_head':subprocess.check_output(['git','-C',str(ORCH),'rev-parse','HEAD'],text=True).strip(),'orchestrator_registry_dirty':True,'scope_checker_sha256':sha(checker),'resolver_sha256':sha(resolver),'compiled_priors_sha256':sha(OUT/'stack_priors.yaml'),'spec_sha256':sha(OUT/'FOLD-SPEC.json'),'spec_unchanged_from_ready_final':True,'source_artifacts':priors['source_artifacts'],'changed_pin_hashes':[k for k in priors['source_artifacts'] if priors['source_artifacts'][k]['sha256']!=original['source_artifacts'][k]['sha256']],'logical_role_count':len(r['roles']),'physical_role_count':len(coverage),'coverage':coverage,'independent_guard':'PASS strict --numa-mode full --skip-hardcoded-surface-scan; default mode fails 8 frontdoor full-vs-both port/entry checks','remaining_blockers':['Both spec entries name generic fold_entry.py, not enrolled m4_gpu_speed/launcher.py V2 writer/reader or m4_cpu_recipe_entry.py. Its docstring explicitly bypasses these backend entries; imports only generic server_np_sweep for GPU measurement.','CPU greedy output capture/identity exists, but current-role model/build/recipe packet evidence and owner-absent independent CPU evidence replay are not qualified by this model-free scope check.','Existing ready-final plan bind is historical evidence; this task did not rerun model/image digest binding or inference.']}
(OUT/'SCOPE-VALIDATION.json').write_text(json.dumps(report,indent=2,sort_keys=True,default=str)+'\n')
print(json.dumps({k:report[k] for k in ('status','logical_role_count','physical_role_count','spec_sha256','changed_pin_hashes')},indent=2))
