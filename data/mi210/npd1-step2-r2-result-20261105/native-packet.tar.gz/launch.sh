#!/bin/bash
# NPD-1 step 2 (owner mi210-serving-program.md). Whole host + idle MI210; four sequential server launches (ABBA).
set -euo pipefail
D=/mnt/raid0/llm/tmp/npd1-step2-a1-tpot-20261104
cd "$D"
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id npd1-step2-a1-tpot-r2-20261104 \
  --class cpu+gpu --gpu-quiet exclusive --claim-cpus 0-95 --role bench --min-window 3000 \
  --cmd "/usr/bin/python3 -I $D/job.py" \
  --complete-cmd "test -s $D/out/PILOT-COMPLETE.json" \
  --stop "$D/STOP" --workdir "$D"
