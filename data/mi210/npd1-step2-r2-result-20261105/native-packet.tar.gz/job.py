#!/usr/bin/env python3
"""NPD-1 step 2: decode interference under one long-prompt arrival, A0 (CPU-only, today) vs A1 (op-offload).
Model Q38FN UD-IQ4_XS + MTP head, champion candidate 181483cfc-lbt stores, INF22-Q38-T48 bundle in both arms.
ABBA x 2 pairs = 4 launches: A0 A1 A1 A0. Per launch: stream B idle baseline, then for L in (8192, 32768):
B starts decoding, after 3 s the long prompt arrives in slot 2; per-token arrival times of B are streamed.
Only this job's own child PIDs are signalled."""
import json, os, signal, subprocess, threading, time, urllib.request

D = "/mnt/raid0/llm/tmp/npd1-step2-a1-tpot-20261104"
OUT = f"{D}/out"
CPU = "/mnt/raid0/llm/kernels/builds/cpu-20261103-181483cfc-lbt"
GPU = "/mnt/raid0/llm/kernels/builds/gpu-20261103-181483cfc-lbt"
MODEL = "/mnt/raid0/llm/models/unsloth/Qwen3.8-Flash-Next-GGUF/UD-IQ4_XS/Qwen3.8-Flash-Next-UD-IQ4_XS-00001-of-00003.gguf"
MTP = "/mnt/raid0/llm/models/unsloth/Qwen3.8-Flash-Next-GGUF/MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf"
PORT = 18932
LS = [8192, 32768]
B_TOKENS = 512
ARRIVAL_DELAY_S = 3.0
ORDER = [("p1", "A0"), ("p1", "A1"), ("p2", "A1"), ("p2", "A0")]  # ABBA
# Shared by both arms: today's served recipe (qwen38_flash_next_recipe.py, t48 bundle) at np2.
COMMON = ["-m", MODEL, "-md", MTP, "--spec-type", "draft-mtp", "--spec-draft-n-max", "4", "--spec-draft-p-min", "0.5",
          "-np", "2", "-c", "69632", "-t", "48", "--no-mmap", "-fa", "on", "-ctk", "f16", "-ctv", "f16",
          "--load-threads", "96", "--no-webui", "--host", "127.0.0.1", "--port", str(PORT)]
ENV = {"GGML_FUSED_DECODE_OFF": "1", "GGML_NOHUGEPAGE_PROCESS": "1", "GGML_FA_SPLIT_KV": "0"}
ARMS = {
    "A0": (CPU, ["-dev", "none", "-ngl", "0"]),   # today: CPU-only, default -b/-ub
    "A1": (GPU, ["-ngl", "0", "-ub", "2048", "-b", "2048"]),  # op-offload: GPU prefill, CPU decode, one process
}
B_PROMPT = ("Write a detailed, step-by-step technical explanation of how a B-tree handles insertion, deletion and "
            "node splitting, with a worked example. ")


def log(rec):
    rec["t"] = time.time()
    with open(f"{OUT}/results.jsonl", "a") as f:
        f.write(json.dumps(rec) + "\n")


def stop():
    return os.path.exists(f"{D}/STOP")


def post(path, body, timeout=3600):
    r = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=json.dumps(body).encode(),
                               headers={"Content-Type": "application/json"})
    return urllib.request.urlopen(r, timeout=timeout)


def health():
    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=5) as h:
        return json.load(h).get("status") == "ok"


def start(arm):
    store, extra = ARMS[arm]
    env = dict(os.environ, LD_LIBRARY_PATH=f"{store}/bin", **ENV)
    logf = open(f"{OUT}/server-{arm}.log", "a")
    p = subprocess.Popen(["taskset", "-c", "0-95", "numactl", "--interleave=all", f"{store}/bin/llama-server"]
                         + COMMON + extra, stdout=logf, stderr=subprocess.STDOUT, env=env)
    t0 = time.time()
    while time.time() - t0 < 900:
        if p.poll() is not None:
            raise SystemExit(f"{arm} server exited rc={p.returncode}")
        try:
            if health():
                return p, time.time() - t0
        except Exception:
            time.sleep(2)
    kill(p)
    raise SystemExit(f"{arm} load timeout")


def kill(p):
    p.send_signal(signal.SIGTERM)
    try:
        p.wait(60)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait(30)
    assert p.poll() is not None


def kfd_own(pid):
    try:
        return str(pid) in os.listdir("/sys/class/kfd/kfd/proc")
    except Exception:
        return None


def stream_b(stamps):
    """Stream B: greedy, fixed length; record wall time of every streamed chunk (one per accepted token batch)."""
    body = {"prompt": B_PROMPT, "n_predict": B_TOKENS, "temperature": 0, "top_k": 1, "ignore_eos": True,
            "stream": True, "cache_prompt": False, "id_slot": 0}
    with post("/completion", body) as h:
        for line in h:
            if line.startswith(b"data: "):
                d = json.loads(line[6:])
                stamps.append((time.time(), len(d.get("tokens", [])) or 1))
                if d.get("stop"):
                    stamps.append(("timings", d.get("timings", {})))


def long_prompt(L, res):
    t0 = time.time()
    with post("/completion", {"prompt": [1000 + (i * 7919) % 50000 for i in range(L)], "n_predict": 1,
                              "temperature": 0, "cache_prompt": False, "id_slot": 1}) as h:
        d = json.load(h)
    res.update(ttft_s=time.time() - t0, t_start=t0, t_end=time.time(), timings=d.get("timings", {}))


def summarize(stamps, win=None):
    ts = [s for s in stamps if s[0] != "timings"]
    toks = sum(n for _, n in ts)
    span = ts[-1][0] - ts[0][0] if len(ts) > 1 else None
    out = {"b_tokens": toks, "b_wall_s": span, "b_tpot_ms": 1000 * span / max(toks - 1, 1) if span else None}
    if win:
        inw = [(t, n) for t, n in ts if win[0] <= t <= win[1]]
        out["b_tokens_in_window"] = sum(n for _, n in inw)
        out["window_s"] = win[1] - win[0]
        out["b_tpot_in_window_ms"] = (1000 * out["window_s"] / out["b_tokens_in_window"]
                                      if out["b_tokens_in_window"] else None)
        gaps = [b[0] - a[0] for a, b in zip(ts, ts[1:])]
        out["b_max_gap_s"] = max(gaps) if gaps else None
    return out


TTFT = {}
for i, (pair, arm) in enumerate(ORDER):
    if i == 2 and all(TTFT.get(("A0", L), 0) / max(TTFT.get(("A1", L), 1e9), 1e-9) < 1.2 for L in LS):
        log({"phase": "STOP_ANSWER", "reason": "pair 1 TTFT gain < 1.2 at every L: reject A1"})
        break
    if stop():
        log({"phase": "STOP"})
        break
    p, load_s = start(arm)
    try:
        log({"phase": "load", "pair": pair, "arm": arm, "s": load_s, "kfd_own_pid": kfd_own(p.pid)})
        # warm-up + idle baseline
        stream_b([])
        idle = []
        stream_b(idle)
        base = summarize(idle)
        log({"phase": "idle", "pair": pair, "arm": arm, **base})
        for L in LS:
            stamps, res = [], {}
            tb = threading.Thread(target=stream_b, args=(stamps,))
            tb.start()
            time.sleep(ARRIVAL_DELAY_S)
            tl = threading.Thread(target=long_prompt, args=(L, res))
            tl.start()
            time.sleep(1.0)
            kfd_mid = kfd_own(p.pid)
            tl.join()
            tb.join()
            s = summarize(stamps, (res["t_start"], res["t_end"]))
            rec = {"phase": "contended", "pair": pair, "arm": arm, "L": L, "ttft_long_s": res["ttft_s"],
                   "long_prompt_ms": res["timings"].get("prompt_ms"), "kfd_own_pid_during_prefill": kfd_mid,
                   "b_idle_tpot_ms": base["b_tpot_ms"], **s}
            if s.get("b_tpot_in_window_ms") and base["b_tpot_ms"]:
                rec["tpot_inflation"] = s["b_tpot_in_window_ms"] / base["b_tpot_ms"]
            log(rec)
            TTFT[(arm, L)] = res["ttft_s"]
            if arm == "A1" and not kfd_mid:
                log({"phase": "STOP_FUTILITY", "reason": "A1 without own-PID KFD residency during prefill"})
                raise SystemExit(3)
    finally:
        kill(p)

with open(f"{OUT}/PILOT-COMPLETE.json", "w") as f:
    json.dump({"complete": True, "order": ORDER}, f)
