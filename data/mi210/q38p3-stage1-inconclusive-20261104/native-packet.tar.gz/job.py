#!/usr/bin/env python3
"""Q38P-3 stage 1 (mi210-serving-program.md Q38P-3): champion c72ec82f5 on ROCm 6.2 (C) vs the same commit built against the
isolated ROCm 10.1.0 tarball (B) vs B + HSA_NO_SCRATCH_RECLAIM=1 (Bp), same MI210 window, interleaved launches.

Unit of analysis = one arm LAUNCH:
  (1) llama-server, 27B Q8 + DFlash2 drafter, np 1, ctx 65536, production :8083 argv shape on an own port (18931),
      --load-threads 8; 3 greedy parity prompts (n_predict 64) + 5 decode prompts (n_predict 256, temperature 0);
      decode metric = median timings.predicted_per_second over the 5 decode prompts (speculative decoding ON = serving gate).
  (2) llama-bench, same build: pp512 and pp2048 at depth 0, plus pp512 at depth 16384 (FA-heavy), -fa 1 -ngl 99,
      -ctk/-ctv q8_0, 3 reps; prefill metric = median t/s per test.
Launch validity: rc 0; our own process on KFD with own VRAM > 20 GiB sampled DURING; no foreign KFD pid; the mapped
libggml-hip sha256 equals the arm's and libamdhip64 resolves under the arm's HIP prefix (linkage proof); greedy parity vs
the C launch of the same pair: INVALID only if < 64 common chars on >= 2 of 3 prompts (gross corruption), exact-match
rate reported.
Pairs: 5 blocks; block order C,B,Bp then Bp,B,C alternating. Per-block ratio arm/C.
Gate (stage-1 decision support; the binding gate is Stage 2 in the v11 window): KEEP-CANDIDATE if for B or Bp the median
block ratio of decode >= 1.05 AND pp512 and pp2048 (depth 0) median ratios >= 0.98, with >= 3 valid blocks; else NO-GO.
Futility: after 3 valid blocks, if every block's decode ratio is < 1.02 for both B and Bp -> stop (decode bar unreachable).
Prefill and FA (depth 16384) deltas are ALWAYS reported descriptively, gate pass or not.
Refuses (exit 2) unless the window probe RESULT.json verdict is PASS. Smoke mode (FILLER_DRYRUN/SMOKE, keeper holds mi210_0 + 184-191):
one real C-arm llama-bench pp512 rep as the first measured record, then the no-GPU checks; the dependency is NOT enforced in smoke."""
import hashlib, json, os, socket, statistics, subprocess, sys, time, urllib.request
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D)
import gpuproof as gp

OUT = os.path.join(D, 'out'); RES = os.path.join(OUT, 'results.jsonl'); SUM = os.path.join(OUT, 'summary.json')
DONE = os.path.join(OUT, 'STAGE1-COMPLETE.json')
IDENT = json.load(open(os.path.join(D, 'IDENTITY.json'))); ARMS = IDENT['arms']; G = IDENT['gate']
STOPF = os.environ.get('FILLER_STOPFILE', os.path.join(D, 'STOP'))
DEADLINE = int(os.environ.get('FILLER_DEADLINE', str(int(time.time()) + 5400)))
PLUMB = os.environ.get('FILLER_DRYRUN') == '1' or os.environ.get('FILLER_SMOKE') == '1'
PORT = 18931; HOST = '127.0.0.1'; CPUS = os.environ.get('Q38P3_CPUS', '184-191')
LAUNCH_NEED_S = 420; OWN_VRAM_MIN = 20 * 1024**3
DROP = ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES', 'HSA_NO_SCRATCH_RECLAIM')
PARITY = ["Explain in two sentences what a hash table is.", "Write a Python function that reverses a linked list.",
          "List three causes of the French Revolution."]
DECODE = ["Write a detailed explanation of how TCP congestion control works, covering slow start and congestion avoidance.",
          "Implement a thread-safe LRU cache in C++ with get and put methods, and explain the design.",
          "Summarize the main ideas of the theory of evolution by natural selection for a high-school student.",
          "Write a bash script that finds the ten largest files under a directory and prints their sizes.",
          "Describe the differences between supervised, unsupervised and reinforcement learning with examples."]
BENCH = [('pp512', 512, 0), ('pp2048', 2048, 0), ('pp512@d16384', 512, 16384)]


def now(): return time.strftime('%FT%TZ', time.gmtime())
def append(u):
    with open(RES, 'a') as f: f.write(json.dumps(u) + '\n'); f.flush(); os.fsync(f.fileno())
def atomic(p, o):
    t = p + '.tmp'; json.dump(o, open(t, 'w'), indent=1); os.replace(t, p)
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 24), b''): h.update(b)
    return h.hexdigest()
def med(x): return statistics.median(x) if x else None


def gate_dependency():
    p = IDENT['depends_on']['result']
    try: v = json.load(open(p)).get('verdict')
    except (OSError, ValueError): v = None
    return v == 'PASS', v


def arm_env(arm):
    a = ARMS[arm]; e = {k: v for k, v in os.environ.items() if k not in DROP}
    e['LD_LIBRARY_PATH'] = a['ld']; e.update(a['env']); return e


def server_argv(arm):
    a = ARMS[arm]
    return ['taskset', '-c', CPUS, a['bin'] + '/llama-server', '-m', IDENT['model'], '--host', HOST, '--port', str(PORT),
            '-np', '1', '-c', '65536', '-t', '8', '--load-threads', '8', '-b', '512', '-ub', '512', '--flash-attn', 'on', '--jinja',
            '-ctk', 'q8_0', '-ctv', 'q8_0', '--kv-unified', '--no-mmap', '-ngl', 'all', '--ctx-checkpoints', '32',
            '--chat-template-file', IDENT['chat_template'], '--no-cache-idle-slots', '-md', IDENT['draft'], '-ngld', '99',
            '--spec-type', 'draft-dflash', '--spec-draft-n-max', '7', '--device', 'ROCm0', '--device-draft', 'ROCm0']


def bench_argv(arm):
    a = ARMS[arm]
    return ['taskset', '-c', CPUS, a['bin'] + '/llama-bench', '-m', IDENT['model'], '-ngl', '99', '-fa', '1', '-ctk', 'q8_0',
            '-ctv', 'q8_0', '-b', '512', '-ub', '512', '-t', '8', '-mmp', '0', '-p', '512,2048', '-n', '0', '-d', '0,16384',
            '-r', '3', '-o', 'json']


def http(path, body=None, timeout=600):
    req = urllib.request.Request(f'http://{HOST}:{PORT}{path}', data=json.dumps(body).encode() if body else None,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as r: return json.loads(r.read())


def port_free():
    s = socket.socket()
    try: s.bind((HOST, PORT)); return True
    except OSError: return False
    finally: s.close()


def linkage(proof, arm):
    a = ARMS[arm]; ok = False; seen = []
    for m in proof['maps'].values():
        hip = [l for l in m['libs'] if 'libggml-hip' in l]; rt = [l for l in m['libs'] if 'libamdhip64' in l]
        seen.append({'hip': hip, 'amdhip': rt})
        if hip and all(sha(h) == a['libggml_hip_sha256'] for h in hip) and rt and all(r.startswith(os.path.realpath(a['hip_prefix'])) for r in rt):
            ok = True
    return ok, seen


def serve_phase(arm, cdir, timeout_at):
    """llama-server launch; a client thread issues the requests while gp.run_sampled samples the server; the server is stopped (own session) when the client is done or STOP appears."""
    import threading
    results = {'parity': [], 'decode': [], 'errors': []}
    def client():
        t_end = timeout_at
        while time.time() < t_end:
            try:
                if http('/health', timeout=5).get('status') == 'ok': break
            except Exception: pass
            time.sleep(2)
        else:
            results['errors'].append('health timeout'); return
        try:
            for p in PARITY:
                r = http('/completion', {'prompt': p, 'n_predict': 64, 'temperature': 0, 'top_k': 1, 'seed': 0, 'cache_prompt': False})
                results['parity'].append(r.get('content', ''))
            for p in DECODE:
                r = http('/completion', {'prompt': p, 'n_predict': 256, 'temperature': 0, 'top_k': 1, 'seed': 0, 'cache_prompt': False})
                t = r.get('timings') or {}
                results['decode'].append({'predicted_per_second': t.get('predicted_per_second'), 'prompt_per_second': t.get('prompt_per_second'),
                                          'predicted_n': t.get('predicted_n'), 'draft_n': t.get('draft_n'), 'draft_n_accepted': t.get('draft_n_accepted')})
        except Exception as e:
            results['errors'].append(repr(e))
        finally:
            open(os.path.join(cdir, 'client.done'), 'w').write(now())
    if not port_free(): return {'error': f'port {PORT} busy'}
    th = threading.Thread(target=client, daemon=True); th.start()
    # watchdog: the server never exits by itself; stop it (own session only) when the client is done
    done = os.path.join(cdir, 'client.done')
    stop_cond = os.path.join(cdir, 'STOP-SERVER')
    def watcher():
        while not os.path.exists(done) and not os.path.exists(STOPF) and time.time() < timeout_at: time.sleep(1)
        open(stop_cond, 'w').write('client done or STOP')
    threading.Thread(target=watcher, daemon=True).start()
    rc, err, proof = gp.run_sampled(server_argv(arm), os.path.join(cdir, 'server.log'), env=arm_env(arm), timeout_at=timeout_at,
                                    stopfile=stop_cond)
    if os.path.exists(STOPF): err = 'stop'
    elif err == 'stop': err = None   # our own client-done stop is the normal end of a server launch
    th.join(10)
    return {'rc': rc, 'error': err, 'proof': proof, **results}


def bench_phase(arm, cdir, timeout_at):
    rc, err, proof = gp.run_sampled(bench_argv(arm), os.path.join(cdir, 'bench.json'), env=arm_env(arm), timeout_at=timeout_at,
                                    stopfile=STOPF, errlog=os.path.join(cdir, 'bench.stderr.log'))
    tps = {}
    try:
        for row in json.load(open(os.path.join(cdir, 'bench.json'))):
            for name, p, d in BENCH:
                if row.get('n_prompt') == p and row.get('n_gen') == 0 and row.get('n_depth', 0) == d:
                    tps[name] = med([x for x in row.get('samples_ts') or [] if x]) or row.get('avg_ts')
    except (OSError, ValueError, TypeError) as e:
        tps['_parse_error'] = repr(e)
    return {'rc': rc, 'error': err, 'proof': proof, 'tps': tps}


def common_prefix(a, b):
    k = 0
    while k < min(len(a), len(b)) and a[k] == b[k]: k += 1
    return k


def run_launch(arm, block, ref_parity):
    lid = f'b{block}-{arm}'; cdir = os.path.join(OUT, 'cells', lid); os.makedirs(cdir, exist_ok=True); t0 = time.time()
    tl = min(DEADLINE - 60, time.time() + 1200)
    s = serve_phase(arm, cdir, tl)
    b = bench_phase(arm, cdir, min(DEADLINE - 60, time.time() + 900)) if not s.get('error') and not os.path.exists(STOPF) else None
    u = {'unit_id': lid, 'arm': arm, 'block': block, 'at': now(), 'wall_s': round(time.time() - t0, 1), 'serve': s, 'bench': b,
         'server_argv': server_argv(arm), 'bench_argv': bench_argv(arm), 'env_extra': ARMS[arm]['env'], 'ld': ARMS[arm]['ld']}
    dec = [x['predicted_per_second'] for x in s.get('decode', []) if x.get('predicted_per_second')]
    u['decode_tps'] = med(dec); u['prefill_tps'] = (b or {}).get('tps', {})
    chk = {}
    for ph, r in (('serve', s), ('bench', b)):
        if not r or 'proof' not in r: chk[ph + '_ran'] = False; continue
        pr = r['proof']; own = max(pr['kfd_pids_ours'].values(), default=0)
        chk[ph + '_rc0'] = r['rc'] in (0, -15) and not r.get('error') and (ph != 'serve' or not s.get('errors'))
        chk[ph + '_own_residency'] = own >= OWN_VRAM_MIN
        chk[ph + '_no_foreign_kfd'] = not pr['kfd_foreign']
        chk[ph + '_linkage'], u[ph + '_linkage_seen'] = linkage(pr, arm)
    chk['decode_n'] = len(dec) == len(DECODE)
    chk['prefill_n'] = all(k in u['prefill_tps'] for k, _, _ in BENCH)
    par = s.get('parity', [])
    if ref_parity is not None and arm != 'C':
        cps = [common_prefix(a, b2) for a, b2 in zip(par, ref_parity)]
        u['parity_common_prefix'] = cps; u['parity_exact'] = sum(a == b2 for a, b2 in zip(par, ref_parity))
        chk['parity_not_gross'] = len(cps) == len(PARITY) and sum(c < 64 for c in cps) < 2
    u['parity_text'] = par
    u['checks'] = chk; u['valid'] = all(chk.values())
    append(u)
    print(f"{lid} decode={u['decode_tps']} prefill={u['prefill_tps']} valid={u['valid']} wall={u['wall_s']}", flush=True)
    return u


def load_units():
    try: return [u for u in (json.loads(l) for l in open(RES) if l.strip() and '"arm"' in l) if u.get('mode') != 'smoke']
    except OSError: return []


def summarize(units, stop_reason=None):
    by = {}
    for u in units: by.setdefault(u['block'], {})[u['arm']] = u
    ratios = {a: {'decode': [], 'pp512': [], 'pp2048': [], 'pp512@d16384': []} for a in ('B', 'Bp')}
    valid_blocks = 0
    for blk, arms in sorted(by.items()):
        c = arms.get('C')
        if not c or not c['valid']: continue
        valid_blocks += 1
        for a in ('B', 'Bp'):
            x = arms.get(a)
            if not x or not x['valid']: continue
            if x['decode_tps'] and c['decode_tps']: ratios[a]['decode'].append(x['decode_tps'] / c['decode_tps'])
            for k in ('pp512', 'pp2048', 'pp512@d16384'):
                if x['prefill_tps'].get(k) and c['prefill_tps'].get(k): ratios[a][k].append(x['prefill_tps'][k] / c['prefill_tps'][k])
    medr = {a: {k: med(v) for k, v in r.items()} for a, r in ratios.items()}
    keep = [a for a in ('B', 'Bp') if len(ratios[a]['decode']) >= 3 and medr[a]['decode'] and medr[a]['decode'] >= G['decode_min_ratio']
            and (medr[a]['pp512'] or 0) >= G['prefill_min_ratio'] and (medr[a]['pp2048'] or 0) >= G['prefill_min_ratio']]
    dec = 'KEEP-CANDIDATE' if keep else ('NO-GO' if valid_blocks >= 3 else 'INCONCLUSIVE')
    return {'at': now(), 'decision_suggestion': dec, 'keep_arms': keep, 'stop_reason': stop_reason, 'valid_blocks': valid_blocks,
            'median_ratio_vs_C': medr, 'per_block_ratios': ratios,
            'abs_medians': {a: {'decode_tps': med([u['decode_tps'] for u in units if u['arm'] == a and u['valid'] and u['decode_tps']]),
                                **{k: med([u['prefill_tps'].get(k) for u in units if u['arm'] == a and u['valid'] and u['prefill_tps'].get(k)])
                                   for k, _, _ in BENCH}} for a in ARMS},
            'descriptive_note': 'prefill and pp512@d16384 (FA at depth) ratios are reported regardless of the decode gate',
            'units': len(units), 'identity_sha256': sha(os.path.join(D, 'IDENTITY.json'))}


def futile(units):
    s = summarize(units)
    if s['valid_blocks'] < G['futility_after_pairs']: return None
    r = s['per_block_ratios']
    if all(r[a]['decode'] and max(r[a]['decode']) < G['futility_decode_ratio'] for a in ('B', 'Bp')):
        return f"futility: after {s['valid_blocks']} valid blocks every decode ratio < {G['futility_decode_ratio']} for B and Bp"
    return None


def smoke_unit():
    """Smoke contract (rowflow): the first record must be a real measurement. The keeper's smoke holds mi210_0 + 184-191:
    one C-arm llama-bench pp512 rep (depth 0) with residency + linkage proof."""
    cdir = os.path.join(OUT, 'smoke'); os.makedirs(cdir, exist_ok=True)
    a = ARMS['C']
    argv = ['taskset', '-c', CPUS, a['bin'] + '/llama-bench', '-m', IDENT['model'], '-ngl', '99', '-fa', '1', '-ctk', 'q8_0', '-ctv', 'q8_0',
            '-b', '512', '-ub', '512', '-t', '8', '-mmp', '0', '-p', '512', '-n', '0', '-r', '30', '-o', 'json']
    t0 = time.time()
    rc, err, proof = gp.run_sampled(argv, os.path.join(cdir, 'bench.json'), env=arm_env('C'), timeout_at=min(DEADLINE - 30, time.time() + 600),
                                    stopfile=STOPF, errlog=os.path.join(cdir, 'bench.stderr.log'))
    tps = None
    try:
        row = json.load(open(os.path.join(cdir, 'bench.json')))[0]; tps = med([x for x in row.get('samples_ts') or [] if x]) or row.get('avg_ts')
    except (OSError, ValueError, TypeError, IndexError): pass
    own = max(proof['kfd_pids_ours'].values(), default=0); lk, seen = linkage(proof, 'C')
    u = {'unit_id': f'smoke-C-pp512-{now()}', 'mode': 'smoke', 'arm': 'C', 'at': now(), 'argv': argv, 'error': err, 'rc': rc,
         'tps_pp512': tps, 'vram_peak_gib': round(own / 1024**3, 3), 'measured_s': round(time.time() - t0, 1),
         'kfd_own_pid_count': len(proof['kfd_pids_ours']), 'kfd_foreign_pid_count': len(proof['kfd_foreign']),
         'linkage_pass': lk, 'linkage_seen': seen, 'proof': proof,
         'note': 'smoke unit, one rep; never enters the stage-1 analysis'}
    u['valid_smoke'] = rc == 0 and err is None and bool(tps) and own >= OWN_VRAM_MIN and lk and not proof['kfd_foreign']
    append(u); print(f"smoke C pp512 tps={tps} own_vram_gib={u['vram_peak_gib']} linkage={lk} valid={u['valid_smoke']}", flush=True)
    return u


def plumbing():
    sm = smoke_unit()
    ok_dep, v = gate_dependency(); bad = [] if sm['valid_smoke'] else ['smoke C-arm pp512 unit invalid']
    for a, x in ARMS.items():
        for f in ('llama-server', 'llama-bench', 'libggml-hip.so.0.16.0'):
            if not os.path.exists(os.path.join(x['bin'], f)): bad.append(f'{a} missing {f}')
        h = os.path.join(x['bin'], 'libggml-hip.so.0.16.0')
        if os.path.exists(h) and sha(h) != x['libggml_hip_sha256']: bad.append(f'{a} libggml-hip sha mismatch')
    for p in (IDENT['model'], IDENT['draft'], IDENT['chat_template']):
        if not os.path.exists(p): bad.append('missing ' + p)
    if not port_free(): bad.append(f'port {PORT} busy')
    u = {'unit_id': f'plumbing-{now()}', 'mode': 'plumbing', 'at': now(), 'problems': bad, 'dependency_verdict': v,
         'note': 'plumbing only, no GPU touched; dependency PASS is enforced at run time, not here'}
    append(u); print(json.dumps({'plumbing_ok': not bad, 'problems': bad, 'dependency': v}), flush=True)
    return 0 if not bad else 3


def main():
    ok_dep, v = gate_dependency()
    if not ok_dep:
        print(f'REFUSED: window probe verdict is {v!r}, not PASS', flush=True); return 2
    stop_reason = None
    for blk in range(G['pairs']):
        order = ['C', 'B', 'Bp'] if blk % 2 == 0 else ['Bp', 'B', 'C']
        done = {u['unit_id']: u for u in load_units()}
        ref = None
        for arm in order:
            lid = f'b{blk}-{arm}'
            if lid in done and done[lid]['valid']: continue
            if os.path.exists(STOPF): print('STOP file', flush=True); return 75
            if time.time() + LAUNCH_NEED_S > DEADLINE: print('window deadline: resume later', flush=True); return 75
            cref = done.get(f'b{blk}-C')
            ref = cref['parity_text'] if cref else None
            u = run_launch(arm, blk, ref if arm != 'C' else None)
            done[lid] = u
        # blocks that start with Bp/B have no C reference yet at launch time: back-fill parity against this block's C
        c = done.get(f'b{blk}-C')
        if c and blk % 2 == 1:
            units = load_units()
            for u in units:
                if u['block'] == blk and u['arm'] != 'C' and 'parity_common_prefix' not in u:
                    cps = [common_prefix(a, b2) for a, b2 in zip(u['parity_text'], c['parity_text'])]
                    u['parity_common_prefix'] = cps; u['parity_exact'] = sum(a == b2 for a, b2 in zip(u['parity_text'], c['parity_text']))
                    u['checks']['parity_not_gross'] = len(cps) == len(PARITY) and sum(x < 64 for x in cps) < 2
                    u['valid'] = all(u['checks'].values()); u['backfilled_parity'] = True; append(u)
        atomic(SUM, summarize(latest(load_units())))
        stop_reason = futile(latest(load_units()))
        if stop_reason: break
    s = summarize(latest(load_units()), stop_reason or 'complete: all planned blocks attempted')
    atomic(SUM, s); atomic(DONE, s)
    print(json.dumps({k: s[k] for k in ('decision_suggestion', 'valid_blocks', 'median_ratio_vs_C', 'stop_reason')}), flush=True)
    return 0


def latest(units):
    last = {}
    for u in units: last[u['unit_id']] = u
    return list(last.values())


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    sys.exit(plumbing() if PLUMB else main())
