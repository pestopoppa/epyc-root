#!/usr/bin/env python3
"""PF1-EXPAND r3 fresh three-block retry; bias unresolved (packet derived from EXP-04 r6; L = 384,448,512,768 (refinement r2), champion candidate 181483cfc) -- EXP-04 pilot job: CPU/MI210 prefill crossover screen for Q38FN (backlog refactor 2026-11, owner PF1).

Runs under filler_run15.sh (cwd = this dir, FILLER_* env). r3 (2026-11-02; r4 2026-11-03 fixes A2 -> -ncmoe 48 and the run-failure vs residency labelling; r6 2026-11-03: ONE pre-evict + ONE model load per ARM LAUNCH (not per cell): each launch passes every L in a single llama-bench invocation (-p L1 -p L2 -r REPS; the model is loaded once and reused across the n_prompt instances, per llama-bench equal_mparams), 3 launches per arm = 3 blocks; r5 2026-11-03 PF1-EXP04-PLACEMENT: sampler fix in research e7f6262b4 + placement failures classed as placement, not run, failures + GPU_SKEW_RULE): EVERY arm, CPU and GPU, runs through the
sanctioned bench_canonical.sh with the explicit kernel-store tuple (--binary <store>/llama-bench --source-root
/mnt/raid0/llm/llama.cpp --library-path <store>), so every cell gets NUMA pre-evict + the in-window placement proof and a
content-proven identity block (store build id, source commit, SHA256SUMS digests, verify_ggml_linkage PASS) written to
<cell>/canonical/identity.json. Code root is PINNED to a detached research worktree at e7f6262b4 (99944fe12 taught the wrapper to accept store binaries;
e7f6262b4 adds the fixed in-window placement sampler), never the shared clone. Two modes:
  plumbing  FILLER_DRYRUN=1 or FILLER_SMOKE=1: identity check, bench_canonical --dry-run for every arm, then ONE small
            real A1 cell (L=512, 8 threads of FILLER_CPUS, mmap from page cache) with in-window VRAM/KFD sampling ->
            one unit (mode=plumbing, never analysed). Proves launcher, binaries, residency proof and result writing.
  pilot     the bounded screen: 2 L x {A0, A1@ub2048, A2@ub2048, A1-disabled} x 3 launches, interleaved, cap 3600 s
            cumulative. Incremental units in out/results.jsonl, summary in out/summary.json after every unit,
            out/PILOT-COMPLETE.json on completion / stop-on-answer / stop-on-futility / cap.
Exploratory / decision-support: an early stop is an operational decision, never a PF1 gate result; the short-L screen
never yields a negative PF1 verdict.
"""
import hashlib, json, math, os, re, signal, statistics, subprocess, sys, threading, time

D = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(D, 'out'); RES = os.path.join(OUT, 'results.jsonl'); SUM = os.path.join(OUT, 'summary.json')
DONE = os.path.join(OUT, 'PILOT-COMPLETE.json'); CELLS = os.path.join(OUT, 'cells')
IDENT = json.load(open(os.path.join(D, 'IDENTITY.json')))
CODE_ROOT = '/mnt/raid0/llm/worktrees/research-pin-pf1-expand-20261104'   # detached pin, research origin/main 1dae4bac8 (bench_canonical passes --load-threads when the binary advertises it)
CODE_SHA = '1dae4bac89a4a4d23051cf8cc8b97366f36173c8'
# GPU-arm placement rule (operator decision PF1-EXP04-PLACEMENT; the 40% node cap itself is NEVER changed here):
#   'strict' = r4 behaviour: wrapper exit 3 (skew > cap) invalidates the cell.
#   'record' = GPU arms (pinned host-resident weights; the HIP pinned allocator does not follow --interleave=all) run with the
#              wrapper's --allow-skew: the in-window sample is REQUIRED and recorded, its max node share is reported as a covariate,
#              but skew alone does not invalidate the cell. A0 (CPU interleave) stays strict in both modes.
GPU_SKEW_RULE = 'record'
WRAP = CODE_ROOT + '/scripts/benchmark/bench_canonical.sh'
LINK = CODE_ROOT + '/scripts/utils/verify_ggml_linkage.sh'
SRC = '/mnt/raid0/llm/llama.cpp'
STORE = {'cpu': '/mnt/raid0/llm/kernels/builds/cpu-20261103-181483cfc-lbt/bin', 'gpu': '/mnt/raid0/llm/kernels/builds/gpu-20261103-181483cfc-lbt/bin'}  # PF1-EXPAND 2026-11-04: newest champion candidate 181483cfc (llama-bench --load-threads)
HEAD = IDENT['kernel']['commit']; MODEL = IDENT['model']['load_path']
N_CPU_MOE = 48; L_SET = (384, 448, 512, 768); UB = 2048; BLOCKS = 3; CAP_S = IDENT['cap']['pilot_wall_s']
REPS = 5   # timed reps per (launch, L) after llama-bench's own untimed warmup pass; the LAUNCH is the replicate unit, reps only give the launch median
LAUNCH_NEED_S = 300   # first-launch wall estimate for window/cap checks (A0 ~380 s incl. a cold pre-evict; GPU arms ~150-270 s); later launches use 1.2 x the arm's max observed
GPU_ARMS = [] if os.environ.get('PF1_ONLY_A0') == '1' else ['A1', 'A2', 'A1-disabled']; BAND = 1.10; CTRL_TOL = 0.10; CTRL_DIVERGE = 0.25
KFD = '/sys/class/kfd/kfd/proc'
REQUIRED = ('tps', 'samples_ts', 'build_commit', 'build_number', 'argv', 'env', 'vram', 'kfd_pids', 'claim', 'raw_log',
            'mapped_ggml', 'wall_s')
PLUMB = os.environ.get('FILLER_DRYRUN') == '1' or os.environ.get('FILLER_SMOKE') == '1'
STOPF = os.environ.get('FILLER_STOPFILE', os.path.join(D, 'STOP'))
DEADLINE = int(os.environ.get('FILLER_DEADLINE', str(int(time.time()) + 3600)))


def now(): return time.strftime('%FT%TZ', time.gmtime())
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 22), b''): h.update(b)
    return h.hexdigest()


def append(unit):
    os.makedirs(OUT, exist_ok=True)
    with open(RES, 'a') as f:
        f.write(json.dumps(unit, sort_keys=True) + '\n'); f.flush(); os.fsync(f.fileno())


def atomic(path, obj):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f: json.dump(obj, f, indent=1, sort_keys=True)
    os.replace(tmp, path)


def identity_check():
    """Content proof at every start: binaries/libs hash as pinned, store symlinks unchanged, linkage PASS, shards' stat
    triple unchanged (full shard sha256 pinned at prep)."""
    bad = []
    r = subprocess.run(['git', '-C', CODE_ROOT, 'rev-parse', 'HEAD'], capture_output=True, text=True)
    if r.returncode != 0 or r.stdout.strip() != CODE_SHA: bad.append(f'code root not at pinned {CODE_SHA[:9]}: {r.stdout.strip() or r.stderr[-200:]}')
    r = subprocess.run(['git', '-C', CODE_ROOT, 'status', '--porcelain', '--untracked-files=no'], capture_output=True, text=True)
    if r.returncode != 0 or r.stdout.strip(): bad.append('code root has tracked modifications')
    for k, s in IDENT['kernel']['stores'].items():
        if os.path.realpath(STORE[k]) != s['resolves_to']: bad.append(f'{k} store moved')
        for f, v in s['files'].items():
            if sha(os.path.join(STORE[k], f)) != v['sha256']: bad.append(f'{k}/{f} digest changed')
        env = dict(os.environ, LD_LIBRARY_PATH=STORE[k] + ':/usr/lib/llvm-20/lib')
        r = subprocess.run(['bash', LINK, STORE[k] + '/llama-bench', STORE[k]], env=env, capture_output=True, text=True)
        if r.returncode != 0: bad.append(f'{k} linkage FAIL: {r.stdout[-300:]}')
    for s in IDENT['model']['shards']:
        st = os.stat(s['path'])
        if (st.st_size, st.st_mtime_ns, st.st_ino) != (s['size'], s['mtime_ns'], s['ino']): bad.append(f"shard changed {s['path']}")
    return bad


def gpu_card():
    for c in sorted(os.listdir('/sys/class/drm')):
        p = f'/sys/class/drm/{c}/device'
        if re.fullmatch(r'card\d+', c) and os.path.exists(p + '/mem_info_vram_used'): return p
    return None


def rd(p, d=None):
    try: return int(open(p).read().strip())
    except (OSError, ValueError): return d


class Sampler(threading.Thread):
    """VRAM / GPU busy / KFD residency of OUR session, sampled every 0.5 s DURING the cell."""
    def __init__(self, sid):
        super().__init__(daemon=True); self.sid = sid; self.stop = threading.Event(); self.card = gpu_card()
        self.vram = []; self.busy = []; self.kfd = {}; self.maps = {}

    def run(self):
        while not self.stop.is_set():
            if self.card:
                self.vram.append(rd(self.card + '/mem_info_vram_used', 0)); self.busy.append(rd(self.card + '/gpu_busy_percent', 0))
            try: pids = [p for p in os.listdir(KFD) if p.isdigit()]
            except OSError: pids = []
            for p in pids:
                try:
                    if os.getsid(int(p)) != self.sid: continue
                except OSError: continue
                v = sum(rd(os.path.join(KFD, p, f), 0) for f in os.listdir(os.path.join(KFD, p)) if f.startswith('vram_'))
                self.kfd[p] = max(self.kfd.get(p, 0), v)
            self.scan_maps()
            self.stop.wait(0.5)

    def scan_maps(self):
        for p in os.listdir('/proc'):
            if not p.isdigit() or p in self.maps: continue
            try:
                if os.getsid(int(p)) != self.sid or not os.readlink(f'/proc/{p}/exe').endswith('llama-bench'): continue
                libs = sorted({l.split()[-1] for l in open(f'/proc/{p}/maps') if 'libggml' in l})
                if libs: self.maps[p] = {'libs': libs, 'real': sorted({os.path.realpath(x) for x in libs})}
            except OSError: continue


def claim_record():
    gid = os.environ.get('FILLER_ID', '')
    g = os.path.join(os.environ.get('FILLER_GRANTS_DIR', '/mnt/raid0/llm/tmp/compute-flags/grants'), gid + '.grant')
    try: gtxt = open(g).read().strip()
    except OSError: gtxt = None
    return {'filler_id': gid, 'filler_cpus': os.environ.get('FILLER_CPUS'), 'grant': gtxt,
            'engine_claim': 'region-lock --cpu-list 0-95 --gpu-quiet exclusive --role bench (filler_run15 cpu+gpu)' if not PLUMB else 'smoke/dry-run claim (plumbing only)'}


def arm_flags(arm, ub):
    if arm == 'A0': return ['-dev', 'none', '-ngl', '0', '--no-op-offload', '1']
    if arm in ('A1', 'A1-disabled'): return ['-ngl', '0', '-ub', str(ub)]
    # r4: llama-bench has no -cmoe/--cpu-moe; the spelling is -ncmoe/--n-cpu-moe N = keep the experts of blocks 0..N-1 on CPU. Q38FN (qwen4exp) has 48 blocks
    # (GGUF qwen4exp.block_count), so N_CPU_MOE=48 is the all-experts-on-CPU shape that -cmoe meant (verified against `llama-bench --help` on the v10 gpu store).
    if arm == 'A2': return ['-ngl', '99', '-ncmoe', str(N_CPU_MOE), '-ub', str(ub)]
    raise ValueError(arm)


def arm_env(arm):
    env = {k: v for k, v in os.environ.items() if not k.startswith('GGML_')}
    st = STORE['cpu' if arm == 'A0' else 'gpu']
    env['LD_LIBRARY_PATH'] = st + ':/usr/lib/llvm-20/lib'; env['CANONICAL_SKIP_REGION_LOCK'] = '1'
    if arm == 'A1-disabled': env['GGML_OP_OFFLOAD_MIN_BATCH'] = '2147483647'
    return env, st


def canonical_argv(arm, Ls, logdir, dry=False):
    """Every arm through the sanctioned wrapper with the explicit kernel-store identity tuple (r1 shape, which failed only
    because the wrapper then refused store binaries; fixed in research 99944fe12). The wrapper pins the store dir first in
    LD_LIBRARY_PATH by realpath, proves the binary + linked libs against the store SHA256SUMS + manifest commit, runs
    verify_ggml_linkage.sh, pre-evicts NUMA and captures the in-window placement proof for EVERY arm."""
    env, st = arm_env(arm)
    skew = ['--allow-skew'] if (arm != 'A0' and GPU_SKEW_RULE == 'record') else []
    Ls = tuple(Ls)   # the wrapper takes ONE -p; the remaining L ride as repeated -p after `--` (llama-bench appends each -p to n_prompt; verified in
    #                  tools/llama-bench/llama-bench.cpp and canonical_recipe.build_canonical_bench_run appends extra flags unvalidated)
    more = [x for L in Ls[1:] for x in ('-p', str(L))]
    a = ['bash', WRAP, '-m', MODEL, '-p', str(Ls[0]), '-n', '0', '-r', str(REPS), '--binary', st + '/llama-bench', '--source-root', SRC,
         '--library-path', st, '--log-dir', logdir] + skew + (['--dry-run'] if dry else []) + ['--', '-o', 'json'] + arm_flags(arm, UB) + more
    return a, env


def parse(text, L):
    dec = json.JSONDecoder()
    for m in re.finditer(r'\[\s*\{', text):
        try: data, _ = dec.raw_decode(text[m.start():])
        except ValueError: continue
        for row in data if isinstance(data, list) else []:
            if isinstance(row, dict) and row.get('n_prompt') == L and row.get('n_gen') == 0: return row
    return None


def run_launch(arm, Ls, argv, env, cdir, timeout_at):
    """ONE bench_canonical invocation = one pre-evict + one model load + one placement sample + one residency sample for the
    whole launch; returns one record per L (same evidence, own timing)."""
    Ls = tuple(Ls)
    os.makedirs(cdir, exist_ok=True); raw = os.path.join(cdir, 'raw.log'); t0 = time.time(); err = None
    card = gpu_card(); v0 = rd(card + '/mem_info_vram_used', 0) if card else None
    with open(raw, 'wb') as f:
        p = subprocess.Popen(argv, stdout=f, stderr=subprocess.STDOUT, env=env, cwd=D, start_new_session=True)
        s = Sampler(p.pid); s.start()
        while p.poll() is None:
            if os.path.exists(STOPF) or time.time() >= timeout_at:
                err = 'stop' if os.path.exists(STOPF) else 'deadline'
                for sig, w in ((signal.SIGTERM, 20), (signal.SIGKILL, 10)):
                    try: os.killpg(p.pid, sig)
                    except ProcessLookupError: break
                    try: p.wait(w); break
                    except subprocess.TimeoutExpired: continue
                break
            time.sleep(0.5)
        rc = p.wait(); s.stop.set(); s.join(5)
    text = open(raw, errors='replace').read()
    vmax = max(s.vram) if s.vram else None
    wall = round(time.time() - t0, 2)
    common = {'arm': arm, 'ub': None if arm == 'A0' else UB, 'rc': rc, 'error': err, 'launch_wall_s': wall, 'Ls': list(Ls), 'reps': REPS,
              'argv': argv, 'env': {k: env.get(k) for k in ('LD_LIBRARY_PATH', 'GGML_OP_OFFLOAD_MIN_BATCH', 'CANONICAL_SKIP_REGION_LOCK')},
              'raw_log': raw, 'vram': {'before_b': v0, 'max_b': vmax, 'delta_b': (vmax - v0) if vmax is not None and v0 is not None else None,
                                       'samples': len(s.vram), 'busy_max_pct': max(s.busy) if s.busy else None},
              'kfd_pids': s.kfd, 'mapped_ggml': s.maps, 'claim': claim_record(), 'at': now()}
    if '--log-dir' in argv:
        ld = argv[argv.index('--log-dir') + 1]
        try: common['canonical_identity'] = json.load(open(os.path.join(ld, 'identity.json')))
        except (OSError, ValueError): common['canonical_identity'] = None
        try: common['placement_rc'] = int(open(os.path.join(ld, 'placement.log.rc')).read().strip())
        except (OSError, ValueError): common['placement_rc'] = None
        common['placement'] = placement_info(ld)
    rows = {L: parse(text, L) for L in Ls}
    bench = {}
    for L, row in rows.items():
        ts = [x for x in (row or {}).get('samples_ts') or [] if x]
        # bench seconds = the timed reps + llama-bench's one untimed warmup pass (assumed = one median rep): both run flat out
        bench[L] = round(sum(L / x for x in ts) + (L / statistics.median(ts) if ts else 0.0), 2)
    tot = sum(bench.values()) or 1.0
    recs = []
    for L in Ls:
        row = rows[L]; u = dict(common, L=L, bench_s=bench[L], wall_s=round(wall * bench[L] / tot, 2) if sum(bench.values()) else (wall if L == Ls[0] else 0.0))
        if row:
            ts = [x for x in row.get('samples_ts') or [] if x]
            u.update(tps=statistics.median(ts) if ts else row.get('avg_ts'), tps_mean=row.get('avg_ts'), samples_ts=row.get('samples_ts'),
                     build_commit=row.get('build_commit'), build_number=row.get('build_number'), n_ubatch=row.get('n_ubatch'), n_threads=row.get('n_threads'))
        u['failure_class'] = failure_class(u)
        u['checks'] = checks(u)
        u['valid'] = all(v for k, v in u['checks'].items() if k != 'offload_suppressed')
        u['capture_complete'] = all(u.get(k) not in (None, {}, []) for k in REQUIRED if not (arm == 'A0' and k == 'kfd_pids') and k != 'wall_s') and u.get('wall_s') is not None
        recs.append(u)
    return recs


def placement_info(ld):
    """What the wrapper's in-window sampler recorded for this cell (r5): max node share, settled/provisional, coverage."""
    info = {'rule': GPU_SKEW_RULE, 'sample_recorded': False}
    try: info['reason'] = open(os.path.join(ld, 'placement.log.reason')).read()[:600]
    except OSError: info['reason'] = None
    try:
        t = open(os.path.join(ld, 'placement.log')).read()
        m = re.search(r'max=node(\d)@([\d.]+)%', t)
        if m: info.update(sample_recorded=True, max_node=int(m.group(1)), max_share_pct=float(m.group(2)))
        nodes = re.findall(r'node (\d):\s+[\d.]+ MB\s+([\d.]+)%', t)
        if nodes: info['shares_pct'] = {n: float(p) for n, p in nodes}
    except OSError: pass
    r = info.get('reason') or ''
    info['settled'] = 'settled=yes' in r; info['provisional'] = 'settled=no' in r
    m = re.search(r'coverage_pct=(-?\d+)', r); info['coverage_pct'] = int(m.group(1)) if m else None
    return info


def failure_class(u):
    """r5: a wrapper refusal for placement is a PLACEMENT failure, not a run failure (r4 counted the rc=3 skew exits as
    'failed to RUN' and stopped the pilot with the wrong label)."""
    if u['rc'] == 0 and not u['error']: return None
    if u['error']: return 'run'
    pl = u.get('placement') or {}
    if u['rc'] == 3 and u.get('placement_rc') == 3: return 'placement_skew'
    if u['rc'] == 1 and u.get('placement_rc') is None and u.get('tps') is not None and 'NO in-window' in (pl.get('reason') or ''): return 'placement_no_sample'
    return 'run'


def checks(u):
    arm = u['arm']; pidv = max(u['kfd_pids'].values()) if u['kfd_pids'] else 0
    hip = [r for m in u['mapped_ggml'].values() for r in m['real'] if 'libggml-hip' in r]
    gpu_store = IDENT['kernel']['stores']['gpu']['resolves_to']; cpu_store = IDENT['kernel']['stores']['cpu']['resolves_to']
    real = [r for m in u['mapped_ggml'].values() for r in m['real']]
    c = {'rc0': u['rc'] == 0 and not u['error'] or (u.get('failure_class') == 'placement_skew' and arm != 'A0' and GPU_SKEW_RULE == 'record'), 'parsed': u.get('tps') is not None,
         'build': u.get('build_number') == IDENT['kernel']['build_number'] and HEAD.startswith(str(u.get('build_commit') or '!')),
         'vram_sampled': (u['vram']['samples'] or 0) >= 2}
    if '--log-dir' in u['argv']:   # wrapper cell: content-proven store identity of THIS arm's backend + placement proof PASS
        ci = u.get('canonical_identity') or {}
        want = IDENT['kernel']['stores']['cpu' if arm == 'A0' else 'gpu']['resolves_to']
        c['store_identity'] = ci.get('kind') == 'kernel_store' and ci.get('library_path') == want \
            and ci.get('ggml_linkage') == 'PASS' and HEAD.startswith(str(ci.get('manifest_commit') or '!'))
        # strict: sample recorded AND within the cap (wrapper rc 0). record (GPU arms only): sample recorded, rc 0 or 3 (skew reported, not fatal).
        okrc = (0, 3) if (arm != 'A0' and GPU_SKEW_RULE == 'record') else (0,)
        c['placement_proof'] = u.get('placement_rc') in okrc and bool((u.get('placement') or {}).get('sample_recorded'))
    if arm == 'A0':
        c['no_gpu_residency'] = not u['kfd_pids'] and (u['vram']['delta_b'] or 0) < (256 << 20)
        c['mapped_store'] = bool(real) and all(r.startswith(cpu_store) for r in real)
    else:
        c['hip_residency'] = bool(u['kfd_pids']) and pidv >= (64 << 20) if arm != 'A1-disabled' else bool(u['kfd_pids'])
        c['mapped_store'] = bool(hip) and all(r.startswith(gpu_store) and r.endswith('libggml-hip.so.0.16.0') for r in hip)
        if arm == 'A1': c['mechanism_fired'] = (u['vram']['busy_max_pct'] or 0) >= 5 and pidv >= (64 << 20)
        if arm == 'A2': c['mechanism_fired'] = pidv >= (1 << 30)
        if arm == 'A1-disabled': c['offload_suppressed'] = (u['vram']['busy_max_pct'] or 0) < 5
    return c


def load_units():
    try: return [json.loads(l) for l in open(RES) if l.strip()]
    except OSError: return []


def med(x): return statistics.median(x) if x else None


def summarize(units, stop_reason=None):
    P = [u for u in units if u.get('mode') == 'pilot']; V = [u for u in P if u['valid']]
    per = {}
    for u in V: per.setdefault(f"{u['arm']}@{u['L']}", []).append(u['tps'])
    var = {k: {'n': len(v), 'median': med(v), 'mean': statistics.fmean(v), 'sd': statistics.stdev(v) if len(v) > 1 else None,
               'cv': (statistics.stdev(v) / statistics.fmean(v)) if len(v) > 1 else None} for k, v in per.items()}
    dur = {}
    for u in P: dur.setdefault(f"{u['arm']}@{u['L']}", []).append(u['wall_s'])
    ratios = {}
    for L in L_SET:
        for b in range(BLOCKS):
            base = [u for u in V if u['L'] == L and u['block'] == b and u['arm'] == 'A0']
            for u in V:
                if base and u['L'] == L and u['block'] == b and u['arm'] != 'A0':
                    ratios.setdefault(f"{u['arm']}@{L}", []).append(round(u['tps'] / base[0]['tps'], 4))
    ctrl = {L: med(ratios.get(f'A1-disabled@{L}', [])) for L in L_SET}
    # r4: a unit that never ran (argv error, launch failure) is NOT a residency finding (r3: A2 `-cmoe` rejected by llama-bench was reported as residency failure)
    resid_fail = sorted({u['launch_id'] for u in P if u['arm'] in ('A1', 'A2') and u['rc'] == 0 and not u['error'] and not u['checks'].get('hip_residency')})
    run_fail = sorted({u['launch_id'] for u in P if u['arm'] in ('A1', 'A2', 'A1-disabled') and u.get('failure_class') == 'run'})
    place_fail = sorted({u['launch_id'] for u in P if not u['checks'].get('placement_proof', True)})
    place_info = {u['launch_id']: {k: (u.get('placement') or {}).get(k) for k in ('max_node', 'max_share_pct', 'shares_pct', 'settled', 'provisional', 'coverage_pct', 'sample_recorded')}
                  for u in P if u.get('placement')}
    complete = sum(1 for u in P if u['capture_complete']) / len(P) if P else 0.0
    cover = {f'{a}@{L}': len(per.get(f'{a}@{L}', [])) for a in ['A0'] + GPU_ARMS for L in L_SET}
    pf1_testable = all(n >= 2 for n in cover.values())
    if resid_fail or run_fail or place_fail or any(c is not None and abs(c - 1) > CTRL_TOL for c in ctrl.values()) or complete < 1.0:
        decision = 'REVISE'
    elif pf1_testable and all(c is not None for c in ctrl.values()):
        decision = 'EXPAND'
    else:
        decision = 'INCONCLUSIVE'
    best = {L: max(((a, med(ratios.get(f'{a}@{L}', [])) or 0) for a in ('A1', 'A2')), key=lambda t: t[1]) for L in L_SET}
    return {'schema': 'brf-exp04-summary.v1', 'updated_at': now(), 'units_total': len(P), 'units_valid': len(V),
            'duration_per_cell_s': {k: {'n': len(v), 'median': med(v), 'max': max(v)} for k, v in dur.items()},
            'variance_per_arm': var, 'paired_ratio_vs_A0_by_block': ratios,
            'best_gpu_arm_median_ratio': {str(L): {'arm': a, 'ratio': r, 'clears_1.10': r >= BAND} for L, (a, r) in best.items()},
            'control_A1disabled_over_A0_median': {str(k): v for k, v in ctrl.items()},
            'residency_failures': resid_fail, 'run_failures': run_fail, 'placement_failures': place_fail,
            'gpu_skew_rule': GPU_SKEW_RULE, 'placement_by_unit': place_info, 'capture_completeness': round(complete, 4),
            'consumer_coverage': {'cells_valid': cover,
                                  'PF1': 'rule testable at L in ' + str(sorted(L_SET)) + ' only' if pf1_testable else 'not yet testable (cells < 2 valid)',
                                  'HSF': 'not covered: needs the full L set (1K..32K)', 'NPD': 'not covered: needs the full L set'},
            'cumulative_wall_s': round(sum(u['wall_s'] for u in P), 1), 'cap_s': CAP_S,
            'busy': busy_block(P),
            'decision_suggestion': decision, 'stop_reason': stop_reason,
            'crossover': crossover(ratios),
            'label': 'exploratory/decision-support; owner (PF1) reviews; never a PF1 gate result; the short-L screen never yields a negative PF1 verdict'}


def crossover(ratios):
    """Per GPU arm: smallest L in L_SET with paired-ratio median >= 1.0 vs A0 such that every larger L in L_SET also has median >= 1.0
    (None = never; 'all' = already at the smallest L). Also the same at BAND (1.10). Decision-support only."""
    out = {}
    for a in ('A1', 'A2', 'A1-disabled'):
        m = {L: med(ratios.get(f'{a}@{L}', [])) for L in L_SET}
        for name, thr in (('ge1.00', 1.0), ('ge1.10', BAND)):
            first = None
            for L in sorted(L_SET, reverse=True):
                if m[L] is not None and m[L] >= thr: first = L
                else: break
            out.setdefault(a, {})[name] = {'first_L': first, 'medians': {str(L): v for L, v in m.items()}} if name == 'ge1.00' else {'first_L': first}
    return out


def busy_block(P):
    """bench seconds (timed reps + the untimed warmup pass, both full-tilt prefill) over launch wall seconds; the rest is setup
    (process start, pre-evict, the single-threaded -mmp 0 model load, context/compute-buffer init, placement/residency sampling)."""
    L_ = {}
    for u in P:
        if u.get('launch_id'): L_[u['launch_id']] = u.get('launch_wall_s') or 0.0
    bench = sum(u.get('bench_s') or 0.0 for u in P); wall = sum(L_.values())
    return {'launches': len(L_), 'bench_s': round(bench, 1), 'launch_wall_s': round(wall, 1), 'setup_s': round(wall - bench, 1),
            'busy_fraction': round(bench / wall, 3) if wall else None,
            'note': 'bench_s = sum of timed reps from samples_ts + one untimed warmup pass assumed = one median rep'}


def look(units, blocks_done):
    """Planned look at each block end (>= 2 blocks). Returns a stop reason or None."""
    s = summarize(units)
    if len(s['run_failures']) >= 2: return 'futility: >= 2 GPU units failed to RUN (argv/launch error, not a residency finding; REVISE the harness)'
    if len(s['placement_failures']) >= 2: return f"futility: placement proof failed on >= 2 GPU units under GPU_SKEW_RULE={GPU_SKEW_RULE} (REVISE: placement; not a run or residency finding)"
    if len(s['residency_failures']) >= 2: return 'futility: HIP residency not proven on >= 2 GPU units (REVISE)'
    if blocks_done < 2: return None
    ctrl = [v for v in s['control_A1disabled_over_A0_median'].values()]
    if all(c is not None and abs(c - 1) > CTRL_DIVERGE for c in ctrl): return 'futility: A1-disabled control diverges > 25% from A0 at every L (REVISE)'
    # r3: three full blocks unless predeclared futility/cap/window stops; no answer-based early stop.
    return None


def plumbing():
    bad = identity_check()
    dry = {}
    for arm in ['A0'] + GPU_ARMS:
        a, env = canonical_argv(arm, L_SET, os.path.join(OUT, 'plumbing', 'canon-' + arm), dry=True)
        r = subprocess.run(a, env=env, capture_output=True, text=True, timeout=300, cwd=D)
        out = r.stdout + r.stderr
        ok = r.returncode == 0 and 'Identity:  kernel_store build=' in out and 'ggml_linkage=PASS' in out and all(f'-p {L}' in out for L in L_SET)   # r6: both L in the ONE launch argv
        dry[arm] = {'rc': r.returncode if ok or r.returncode else 4, 'tail': out[-900:]}
    cpus = os.environ.get('FILLER_CPUS') or ''
    allowed = sorted(os.sched_getaffinity(0)); use = allowed[-8:]
    env, st = arm_env('A1')
    argv = ['taskset', '-c', ','.join(map(str, use)), st + '/llama-bench', '-m', MODEL, '-p', '512', '-n', '0', '-r', '1',
            '-t', str(len(use)), '-fa', '1', '-mmp', '1', '-ngl', '0', '-ub', '512', '-o', 'json']
    u = run_launch('A1', (512,), argv, env, os.path.join(OUT, 'plumbing', f'cell-{int(time.time())}'), min(DEADLINE, time.time() + 1200))[0]
    u.update(mode='plumbing', unit_id=f'plumbing-{now()}', identity_problems=bad, canonical_dry_run=dry, filler_cpus=cpus,
             note='plumbing proof only (mmap, 8 threads); never analysed')
    append(u)
    ok = not bad and all(v['rc'] == 0 for v in dry.values()) and u['valid']
    print(json.dumps({'plumbing_ok': ok, 'identity': bad, 'canon_rc': {k: v['rc'] for k, v in dry.items()}, 'checks': u['checks'],
                      'tps': u.get('tps'), 'vram_max': u['vram']['max_b'], 'kfd': u['kfd_pids']}), flush=True)
    return 0 if ok else 3


def pilot():
    bad = identity_check()
    if bad:
        print('IDENTITY REFUSED: ' + '; '.join(bad), flush=True); return 2
    units = load_units(); run_id = now()
    done_ids = {u['unit_id'] for u in units if u.get('mode') == 'pilot' and u.get('error') not in ('stop', 'deadline')}
    stop_reason = None
    for b in range(BLOCKS):
        Ls = L_SET if b % 2 == 0 else tuple(reversed(L_SET))      # odd blocks run the L's reversed WITHIN each launch
        g = GPU_ARMS[b % 3:] + GPU_ARMS[:b % 3]                    # GPU arms rotated by block; A0 first (control) in every block
        for arm in ([] if os.environ.get('PF1_SKIP_A0') == '1' else ['A0']) + g:
            lid = f'b{b}-{arm}'
            if all(f'b{b}-L{L}-{arm}' in done_ids for L in Ls): continue
            if os.path.exists(STOPF): print('STOP file', flush=True); return 75
            pil = [u for u in load_units() if u.get('mode') == 'pilot']
            used = sum(u['wall_s'] for u in pil)
            prev = [u['launch_wall_s'] for u in pil if u['arm'] == arm and u.get('launch_wall_s')]
            need = max(prev) * 1.2 if prev else LAUNCH_NEED_S
            if used + need > CAP_S: stop_reason = f'cap: cumulative {used:.0f}s + next {need:.0f}s > {CAP_S}s'; break
            if time.time() + need > DEADLINE: print('window deadline: resume later', flush=True); return 75
            a, env = canonical_argv(arm, Ls, os.path.join(CELLS, lid, 'canonical'))
            recs = run_launch(arm, Ls, a, env, os.path.join(CELLS, lid), min(DEADLINE, time.time() + max(need * 2, 1500)))
            for u in recs:
                u.update(mode='pilot', unit_id=f"b{b}-L{u['L']}-{arm}", launch_id=lid, block=b, run_id=run_id, identity_sha256=sha(os.path.join(D, 'IDENTITY.json')))
                append(u)
                print(f"{u['unit_id']} rc={u['rc']} tps={u.get('tps')} valid={u['valid']} bench={u['bench_s']} launch_wall={u['launch_wall_s']}", flush=True)
            units = load_units(); atomic(SUM, summarize(units))
            if recs[0]['error'] in ('stop', 'deadline'): return 75
        if stop_reason: break
        stop_reason = look(load_units(), b + 1)
        if stop_reason: break
    s = summarize(load_units(), stop_reason or 'complete: all planned cells attempted')
    atomic(SUM, s); atomic(DONE, s)
    print(json.dumps({k: s[k] for k in ('decision_suggestion', 'stop_reason', 'units_valid', 'capture_completeness')}), flush=True)
    return 0


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    sys.exit(plumbing() if PLUMB else pilot())
