from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from urllib.request import Request, urlopen


D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
import ak_row_harness as H

OUT = D / 'out'
STORE = Path('/mnt/raid0/llm/kernels/builds/gpu-20260921-ffc1bac82')
BIN = STORE / 'bin'
LIB = BIN / 'libggml-hip.so.0.16.0'
SERVER = BIN / 'llama-server'
MODEL = Path('/mnt/raid0/llm/models/Qwen3.6-35B-A3B-MTP-Q8_0.gguf')
MODEL_PIN = 'c1283d8b80c3e38b2735ddbc9766d3b3126f44d6c484be419d4e101d09a76131'
SDK = Path('/mnt/raid0/llm/tools/rocprofiler-sdk-6.2.0-66/opt/rocm-6.2.0')
SUPPORT = '/mnt/raid0/llm/tools/rocm-profilers-6.2/opt/rocm-6.2.0/lib'
VERIFY = '/mnt/raid0/llm/epyc-inference-research/scripts/utils/verify_ggml_linkage.sh'
PORT = os.environ['FILLER_PORTS'].split(',')[0]
SMOKE = os.environ.get('FILLER_SMOKE') == '1' or os.environ.get('FILLER_DRYRUN') == '1'
STOP = Path(os.environ['FILLER_STOPFILE'])
DEADLINE = float(os.environ['FILLER_DEADLINE'])
PROMPT = ('The maintainers compared the reference implementation to the experimental build. '
          'The records identify the input, the execution path, and the observed result. '
          'Read the attached notes, then produce an ordered summary of the observations.\n')


def save(path, record):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def request(path, payload=None, timeout=90):
    data = json.dumps(payload).encode() if payload is not None else None
    req = Request('http://127.0.0.1:' + PORT + path, data, {'Content-Type': 'application/json'})
    with urlopen(req, timeout=timeout) as rsp:
        return json.load(rsp)


def check_time(margin):
    if STOP.is_file() or time.time() + margin > DEADLINE:
        raise RuntimeError('STOP or insufficient time for next request')


def kfd_sample(pid):
    proc = Path('/sys/class/kfd/kfd/proc') / str(pid)
    vram = sum(int(x.read_text()) for x in proc.glob('vram_*'))
    maps = (Path('/proc') / str(pid) / 'maps').read_text()
    kfd = sorted(int(p.name) for p in proc.parent.iterdir() if p.name.isdigit())
    return {'pid': pid, 'vram_b': vram, 'hip_store_mapped': str(LIB) in maps, 'kfd_pids': kfd}


def probe(tokens, n_predict):
    start = time.monotonic_ns()
    rsp = request('/completion', {
        'prompt': tokens, 'n_predict': n_predict, 'temperature': 0.0, 'top_k': 1,
        'seed': 42, 'ignore_eos': True, 'cache_prompt': False,
    })
    end = time.monotonic_ns()
    info = rsp['timings']
    if info['predicted_n'] != n_predict:
        raise RuntimeError(f'short response {info["predicted_n"]} vs {n_predict}')
    return {
        'start_ns': start, 'end_ns': end, 'timings': info, 'input_token_count': len(tokens),
        'input_token_sha256': hashlib.sha256(json.dumps(tokens).encode()).hexdigest(),
    }


def sample_while_running(p, futures):
    samples = []
    while any(not fut.done() for fut in futures):
        try:
            samples.append({'at_ns': time.monotonic_ns(), **kfd_sample(p.pid)})
        except (FileNotFoundError, ProcessLookupError):
            pass
        time.sleep(0.10)
    results = [f.result() for f in futures]
    if not any(x['vram_b'] >= 20 * 1024 ** 3 and x['hip_store_mapped'] for x in samples):
        raise RuntimeError(f'no in-window GPU residency proof for PID {p.pid}')
    return {'requests': results, 'residency': samples}


def main():
    job_start = time.monotonic()
    out = OUT / ('smoke' if SMOKE else 'native')
    out.mkdir(exist_ok=True)
    manifest = (STORE / 'SHA256SUMS').read_text()
    identity = {str(p): digest(p) for p in (SERVER, LIB, BIN / 'libllama-server-impl.so')}
    for path, sha in identity.items():
        if sha not in manifest:
            raise RuntimeError(f'store manifest does not bind {path}')
    check_time(125)
    if digest(MODEL) != MODEL_PIN:
        raise RuntimeError('GGUF manifest mismatch')
    identity[str(MODEL)] = MODEL_PIN

    env = {k: v for k, v in os.environ.items() if not k.startswith(('GGML_', 'LLAMA_', 'HSA_', 'ROCR_', 'HIP_'))}
    env.update({
        'LD_LIBRARY_PATH': ':'.join(map(str, (BIN, SDK / 'lib', SDK / 'lib/rocprofiler-sdk', SUPPORT, '/opt/rocm/lib'))),
        'HIP_VISIBLE_DEVICES': '0', 'ROCM_PATH': '/opt/rocm', 'GGML_CUDA_LOG_MMVQ_ROUTE': '2',
        'FILLER_ID': os.environ['FILLER_ID'],
    })
    with (out / 'linkage.txt').open('w') as f:
        subprocess.run([VERIFY, str(SERVER), str(STORE)], env=env, stdout=f, stderr=subprocess.STDOUT, check=True)
    argv = [
        str(SDK / 'bin/rocprofv3'), '-M', '--kernel-trace', '--output-format', 'csv', '-d', str(out), '-o', 'a3b-v10', '--',
        '/usr/bin/numactl', '--membind=3', '--', '/usr/bin/taskset', '-c', '184-191',
        str(SERVER), '-m', str(MODEL), '--host', '127.0.0.1', '--port', PORT, '-np', '4', '-c', '16384',
        '--no-kv-unified', '-t', '8', '-tb', '8', '-b', '2048', '-ub', '2048', '-fa', 'on',
        '-ctk', 'f16', '-ctv', 'f16', '--reasoning', 'off', '--device', 'ROCm0', '-ngl', 'all',
        '--spec-type', 'draft-mtp', '--spec-draft-n-max', '2', '-lv', '4',
    ]
    save(out / 'run.json', {'argv': argv, 'identity': identity, 'role': 'A3B GPU production-config experimental visit'})
    records = []
    with (out / 'server.log').open('w') as log:
        p = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            wait_end = time.monotonic() + 120
            while time.monotonic() < wait_end:
                if p.poll() is not None:
                    raise RuntimeError(f'server exited before ready rc={p.returncode}')
                try:
                    if request('/health', timeout=2).get('status') == 'ok':
                        break
                except OSError:
                    pass
                time.sleep(0.25)
            else:
                raise RuntimeError('server did not become ready')
            tokens = request('/tokenize', {'content': PROMPT * 70, 'add_special': False})['tokens']
            probe(tokens[:32], 8)
            panels = [
                ('prefill256', 256, 1, 1),
                ('prefill1024', 1024, 1, 1),
                ('decode_np1', 500, 64, 1),
                ('decode_np4', 512, 64, 4),
                ('later_np1', 384, 64, 1),
                ('later_np4', 768, 64, 4),
            ]
            if SMOKE:
                panels = [panels[0], panels[3]]
            with ThreadPoolExecutor(max_workers=4) as ex:
                for name, length, n_predict, concurrent in panels:
                    check_time(35)
                    panel_start = time.monotonic()
                    time.sleep(1)
                    base = 12 if name.startswith('later') else 0
                    futures = [
                        ex.submit(probe, tokens[i * 125 + base:i * 125 + base + length], n_predict)
                        for i in range(concurrent)
                    ]
                    rec = sample_while_running(p, futures)
                    records.append({'panel': name, 'wall_s': time.monotonic() - panel_start, **rec})
                    save(out / 'requests.json', records)
                    print(f'PANEL_COMPLETE {name}', flush=True)
        finally:
            if p.poll() is None:
                p.send_signal(signal.SIGTERM)
                try:
                    p.wait(timeout=90)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait(timeout=10)
    trace = out / 'a3b-v10_kernel_trace.csv'
    if not trace.is_file() or trace.stat().st_size < 1000:
        raise RuntimeError(f'kernel trace missing or empty {trace}')
    result = {'row': os.environ['FILLER_ID'], 'ok': True, 'complete': True,
              'panels': [r['panel'] for r in records], 'trace': str(trace), 'trace_sha256': digest(trace)}
    if SMOKE:
        measured = [r['wall_s'] for r in records]
        loads_s = max(0, time.monotonic() - job_start - sum(measured))
        H.write_smoke_measure(D / "out" / "smoke", max(measured), len(measured), loads_s, unit_name='request panel')
        return H.end_smoke('PASS', 0, 'two panels passed with in-window residency', OUT, extra=result)
    save(OUT / 'RESULT.json', {'verdict': 'CENSUS_CAPTURED', **result})
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        if SMOKE:
            raise SystemExit(H.end_smoke('FAIL', 1, str(exc), OUT)) from exc
        raise
