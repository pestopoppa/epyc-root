#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/codex-mi210-matmul-census-20261127
cd "$D"
ulimit -c 0
# Smoke measures the isolated and four-request panels before native collection.
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh \
  --id codex-mi210-matmul-census-gpu-20261127 --class gpu \
  --claim-cpus 184-191 --role bench --gpu-quiet exclusive --gpu-threads 184-191 \
  --min-window 240 --port 28656 --cmd "/usr/bin/python3 -I -B $D/job.py" \
  --complete-cmd "/usr/bin/python3 -I -B $D/check_complete.py" --stop "$D/STOP" --workdir "$D"
