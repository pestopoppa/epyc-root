import json
from pathlib import Path

p = Path(__file__).resolve().parent / 'out' / 'RESULT.json'
raise SystemExit(0 if p.is_file() and json.loads(p.read_text()).get('complete') is True else 1)
