#!/usr/bin/python3
"""Exit zero only for this row's terminal gate result."""
import json
from pathlib import Path
import sys

try:
    result = json.loads((Path(__file__).resolve().parent / "out/RESULT.json").read_text())
except (OSError, ValueError):
    sys.exit(1)
verdict = str(result.get("verdict") or "")
sys.exit(0 if result.get("row") == "ak-q8-convcore-gpu-20261127" and result.get("complete") is True
         and verdict and "polar" in result and not verdict.startswith(("SMOKE", "STOPPED", "INCOMPLETE")) else 1)
