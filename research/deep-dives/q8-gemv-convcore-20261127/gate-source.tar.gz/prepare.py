#!/usr/bin/python3
"""Generate the sealed offline declaration from a source-pinned candidate store."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

from job import KNOBS, ROOT, ROW, SPEC, TASK

V5I_MARKER = "ggml_cuda_q8ip: in-place Q8_0 stage-contiguous repack enabled"
FLAGS = "/mnt/raid0/llm/tmp/compute-flags"
MODELS = Path("/mnt/raid0/llm/models")
MODEL = str(MODELS / "Qwen3.8-27B-Q8_0.gguf")
DRAFT = str(MODELS / "Qwen3.8-27B-DFlash2-Q8_0.gguf")
ARMS = ["OFF", "OFF2", "ON"]
PORT = 28112
ESTIMATE_S = 9600
MIN_WINDOW_S = 1800
RULE = (
    "Qwen3.8-27B Q8_0 + DFlash2-Q8_0 greedy np1, n-max 7. "
    "OFF/OFF2/ON pin the same V5I MF=6 HIP store. ON enables only the conversion-core knob. "
    "Require CPU-reference MUL_MAT and KLD <=0.003 at ub8/4/16/512 before profiling or served visits. "
    "Trace/counter evidence is required, with its rates reported against V5I. "
    "Served metric ms/verify round, lower is better. Discard block 0. "
    "Stop-on-answer at eight scored blocks, KEEP iff 95% speedup CI lower >1.01, else NO_KEEP. "
    "Stop-on-futility if 95% speedup CI upper <1.0 at block 4 or A/A deviation >2%, "
    "or on a correctness, witness, residency or input failure. Gate-class = futility-only at interim."
)
CONDITIONAL_FILES = ("op_profile.py", "profile-shapes.json", "profile_weights.json")
INPUTS = {
    "inputs/long_ctx.txt": "21cfa5e5374dd9c8864c9b716abe51f716d8b6d41919df4721978744fb59566c",
    "inputs/kld_text.txt": "5b64a9d6775c194517ff930b9bb7de229921167fb561d712e352e0c11b087957",
}


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def store_proof(store, source_sha, marker, on_kernel, off_kernel, offline):
    """Match the build identity and immutable hashes before sealing any run-ready declaration."""
    identity = json.loads((store / "BUILD-IDENTITY.json").read_text())
    if not re.fullmatch(r"[0-9a-f]{40}", source_sha) or identity.get("source_sha") != source_sha:
        raise ValueError("Need the full source SHA matching BUILD-IDENTITY.json.")
    binaries = ["llama-server", "llama-perplexity", "test-backend-ops"]
    libraries = ["libggml.so", "libggml-base.so", "libggml-hip.so", "libggml-cpu.so"]
    paths = {str((store / "bin" / item).resolve(strict=True).relative_to(store))
             for item in binaries + libraries}
    if not offline:
        required_strings = (KNOBS[0], marker, on_kernel, off_kernel)
        dso = (store / "bin" / "libggml-hip.so").read_bytes()
        for item in required_strings:
            if item.encode() not in dso:
                raise ValueError(f"Candidate HIP image lacks {item!r}.")
        subprocess.run(
            ["/usr/bin/sha256sum", "--check", "--status", "SHA256SUMS"],
            cwd=store, check=True, timeout=900,
        )
    return {"store": str(store), "bin": str(store / "bin"), "lib": str(store / "bin"),
            "sha256": {item: sha(store / item) for item in sorted(paths)}}


def declaration(store, source_sha, marker, on_kernel, off_kernel, proof, offline):
    binary = lambda name: str(store / "bin" / name)
    base = ["-m", MODEL, "-t", "8", "-b", "512", "-ngl", "99",
            "-fa", "on", "-ctk", "q8_0", "-ctv", "q8_0"]
    server = [binary("llama-server"), *base, "--host", "127.0.0.1", "--port", "{PORT}",
              "-np", "1", "-c", "16384", "-ub", "512", "--no-mmap",
              "-md", DRAFT, "-ngld", "99", "--spec-type", "draft-dflash", "--spec-draft-n-max", "7",
              "--device", "ROCm0", "--device-draft", "ROCm0", "-lv", "4"]
    ppl = [binary("llama-perplexity"), *base, "-f", "inputs/kld_text.txt",
           "-c", "1024", "--chunks", "1", "-lv", "4"]
    # The test-mode fixtures on 5d85e7e73: dtree_add_q8mf/_q8v5/_q8ip_eval_cases.
    shapes = {
        (12288, 5120): (1, 3, 5, 7, 13, 16),
        (17408, 5120): (1, 3, 4, 5, 7, 8, 13, 16),
        (5120, 17408): (1, 2, 3, 4, 8, 16),
        (5120, 6144): (1, 3, 5, 7, 13, 16),
    }
    cases = [re.escape(f"type_a=q8_0,type_b=f32,m={m},n={n},k={k},bs=[1,1],nr=[1,1]")
             for (m, k), widths in shapes.items() for n in widths]
    return {
        "row_id": ROW, "task": TASK, "offline_fixture": offline, "lane": "gpu", "rule": RULE,
        "knobs": {
            KNOBS[0]: {"kind": "env", "marker": marker, "level": 4, "cap": -1},
            KNOBS[1]: {"kind": "observe", "marker": V5I_MARKER, "level": 4, "cap": -1},
        },
        "arms": {"OFF": {}, "OFF2": {}, "ON": {KNOBS[0]: "1"}},
        "baseline": ["OFF", "OFF2"],
        "expect": {arm: {KNOBS[0]: "present" if arm == "ON" else "absent", KNOBS[1]: "present"} for arm in ARMS},
        "arm_stores": dict.fromkeys(ARMS, proof),
        "server": {
            "argv": server,
            "env": {
                "PATH": "/usr/bin:/bin:/opt/rocm/bin",
                "HIP_VISIBLE_DEVICES": "0", "ROCM_PATH": "/opt/rocm",
                "GGML_HIP_Q8_MF": "6", "GGML_HIP_Q8_MF_MIN": "1",
                "GGML_HIP_Q8_MF_INPLACE": "2", "GGML_HIP_Q8_MF_SLC": "1",
                "GGML_HIP_Q8_WVSK_MAX": "16", "GGML_NO_BACKTRACE": "1",
            },
            "warmup": 1, "ready_timeout_s": 900, "membind": 3, "kfd_min_vram_gib": 20.0,
        },
        "workload": {
            "input": "inputs/long_ctx.txt", "offsets": [0, 22000, 44000, 66000], "win_chars": 6000,
            "suffix": "\n\nSummarize the section above in detail, then list every command-line option it mentions.",
            "n_predict": 256,
        },
        "inputs": INPUTS,
        "metric": {"name": "ms_per_round", "higher_is_better": False},
        "keep": SPEC["keep"],
        "tbo": {
            "kind": "tbo", "argv": [binary("test-backend-ops"), "test", "-b", "ROCm0", "-p", "|".join(cases)],
            "ops": "MUL_MAT", "arms": ARMS, "require_rc0": True, "min_cases": len(cases),
            "required_cases": dict.fromkeys(cases, 1), "timeout_s": 1800,
            "env": {"GGML_HIP_Q8_MF_INPLACE": "2", "AUTOKERNEL_BACKEND_THREADS": "8"},
        },
        "kld": {
            "kind": "kld", "argv": ppl, "arms": ["OFF2", "ON"], "max_kld": 0.003,
            "timeout_s": 1800, "min_vram_gib": 20, "library_root": str(store),
        },
        "source_proof": {"source_sha": source_sha, "store": str(store)},
        "profile_kernels": {"on_kernel": on_kernel, "off_kernel": off_kernel},
        "smoke": SPEC["smoke"],
        "verdict_map": {"FAIL": {"FUTILITY_CANDIDATE_BELOW_FLOOR": "FUTILITY_BELOW_FLOOR"}},
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--store", required=True, type=Path)
    p.add_argument("--source-sha", required=True)
    p.add_argument("--marker", required=True)
    p.add_argument("--on-kernel", required=True)
    p.add_argument("--off-kernel", default="q8mf6_mul_mat")
    p.add_argument("--offline-fixture", action="store_true", help="Offline selftest only, refuses execution.")
    args = p.parse_args()
    store = args.store.resolve(strict=True)
    if not args.offline_fixture and not (ROOT / "op_profile.py").is_file():
        p.error("op_profile.py is required for run-ready sealing")
    proof = store_proof(store, args.source_sha, args.marker, args.on_kernel, args.off_kernel, args.offline_fixture)
    for rel, digest in INPUTS.items():
        if sha(ROOT / rel) != digest:
            raise ValueError(f"Input digest mismatch: {rel}")
    for gguf in (MODEL, DRAFT):
        if not Path(gguf).is_file():
            raise ValueError(f"Missing model: {gguf}")
    gate = declaration(store, args.source_sha, args.marker, args.on_kernel, args.off_kernel,
                       proof, args.offline_fixture)
    gate["kld"]["arms"].insert(0, "OFF")
    # The engine validates that explicit arm lists include both controls and would
    # run OFF again as a measurement. The prephase drops that redundant compare.
    (ROOT / "gate-declaration.json").write_text(json.dumps(gate, indent=2) + "\n")
    job = ROOT / "job.py"
    source, changed = re.subn(r"^SERVER_ARGV = .*?$", lambda _: f"SERVER_ARGV = {gate['server']['argv']!r}",
                              job.read_text(), flags=re.M)
    if changed != 1:
        raise ValueError("Need exactly one static SERVER_ARGV declaration in job.py.")
    job.write_text(source)
    source_files = ["job.py", "gate-declaration.json", "ak_gate.py", "ak_row_harness.py", "rocprof_trace.py",
                    "launch.sh", "check_complete.py", *INPUTS,
                    *(f for f in CONDITIONAL_FILES if (ROOT / f).is_file())]
    (ROOT / "SOURCE.sha256").write_text("".join(f"{sha(ROOT / f)}  {f}\n" for f in source_files))
    if args.offline_fixture:
        return
    output = ROOT / "out" / "RESULT.json"
    smoke = ROOT / "out" / "TERMINAL-smoke.json"
    spec = {
        "schema": "epyc.row.v3", "kind": "compute", "lane": "gpu", "owner": "autokernel",
        "id": ROW, "handoff_task": TASK, "handoff_task_sha": "6214f742f55b9de6",
        "regions": "mi210_0,88-95,184-191", "claim_cpus": "88-95,184-191", "declared_threads": 8,
        "launcher": str(ROOT / "launch.sh"), "workdir": str(ROOT), "scratch_root": str(ROOT),
        "result_path": str(output), "result_format": "json", "stop_file": str(ROOT / "STOP"),
        "estimate_s": ESTIMATE_S, "min_window_s": MIN_WINDOW_S, "ports": [PORT], "scratch_gb": 8.0,
        "first_progress_s": SPEC["smoke"]["budget_s"] + 60,
        "model": f"Qwen3.8-27B Q8_0 + DFlash2-Q8_0, V5I MF=6, np1 greedy, source {args.source_sha}",
        "decision_rule": RULE, "verdict_by": "agent", "requires_quiet_host": False, "resumable": True,
        "estimate_basis": {"provisional": True, "units": 78, "rebook_from": str(ROOT / "out-smoke/smoke_measure.json"),
                           "reason": "27 visits x 240 s, 12 KLD x 75 s, 3 TBO x 240 s, 36 profile units x 12 s plus margin"},
        "smoke_predicate": f"""/usr/bin/grep -q '"ok": true' {smoke} && [ "$(stat -c %Y {smoke})" -ge "${{FILLER_SMOKE_T0:?}}" ]""",
        "expects_created": [str(smoke)],
        "generator": {"tool": "prepare.py", "version": "v1", "profile": "gate",
                      "harness_sha256": sha(ROOT / "ak_row_harness.py"), "gate_sha256": sha(ROOT / "ak_gate.py")},
        "fresh_server_per_visit": True,
        "fresh_server_reason": "One server per arm visit to isolate the candidate and load-time V5I repack.",
        "witness_lines": [
            {"line": args.marker, "needs": 1, "cap": -1, "knob": KNOBS[0]},
            {"line": V5I_MARKER, "needs": 1, "cap": -1, "knob": KNOBS[1]},
        ],
        "keep": ["out/logs", "out/results.jsonl", "out/RESULT.json", "out/correctness", "out/prof",
                 "out/op-collection.json", "out/convcore-op-*", "out/TERMINAL-smoke.json", "out-smoke"],
        "notes": "Private candidate store shared by OFF/OFF2/ON. Content pins in gate-declaration.json.",
    }
    (ROOT / "spec.json").write_text(json.dumps(spec, indent=2) + "\n")


if __name__ == "__main__":
    main()
