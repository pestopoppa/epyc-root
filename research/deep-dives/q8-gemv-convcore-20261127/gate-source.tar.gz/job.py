#!/usr/bin/python3
"""Q8-GEMV-CONVCORE-1: CPU-reference and KLD checks, traced ops, then the greedy np1 speed gate."""
import hashlib
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import ak_gate as G
import ak_row_harness as H

ROW = "ak-q8-convcore-gpu-20261127"
TASK = "rocm-kernel-authoring.md:Q8-GEMV-CONVCORE-1"
KNOBS = ["GGML_HIP_Q8_MF6_CONVCORE", "V5I_INPLACE"]
SERVER_ARGV = ['/mnt/raid0/llm/tmp/q8-convcore-20261127/candidate-bundle/bin/llama-server', '-m', '/mnt/raid0/llm/models/Qwen3.8-27B-Q8_0.gguf', '-t', '8', '-b', '512', '-ngl', '99', '-fa', 'on', '-ctk', 'q8_0', '-ctv', 'q8_0', '--host', '127.0.0.1', '--port', '{PORT}', '-np', '1', '-c', '16384', '-ub', '512', '--no-mmap', '-md', '/mnt/raid0/llm/models/Qwen3.8-27B-DFlash2-Q8_0.gguf', '-ngld', '99', '--spec-type', 'draft-dflash', '--spec-draft-n-max', '7', '--device', 'ROCm0', '--device-draft', 'ROCm0', '-lv', '4']
SPEC = {
    "smoke": {"prompt_chars": 2000, "n_predict": 32, "budget_s": 1200},
    "keep": {"threshold": 1.01, "futility_threshold": 1.0, "n_blocks": 8, "look_blocks": 4,
             "aa_max": 0.02, "dummy_block": True},
}
KLD_UBS = (8, 4, 16, 512)
KLD_MAX = 0.003


def phase_specs(spec):
    yield "tbo", dict(spec, correctness=spec["tbo"])
    for ub in KLD_UBS:
        kld = dict(spec["kld"], argv=spec["kld"]["argv"] + ["-ub", str(ub)])
        settings = {"correctness": kld}
        if ub in (16, 512):
            settings["expect_by_unit"] = {"kld": {"ON": {KNOBS[0]: "ignore"}}}
        yield f"kld-u{ub}", dict(spec, **settings)


def phase_plan(scoped):
    return [(uid, kind, arm, extra) for uid, kind, arm, extra in G.plan_correctness(scoped)
            if not (kind == "c-kld" and arm == "OFF" and extra.get("mode") == "kld")]


def tbo_route_witness(spec, record, directory):
    if record.get("kind") == "c-tbo" and not record.get("error"):
        log = record.get("log")
        text = G.read_log(str(directory / log)) if log else None
        # This test-mode binary emits ggml native INFO directly. It does not
        # accept the CLI -lv flag required by llama-server/perplexity.
        record["witness"] = G.witness_for(spec, record["arm"], text, log=log)
    return record


def phase_verdict(record, base_logits):
    if record.get("error_class") == "STOPPED":
        return "STOPPED"
    if record.get("error") or G.mismatches([record]):
        return "FUTILITY_HARNESS_CORRECTNESS_WITNESS"
    arm = record["arm"]
    if record["kind"] == "c-tbo":
        if not record.get("pass"):
            return "FAIL_CORRECTNESS" if arm == "ON" else "FUTILITY_HARNESS_BASELINE"
        return None
    if record.get("rc") != 0:
        return "FUTILITY_HARNESS_KLD_PROCESS"
    if record["mode"] == "base":
        if not base_logits.is_file() or not base_logits.stat().st_size:
            return "FUTILITY_HARNESS_KLD_LOGITS"
    else:
        value = record.get("mean_kld")
        if not isinstance(value, (float, int)) or not math.isfinite(value):
            return "FUTILITY_HARNESS_KLD_OUTPUT"
        if value > KLD_MAX:
            return "FAIL_KLD" if arm == "ON" else "FUTILITY_HARNESS_KLD_AA"
    return None


def replay(spec, prior, decide_mode):
    from op_profile import replay_profile

    outdir, _ = G.resolve_prior(prior)
    evidence = Path(outdir)
    if not (evidence / "correctness").exists():
        if any(u.get("kind") == "visit" for u in G.load_units(outdir)):
            rec = {"verdict": "FUTILITY_HARNESS_MISSING_CORRECTNESS", "prior_out": outdir}
        else:
            rec = G.replay(spec, str(ROOT), prior)
    else:
        rec = {"verdict": "INCOMPLETE_CORRECTNESS", "prior_out": outdir}
        for name, scoped in phase_specs(spec):
            directory = evidence / "correctness" / name
            units, _, _ = G.replay_units(scoped, str(directory), str(directory))
            by_id = {u["unit_id"]: u for u in units}
            rec["phase"] = name
            failed = False
            for uid, kind, arm, extra in phase_plan(scoped):
                unit = by_id.get(uid)
                if not unit or unit["kind"] != kind or unit["arm"] != arm or any(
                    unit.get(key) != val for key, val in extra.items()
                ):
                    failed = True
                    rec["verdict"] = "INCOMPLETE_CORRECTNESS"
                    break
                tbo_route_witness(scoped, unit, directory)
                verdict = phase_verdict(unit, directory / "kld-base.bin")
                if verdict:
                    rec["verdict"] = verdict
                    failed = True
                    break
            if failed:
                break
        else:
            prof = replay_profile(evidence, **spec["profile_kernels"])
            if prof.get("ok"):
                rec = G.replay(spec, str(ROOT), prior)
                if rec["mode"] not in ("units", "logs-only"):
                    rec["verdict"] = "INCOMPLETE_TIMING"
                    rec["observed"].update(verdict=rec["verdict"], polar=None, terminal=False)
                rec["op_report"] = prof
            else:
                rec = {"verdict": "FUTILITY_HARNESS_OP", "prior_out": outdir,
                       "reason": prof.get("reason", "Missing op evidence")}
    print("DECIDE " + json.dumps(rec) if decide_mode else "REPLAY " + json.dumps(rec), flush=True)
    return 0


class ConvCoreGate(G.Gate):
    def finish(self, units, decision):
        scored = [u for u in units if u.get("kind") == "visit" and u.get("block", 0) > 0]
        tok_s = {}
        for arm in self.spec["arms"]:
            prompts = [r for u in scored if u.get("arm") == arm for r in u.get("req", ())]
            ms = sum(r.get("predicted_ms", 0) or 0 for r in prompts)
            if ms > 0:
                tok_s[arm] = 1000 * sum(r.get("predicted_n", 0) or 0 for r in prompts) / ms
        return super().finish(units, dict(decision, conversion_core={
            "source": self.spec["source_proof"], "phases": self.phase_results, "decode_tok_s": tok_s,
        }))

    def _fail(self, verdict, reason):
        return self.finish(G.load_units(self.out), {
            "verdict": verdict, "polar": G.polar(verdict), "terminal": True, "reason": reason,
        })

    def verify_arm_stores(self):
        if self.linkage_witness and all(v.get("ok") for v in self.linkage_witness.values()):
            return True
        original = self.spec
        self.spec = dict(original, correctness=[original["tbo"], original["kld"]])
        try:
            return super().verify_arm_stores()
        finally:
            self.spec = original

    def _phase(self, name, scoped):
        phase = G.Gate(scoped, self.d, env=self.env)
        phase.procs = self.procs
        phase.out = str(Path(self.out) / "correctness" / name)
        phase.logs = str(Path(phase.out) / "logs")
        Path(phase.logs).mkdir(parents=True, exist_ok=True)
        base_logits = Path(phase.out) / "kld-base.bin"
        units = []
        for uid, kind, arm, extra in phase_plan(scoped):
            if self.should_stop():
                return {"stopped": True}
            if extra.get("mode") == "base" and base_logits.exists():
                base_logits.unlink()
            record = phase.run_correctness_unit(uid, kind, arm, extra)
            tbo_route_witness(scoped, record, Path(phase.out))
            H.append_unit(record, phase.out)
            units.append(record)
            verdict = phase_verdict(record, base_logits)
            if verdict == "STOPPED":
                return {"stopped": True}
            if verdict:
                return {"ok": False, "verdict": verdict, "units": units}
        return {"ok": True, "units": units}

    def _run(self):
        from op_profile import profile

        self.phase_results = {}
        bad = self.prepare()
        if bad:
            return self._fail("FUTILITY_HARNESS_MISSING_INPUT", "; ".join(bad))
        if not self.verify_arm_stores():
            return self._fail("FUTILITY_HARNESS_LINKAGE", "Pinned store linkage failed.")
        build = self.spec["source_proof"]
        try:
            actual = json.loads((Path(build["store"]) / "BUILD-IDENTITY.json").read_text())
            if actual.get("source_sha") != build["source_sha"]:
                raise ValueError(f"expected source {build['source_sha']}, got {actual.get('source_sha')}")
        except (OSError, ValueError) as error:
            return self._fail("FUTILITY_HARNESS_SOURCE", str(error))
        declaration_hash = hashlib.sha256((ROOT / "SOURCE.sha256").read_bytes()).hexdigest()
        for name, scoped in phase_specs(self.spec):
            if self.should_stop():
                return 75
            checkpoint = Path(self.out) / "correctness" / name / "PASS.json"
            try:
                prior = json.loads(checkpoint.read_text())
            except (OSError, ValueError):
                prior = {}
            if prior.get("declaration_sha256") == declaration_hash and prior.get("result", {}).get("ok"):
                result = prior["result"]
            else:
                result = self._phase(name, scoped)
            self.phase_results[name] = result
            if result.get("stopped"):
                return 75
            if not result.get("ok"):
                return self._fail(result["verdict"], f"{name} did not clear its predeclared check.")
            G.atomic_json(str(checkpoint), {"declaration_sha256": declaration_hash, "result": result})
        op_result = profile(self, **self.spec["profile_kernels"])
        self.phase_results["op"] = op_result
        if op_result.get("stopped"):
            return 75
        if not op_result.get("ok"):
            return self._fail("FUTILITY_HARNESS_OP", op_result.get("reason", "Trace or counter witness missing."))
        return super()._run()


def main(argv):
    spec = json.loads((ROOT / "gate-declaration.json").read_text())
    if any(spec[k] != v for k, v in SPEC.items()) or spec["server"]["argv"] != SERVER_ARGV:
        raise ValueError("Sealed gate declaration differs from the static publish-time declaration.")
    if "--selftest" in argv:
        for _, scoped in phase_specs(spec):
            G.validate_spec(scoped)
            assert len(phase_plan(scoped)) == 3
        def buffered_cells(n, speedup):
            return [{"kind": "visit", "block": b, "arm": a, "metric": v}
                    for b in range(1, n + 1) for a, v in [
                        ("OFF", 100), ("OFF2", 100), ("ON", 100 / speedup)]]
        assert G.decide(spec, buffered_cells(4, 0.99))["verdict"] == "FUTILITY_BELOW_FLOOR"
        assert G.decide(spec, buffered_cells(4, 1.005))["verdict"] == "INCOMPLETE"
        assert G.decide(spec, buffered_cells(8, 1.005))["verdict"] == "NO_KEEP"
        assert G.decide(spec, buffered_cells(8, 1.03))["verdict"] == "KEEP_ON"
        return G.selftest(spec, str(ROOT))
    if "--replay" in argv or "--decide-from" in argv:
        flag = "--replay" if "--replay" in argv else "--decide-from"
        return replay(spec, argv[argv.index(flag) + 1], flag == "--decide-from")
    if spec.get("offline_fixture"):
        raise SystemExit("Offline fixture declaration cannot execute.")
    H.require_grant(os.environ)
    gate = ConvCoreGate(spec, str(ROOT))
    gate.phase_results = {}
    gate.install_traps()
    try:
        if os.environ.get("FILLER_SMOKE") == "1" or os.environ.get("FILLER_DRYRUN") == "1":
            return gate.smoke()
        return gate.run()
    finally:
        gate.kill_all()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
