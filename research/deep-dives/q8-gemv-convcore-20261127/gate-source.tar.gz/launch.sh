#!/bin/bash
set -euo pipefail
D=/mnt/raid0/llm/tmp/codex-convcore-gate-20261127
C=${WS58_CPUS:-88-95,184-191}
cd "$D"
ulimit -c 0
/usr/bin/sha256sum --check --status SOURCE.sha256
exec /bin/bash /mnt/raid0/llm/tmp/compute-flags/bin/rowflow/filler_run15.sh --id ak-q8-convcore-gpu-20261127 \
  --class gpu --claim-cpus "$C" --role bench --min-window 1800 --port 28112 \
  --cmd "/usr/bin/python3 -I -B $D/job.py" \
  --complete-cmd "/usr/bin/python3 -I -B $D/check_complete.py" \
  --stop "$D/STOP" --workdir "$D"
