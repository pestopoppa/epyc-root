"""Width-8 MI210 op evidence run inside the Q8 conversion-core gate."""

import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
from tempfile import mkdtemp

SDK = Path("/mnt/raid0/llm/tools/rocprofiler-sdk-6.2.0-66/opt/rocm-6.2.0")
PROFILER = SDK / "bin/rocprofv3"
SDK_SUPPORT = "/mnt/raid0/llm/tools/rocm-profilers-6.2/opt/rocm-6.2.0/lib"
CASE_SET = "served_shape_perf_v1"
SELECTION = "op-collection.json"
MANIFEST = "collection.json"
TRACE_SUFFIX = "_kernel_trace.csv"
COUNTER_SUFFIX = "_counter_collection.csv"
AGENT_SUFFIX = "_agent_info.csv"
# Historical target verify shape call weights from ak-c22-q8wp-op-gpu-20261125.
SHAPES = {
    "attn_q": (12288, 5120, 17),
    "attn_qkv": (10240, 5120, 48),
    "attn_out": (5120, 6144, 65),
    "attn_gate": (6144, 5120, 48),
    "ffn_gateup": (17408, 5120, 130),
    "ffn_down": (5120, 17408, 65),
}
COUNTERS = ("SQ_INSTS_VALU", "SQ_INSTS_MFMA", "SQ_INSTS_VMEM_RD", "SQ_INSTS_LDS")
COMPETING = ("mul_mat", "gemm", "hipblas", "rocblas", "q8ip_mmvq", "q8_skinny", "Cijk")
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def exact_symbol(symbol):
    if not re.fullmatch(r"_Z[A-Za-z0-9_]+(?:\.kd)?", symbol):
        raise ValueError("an exact mangled gfx90a kernel symbol is required")
    return symbol if symbol.endswith(".kd") else symbol + ".kd"


def only_file(folder, suffix):
    paths = sorted(folder.rglob(f"*{suffix}"))
    if len(paths) != 1:
        raise ValueError(f"expected one {suffix} in {folder}, found {len(paths)}")
    return paths[0]


def csv_rows(path):
    with path.open(newline="") as handle:
        yield from csv.DictReader(handle)


def check_route(name, symbol):
    if name == symbol:
        return True
    if any(pattern in name for pattern in COMPETING):
        raise ValueError(f"expected {symbol}, observed competing kernel {name}")
    return False


def mi210_agents(folder):
    return {
        row["Node_Id"] for row in csv_rows(only_file(folder, AGENT_SUFFIX))
        if row["Name"] == "gfx90a" and row["Product_Name"] == "AMD Instinct MI210"
    }


def trace_metrics(folder, symbol, grid):
    path = only_file(folder, TRACE_SUFFIX)
    agents = mi210_agents(folder)
    durations = []
    for row in csv_rows(path):
        if not check_route(row["Kernel_Name"], symbol):
            continue
        resources = tuple(int(row[key]) for key in (
            "Private_Segment_Size", "Group_Segment_Size", "Workgroup_Size_X",
            "Workgroup_Size_Y", "Workgroup_Size_Z", "Grid_Size_X", "Grid_Size_Y", "Grid_Size_Z"))
        if row["Agent_Id"] not in agents or resources != (0, 15360, 256, 1, 1, grid, 1, 1):
            raise ValueError(f"unexpected MI210 dispatch resources: {resources}")
        elapsed = int(row["End_Timestamp"]) - int(row["Start_Timestamp"])
        if elapsed <= 0:
            raise ValueError(f"invalid duration for {symbol}")
        durations.append(elapsed)
    if len(durations) < 2:
        raise ValueError(f"insufficient trace dispatches for {symbol}")
    return {"duration_ns": statistics.median(durations), "dispatches": len(durations),
            "csv": str(path)}


def counter_metrics(folder, symbol, grid, expected_mfma):
    path = only_file(folder, COUNTER_SUFFIX)
    agents = mi210_agents(folder)
    by_dispatch = {}
    dispatch_identity = {}
    process = None
    for row in csv_rows(path):
        if not check_route(row["Kernel_Name"], symbol):
            continue
        resources = tuple(int(row[key]) for key in (
            "Scratch_Size", "LDS_Block_Size", "Workgroup_Size", "Grid_Size"))
        if row["Agent_Id"] not in agents or resources != (0, 15360, 256, grid):
            raise ValueError(f"unexpected MI210 counter dispatch resources: {resources}")
        if process is None:
            process = row["Process_Id"]
        if row["Process_Id"] != process:
            raise ValueError("mixed processes in one counter collection")
        dispatch = int(row["Dispatch_Id"])
        identity = tuple(row[key] for key in ("Agent_Id", "Queue_Id", "Correlation_Id"))
        if dispatch_identity.setdefault(dispatch, identity) != identity:
            raise ValueError(f"ambiguous identity for counter dispatch {dispatch}")
        insts = by_dispatch.setdefault(dispatch, {})
        name = row["Counter_Name"]
        if name in insts:
            raise ValueError(f"duplicate {name} row for counter dispatch {dispatch}")
        value = float(row["Counter_Value"])
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"invalid {name} for {symbol}")
        insts[name] = value
    if len(by_dispatch) < 2 or any(not set(COUNTERS) <= values.keys() for values in by_dispatch.values()):
        raise ValueError(f"incomplete C6 dispatches for {symbol}")
    if any(values["SQ_INSTS_MFMA"] != expected_mfma or values["SQ_INSTS_VALU"] <= 0
           for values in by_dispatch.values()):
        raise ValueError(f"unexpected MFMA or VALU count for {symbol}")
    counts = {name: statistics.median(dispatch[name] for dispatch in by_dispatch.values())
              for name in COUNTERS}
    return {"counter_instructions": counts, "dispatches": len(by_dispatch), "csv": str(path)}


def collection_plan():
    for index, shape in enumerate(SHAPES):
        for kind, rep in (("trace", 1), ("trace", 2), ("pmc", 1)):
            order = ("OFF", "ON") if (index + rep) % 2 else ("ON", "OFF")
            for arm in order:
                yield arm, shape, kind, rep


def unit_name(arm, shape, kind, rep):
    return f"convcore-{shape}-w8-{kind}-{rep}-{arm.lower()}"


def case_for(shape):
    m, k, _ = SHAPES[shape]
    return f"type_a=q8_0,type_b=f32,m={m},n=8,k={k},bs=[1,1],nr=[1,1]"


def read_profile_pass(folder, arm, shape, kind, rep, symbol):
    case = case_for(shape)
    log = folder / "run.log"
    txt = ANSI.sub("", log.read_text(errors="replace"))
    case_lines = [line for line in txt.splitlines() if line.lstrip().startswith("MUL_MAT(")]
    # The profiler may log during the case line, splitting the normal TBO timing line away.
    if len(case_lines) != 1 or case not in case_lines[0] or "us/run" not in txt:
        raise ValueError(f"{folder.name}: expected one timed TBO case for {case}")
    m, k, _ = SHAPES[shape]
    units = m // 32 * (k // 256)
    grid = min(416, units) * 256
    metric = (trace_metrics(folder, symbol, grid) if kind == "trace"
              else counter_metrics(folder, symbol, grid, units * 4 * 8))
    return {"arm": arm, "shape": shape, "kind": kind, "rep": rep, "symbol": symbol, **metric}


def profile_pass(gate, tbo, root, arm, shape, kind, rep, symbol):
    uid = unit_name(arm, shape, kind, rep)
    # Fresh result directory prevents stale CSVs after interruption or a retry.
    folder = root / uid
    folder.mkdir()
    log = folder / "run.log"
    case = case_for(shape)
    argv = [str(PROFILER), "-M", "--output-format", "csv", "-d", str(folder), "-o", uid]
    if kind == "trace":
        argv.append("--kernel-trace")
    else:
        request = folder / "pmc.txt"
        request.write_text("pmc: " + " ".join(COUNTERS) + "\n")
        argv += ["-i", str(request)]
    argv += ["--"] + gate.pin([str(tbo), "perf", "-b", "ROCm0", "-o", "MUL_MAT", "-p", re.escape(case)])
    env = gate.proc_env(arm, str(tbo), {
        "AUTOKERNEL_CORRECTNESS_CASE_SET": CASE_SET,
        # test-backend-ops uses ordinary buffers; value 2 packs these as well.
        "GGML_HIP_Q8_MF_INPLACE": "2",
    })
    if any(env.get(key) != val for key, val in (
        ("GGML_HIP_Q8_MF", "6"), ("GGML_HIP_Q8_MF_MIN", "1"),
        ("GGML_HIP_Q8_MF_INPLACE", "2"), ("GGML_HIP_Q8_MF_SLC", "1"),
    )):
        raise ValueError(f"{arm}: expected stage-packed V5I and SLC route")
    env["LD_LIBRARY_PATH"] = ":".join(dict.fromkeys([
        str(tbo.parent), "/opt/rocm/lib", str(SDK / "lib"),
        str(SDK / "lib/rocprofiler-sdk"), SDK_SUPPORT,
    ]))
    result = gate.run_fn(argv, env, str(log), 180 if kind == "trace" else 300)
    if result.get("error") or result.get("rc") != 0:
        raise RuntimeError(result.get("error") or f"{uid}: profiler exited {result.get('rc')}")
    return {"secs": result.get("secs"), **read_profile_pass(folder, arm, shape, kind, rep, symbol)}


def summarize(units):
    by_arm = {}
    for arm in ("OFF", "ON"):
        cells = {}
        for shape, (m, k, calls) in SHAPES.items():
            matched = [unit for unit in units if unit["arm"] == arm and unit["shape"] == shape]
            duration_ns = statistics.median(unit["duration_ns"] for unit in matched if unit["kind"] == "trace")
            counters, = [unit["counter_instructions"] for unit in matched if unit["kind"] == "pmc"]
            nbytes = m * k * 34 // 32
            cells[shape] = {"duration_ns": duration_ns, "weight_bytes": nbytes, "calls": calls,
                            "gbps": nbytes / duration_ns,
                            "valu_per_kib": counters["SQ_INSTS_VALU"] / (nbytes / 1024),
                            "counter_instructions": counters}
        total_ns = sum(cell["duration_ns"] * cell["calls"] for cell in cells.values())
        total_bytes = sum(cell["weight_bytes"] * cell["calls"] for cell in cells.values())
        total_valu = sum(cell["counter_instructions"]["SQ_INSTS_VALU"] * cell["calls"] for cell in cells.values())
        by_arm[arm] = {"shapes": cells, "weighted_ms": total_ns / 1e6, "weighted_gbps": total_bytes / total_ns,
                       "weighted_valu_per_kib": total_valu / (total_bytes / 1024)}
    off, on = by_arm["OFF"], by_arm["ON"]
    return {"arms": by_arm, "speedup": off["weighted_ms"] / on["weighted_ms"],
            "off_valu_per_kib": off["weighted_valu_per_kib"], "on_valu_per_kib": on["weighted_valu_per_kib"],
            "width": 8, "device": "AMD Instinct MI210 (gfx90a)", "backend": "ROCm0",
            "reference_arm": "OFF, same GPU store and synthetic op shape; CPU reference belongs to correctness",
            "weighting": "historical per-step calls × median profile dispatch duration"}


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def atomic_json(path, payload):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def symbols_for(on_kernel, off_kernel):
    symbols = {"OFF": exact_symbol(off_kernel), "ON": exact_symbol(on_kernel)}
    if symbols["OFF"] == symbols["ON"]:
        raise ValueError("OFF and ON kernels must have distinct symbols")
    return symbols


def evidence_files(folder, kind):
    return (folder / "run.log", only_file(folder, AGENT_SUFFIX),
            only_file(folder, TRACE_SUFFIX if kind == "trace" else COUNTER_SUFFIX))


def binding_for(gate, tbo):
    return {
        "source_commit": gate.spec.get("source_proof", {}).get("source_sha"),
        "runner_source_sha256": digest(Path(gate.d) / "SOURCE.sha256"),
        "test_backend_ops_sha256": digest(tbo),
        "hip_library_sha256": digest(tbo.parent / "libggml-hip.so"),
    }


def replay_profile(out, *, on_kernel, off_kernel, binding=None):
    """Verify and replay just the selected complete op collection. No device required."""
    out = Path(out)
    units = []
    try:
        symbols = symbols_for(on_kernel, off_kernel)
        selection = json.loads((out / SELECTION).read_text())
        name = selection["collection"]
        if not re.fullmatch(r"convcore-op-[A-Za-z0-9_]+", name):
            raise ValueError("invalid selected op collection name")
        root = out / name
        manifest_path = root / MANIFEST
        if digest(manifest_path) != selection["manifest_sha256"]:
            raise ValueError("selected op manifest hash mismatch")
        manifest = json.loads(manifest_path.read_text())
        if manifest["symbols"] != symbols:
            raise ValueError("op collection does not match the declared arm symbols")
        if binding is not None and manifest["binding"] != binding:
            raise ValueError("op collection does not match the current source and artifact binding")
        plan = list(collection_plan())
        expected_names = {unit_name(*item) for item in plan}
        if set(manifest["passes"]) != expected_names:
            raise ValueError("incomplete or mixed op collection manifest")
        for arm, shape, kind, rep in plan:
            uid = unit_name(arm, shape, kind, rep)
            folder = root / uid
            files = evidence_files(folder, kind)
            if {str(p.relative_to(root)): digest(p) for p in files} != manifest["passes"][uid]:
                raise ValueError(f"op input hash mismatch: {uid}")
            units.append(read_profile_pass(folder, arm, shape, kind, rep, symbols[arm]))
        return {"ok": True, "stopped": False, "units": units, "collection": name,
                "binding": manifest["binding"], **summarize(units)}
    except (OSError, RuntimeError, ValueError, TypeError, KeyError) as exc:
        return {"ok": False, "stopped": False, "reason": str(exc), "units": units}


def profile(gate, *, on_kernel, off_kernel):
    """Collect native op evidence using the gate's binary, grant and process manager."""
    units = []
    try:
        symbols = symbols_for(on_kernel, off_kernel)
        tbo = Path(gate.spec["server"]["argv"][0]).parent / "test-backend-ops"
        if not tbo.is_file() or CASE_SET.encode() not in tbo.read_bytes() or not PROFILER.is_file():
            raise ValueError("missing the candidate store's served-shape TBO or the pinned ROCm profiler")
        out = Path(gate.out)
        out.mkdir(parents=True, exist_ok=True)
        binding = binding_for(gate, tbo)
        if (out / SELECTION).exists():
            # Preserve the op/timing join on resumption of the same published row.
            return replay_profile(out, on_kernel=on_kernel, off_kernel=off_kernel, binding=binding)
        if gate.should_stop():
            return {"ok": False, "stopped": True, "reason": "stopped", "units": units}
        root = Path(mkdtemp(prefix="convcore-op-", dir=out))
        passes = {}
        for arm, shape, kind, rep in collection_plan():
            if gate.should_stop():
                return {"ok": False, "stopped": True, "reason": "stopped", "units": units}
            units.append(profile_pass(gate, tbo, root, arm, shape, kind, rep, symbols[arm]))
            uid = unit_name(arm, shape, kind, rep)
            files = evidence_files(root / uid, kind)
            passes[uid] = {str(p.relative_to(root)): digest(p) for p in files}
        summary = summarize(units)
        manifest = root / MANIFEST
        atomic_json(manifest, {"symbols": symbols, "binding": binding, "passes": passes})
        atomic_json(out / SELECTION, {"collection": root.name, "manifest_sha256": digest(manifest)})
        return {"ok": True, "stopped": False, "units": units, "collection": root.name,
                "binding": binding, **summary}
    except (OSError, RuntimeError, ValueError, TypeError, KeyError) as exc:
        return {"ok": False, "stopped": gate.should_stop(), "reason": str(exc), "units": units}
